export interface Profile {
  id: string;
  email: string;
  display_name: string;
  avatar_url: string;
  bio: string;
  current_level: string;
  target_level: string;
  daily_goal_minutes: number;
  total_xp: number;
  streak_days: number;
  last_study_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserSettings {
  id: string;
  user_id: string;
  theme: 'light' | 'dark';
  interface_language: 'uk' | 'en';
  notification_reviews: boolean;
  notification_lessons: boolean;
  notification_marketing: boolean;
  gamification_enabled: boolean;
}

export interface VocabularyCategory {
  id: string;
  name_uk: string;
  name_en: string;
  icon: string;
  sort_order: number;
}

export interface Vocabulary {
  id: string;
  word: string;
  translation_uk: string;
  transcription: string;
  part_of_speech: string;
  cefr_level: string;
  example_en: string;
  example_uk: string;
  collocations: string;
  synonyms: string;
  antonyms: string;
  common_mistakes: string;
  category_id: string | null;
  is_for_nmt: boolean;
  difficulty: number;
}

export interface UserVocabulary {
  id: string;
  user_id: string;
  vocabulary_id: string;
  is_favorite: boolean;
  is_difficult: boolean;
  is_learned: boolean;
  times_practiced: number;
  times_correct: number;
  first_studied_at: string | null;
  last_studied_at: string | null;
  sm2_interval: number;
  sm2_repetitions: number;
  sm2_easiness: number;
  sm2_next_review: string;
  vocabulary?: Vocabulary;
}

export interface VocabularyReview {
  id: string;
  user_id: string;
  vocabulary_id: string;
  quality: number;
  was_correct: boolean;
  reviewed_at: string;
}

export interface VocabularyDeck {
  id: string;
  user_id: string;
  name: string;
  description: string;
  created_at: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  cefr_level: string;
  cover_emoji: string;
  is_published: boolean;
  sort_order: number;
}

export interface Module {
  id: string;
  course_id: string;
  title: string;
  description: string;
  sort_order: number;
}

export interface Lesson {
  id: string;
  module_id: string;
  title: string;
  content: string;
  lesson_type: string;
  estimated_minutes: number;
  sort_order: number;
}

export interface LessonProgress {
  id: string;
  user_id: string;
  lesson_id: string;
  status: 'not_started' | 'in_progress' | 'completed';
  progress_percent: number;
  started_at: string | null;
  completed_at: string | null;
}

export interface ExerciseQuestion {
  id: string;
  exercise_id: string;
  question_text: string;
  correct_answer: string;
  hint: string;
  explanation: string;
  sort_order: number;
}

export interface ExerciseOption {
  id: string;
  question_id: string;
  option_text: string;
  is_correct: boolean;
  sort_order: number;
}

export interface ExerciseAttempt {
  id: string;
  user_id: string;
  exercise_id: string;
  score: number;
  total_questions: number;
  time_spent_seconds: number;
  completed_at: string;
}

export interface ExamVariant {
  id: string;
  title: string;
  description: string;
  duration_minutes: number;
  is_published: boolean;
}

export interface ExamQuestion {
  id: string;
  exam_variant_id: string;
  question_number: number;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  explanation: string;
  topic: string;
}

export interface ExamAttempt {
  id: string;
  user_id: string;
  exam_variant_id: string;
  status: 'in_progress' | 'completed';
  score: number;
  total_questions: number;
  started_at: string;
  completed_at: string | null;
  time_spent_seconds: number;
}

export interface ExamAnswer {
  id: string;
  exam_attempt_id: string;
  question_id: string;
  selected_option: string | null;
  is_marked: boolean;
  answered_at: string | null;
}

export interface StudySession {
  id: string;
  user_id: string;
  session_type: string;
  duration_seconds: number;
  items_studied: number;
  items_correct: number;
  xp_earned: number;
  studied_at: string;
}

export interface StudyPlan {
  id: string;
  user_id: string;
  plan_date: string;
  task_type: string;
  title: string;
  duration_minutes: number;
  is_completed: boolean;
  completed_at: string | null;
}

export interface Achievement {
  id: string;
  code: string;
  title_uk: string;
  title_en: string;
  description_uk: string;
  description_en: string;
  icon: string;
  xp_reward: number;
  threshold: number;
  metric: string;
}

export interface UserAchievement {
  id: string;
  user_id: string;
  achievement_id: string;
  earned_at: string;
  achievement?: Achievement;
}

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: string;
  is_read: boolean;
  created_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  category: string;
  message: string;
  status: string;
  created_at: string;
}

export interface GrammarTopic {
  id: string;
  title_uk: string;
  title_en: string;
  cefr_level: string;
  category: string;
  summary: string;
  explanation: string;
  rules: string;
  sort_order: number;
}

export interface GrammarExample {
  id: string;
  topic_id: string;
  sentence_en: string;
  sentence_uk: string;
  note: string;
  sort_order: number;
}

export interface GrammarExercise {
  id: string;
  topic_id: string;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  explanation: string;
  sort_order: number;
}

export interface ReadingText {
  id: string;
  title: string;
  cefr_level: string;
  category: string;
  excerpt: string;
  body: string;
  source: string;
  estimated_minutes: number;
  sort_order: number;
}

export interface ReadingQuestion {
  id: string;
  text_id: string;
  question: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_option: string;
  explanation: string;
  sort_order: number;
}

export interface ReadingProgress {
  id: string;
  user_id: string;
  text_id: string;
  score: number;
  total_questions: number;
  completed_at: string;
}

export interface ListeningTrack {
  id: string;
  title: string;
  cefr_level: string;
  category: string;
  description: string;
  video_url: string;
  audio_url: string;
  duration_seconds: number;
  thumbnail_url: string;
  sort_order: number;
}

export interface ListeningSubtitle {
  id: string;
  track_id: string;
  start_time: number;
  end_time: number;
  text_en: string;
  text_uk: string;
  sort_order: number;
}

export interface ListeningProgress {
  id: string;
  user_id: string;
  track_id: string;
  watched_seconds: number;
  completed: boolean;
  last_watched_at: string;
}

export interface UserStudyPlanItem {
  id: string;
  user_id: string;
  plan_date: string;
  task_type: string;
  title: string;
  description: string;
  target_url: string;
  difficulty: string;
  is_completed: boolean;
  completed_at: string | null;
  sort_order: number;
}
