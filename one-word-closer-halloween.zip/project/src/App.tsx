import { useEffect } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { ThemeProvider } from '@/context/ThemeContext';
import { RouterProvider, useRouter } from '@/context/RouterContext';
import { I18nProvider } from '@/context/I18nContext';
import { LoadingState } from '@/components/ui/States';

import { LandingPage } from '@/pages/public/LandingPage';
import { AboutPage } from '@/pages/public/AboutPage';
import { FeaturesPage } from '@/pages/public/FeaturesPage';
import { CoursesPage } from '@/pages/public/CoursesPage';
import { NMTPage } from '@/pages/public/NMTPage';
import { FAQPage } from '@/pages/public/FAQPage';
import { ContactPage } from '@/pages/public/ContactPage';
import { PrivacyPage, TermsPage, NotFoundPage } from '@/pages/public/LegalPages';

import { LoginPage } from '@/pages/auth/LoginPage';
import { RegisterPage } from '@/pages/auth/RegisterPage';
import { OnboardingPage } from '@/pages/auth/OnboardingPage';

import { DashboardPage } from '@/pages/app/DashboardPage';
import { VocabularyPage } from '@/pages/app/VocabularyPage';
import { ReviewPage } from '@/pages/app/ReviewPage';
import { TrainersPage } from '@/pages/app/TrainersPage';
import { CoursesAppPage } from '@/pages/app/CoursesAppPage';
import { NMTPrepPage } from '@/pages/app/NMTPrepPage';
import { ExamPage } from '@/pages/app/ExamPage';
import { AnalyticsPage } from '@/pages/app/AnalyticsPage';
import { AchievementsPage } from '@/pages/app/AchievementsPage';
import { SettingsPage } from '@/pages/app/SettingsPage';

const publicRoutes: Record<string, React.ComponentType> = {
  '/': LandingPage,
  '/about': AboutPage,
  '/features': FeaturesPage,
  '/courses': CoursesPage,
  '/nmt': NMTPage,
  '/faq': FAQPage,
  '/contact': ContactPage,
  '/privacy': PrivacyPage,
  '/terms': TermsPage,
};

const authRoutes: Record<string, React.ComponentType> = {
  '/login': LoginPage,
  '/register': RegisterPage,
};

const appRoutes: Record<string, React.ComponentType> = {
  '/dashboard': DashboardPage,
  '/vocabulary': VocabularyPage,
  '/review': ReviewPage,
  '/trainers': TrainersPage,
  '/courses-app': CoursesAppPage,
  '/nmt-prep': NMTPrepPage,
  '/exam': ExamPage,
  '/analytics': AnalyticsPage,
  '/achievements': AchievementsPage,
  '/settings': SettingsPage,
};

function Router() {
  const { path } = useRouter();
  const { user, loading, needsOnboarding } = useAuth();

  useEffect(() => {
    const handler = () => {
      window.scrollTo({ top: 0 });
    };
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-navy-50 dark:bg-navy-950 flex items-center justify-center">
        <LoadingState message="Завантаження платформи..." />
      </div>
    );
  }

  if (authRoutes[path] && !user) {
    const Page = authRoutes[path];
    return <Page />;
  }

  if (user && needsOnboarding && path !== '/onboarding') {
    return <OnboardingPage />;
  }

  if (appRoutes[path]) {
    if (!user) {
      const Page = LoginPage;
      return <Page />;
    }
    const Page = appRoutes[path];
    return <Page />;
  }

  if (publicRoutes[path]) {
    const Page = publicRoutes[path];
    return <Page />;
  }

  if (path === '/onboarding' && user) {
    return <OnboardingPage />;
  }

  return <NotFoundPage />;
}

function RouterWithI18n() {
  const { settings, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen bg-navy-50 dark:bg-navy-950 flex items-center justify-center">
        <LoadingState message="Завантаження платформи..." />
      </div>
    );
  }
  return (
    <I18nProvider initialLang={settings?.interface_language || 'uk'}>
      <Router />
    </I18nProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <RouterProvider>
          <RouterWithI18n />
        </RouterProvider>
      </ThemeProvider>
    </AuthProvider>
  );
}
