import { useState } from 'react';
import { Menu, X, GraduationCap, Sun, Moon, Globe } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useI18n } from '@/context/I18nContext';

export function PublicNavbar() {
  const { path, navigate } = useRouter();
  const { user } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { lang, setLang, t } = useI18n();
  const [mobileOpen, setMobileOpen] = useState(false);

  const links = [
    { label: t('nav.home'), path: '/' },
    { label: t('nav.about'), path: '/about' },
    { label: t('nav.features'), path: '/features' },
    { label: t('nav.coursesPublic'), path: '/courses' },
    { label: t('nav.nmtPublic'), path: '/nmt' },
    { label: t('nav.faq'), path: '/faq' },
  ];

  const isActive = (p: string) => path === p || (p !== '/' && path.startsWith(p));

  return (
    <header className="fixed top-0 left-0 right-0 z-40 bg-white/80 dark:bg-navy-950/80 backdrop-blur-lg border-b border-navy-200/60 dark:border-navy-800/60 transition-colors">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <button onClick={() => navigate('/')} className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-sm group-hover:shadow-md transition-shadow">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <span className="font-heading font-bold text-lg text-navy-900 dark:text-white">
            One Word Closer
          </span>
        </button>

        <div className="hidden lg:flex items-center gap-1">
          {links.map((link) => (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                isActive(link.path)
                  ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-950/30'
                  : 'text-navy-600 dark:text-navy-300 hover:text-navy-900 dark:hover:text-white hover:bg-navy-100 dark:hover:bg-navy-800/50'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setLang(lang === 'uk' ? 'en' : 'uk')}
            className="btn-ghost p-2"
            aria-label="Switch language"
          >
            <Globe className="w-5 h-5" />
          </button>
          <button onClick={toggleTheme} className="btn-ghost p-2" aria-label="Змінити тему">
            {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
          </button>
          {user ? (
            <button onClick={() => navigate('/dashboard')} className="btn-primary hidden sm:inline-flex">
              Кабінет
            </button>
          ) : (
            <>
              <button onClick={() => navigate('/login')} className="btn-ghost hidden sm:inline-flex">
                {t('nav.login')}
              </button>
              <button onClick={() => navigate('/register')} className="btn-primary hidden sm:inline-flex">
                {t('nav.start')}
              </button>
            </>
          )}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="btn-ghost p-2 lg:hidden"
            aria-label="Меню"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {mobileOpen && (
        <div className="lg:hidden border-t border-navy-200/60 dark:border-navy-800/60 bg-white dark:bg-navy-950 animate-slide-down">
          <div className="px-4 py-3 space-y-1">
            {links.map((link) => (
              <button
                key={link.path}
                onClick={() => { navigate(link.path); setMobileOpen(false); }}
                className={`block w-full text-left px-3 py-2 rounded-lg text-sm font-medium ${
                  isActive(link.path)
                    ? 'text-primary-600 dark:text-primary-400 bg-primary-50 dark:bg-primary-950/30'
                    : 'text-navy-600 dark:text-navy-300'
                }`}
              >
                {link.label}
              </button>
            ))}
            {!user && (
              <div className="pt-2 flex gap-2">
                <button onClick={() => { navigate('/login'); setMobileOpen(false); }} className="btn-secondary flex-1">
                  {t('nav.login')}
                </button>
                <button onClick={() => { navigate('/register'); setMobileOpen(false); }} className="btn-primary flex-1">
                  {t('nav.start')}
                </button>
              </div>
            )}
            {user && (
              <button onClick={() => { navigate('/dashboard'); setMobileOpen(false); }} className="btn-primary w-full">
                {t('nav.cabinet')}
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}

export function PublicFooter() {
  const { navigate } = useRouter();
  const { lang } = useI18n();
  const isEn = lang === 'en';
  return (
    <footer className="border-t border-navy-200 dark:border-navy-800 bg-white dark:bg-navy-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
                <GraduationCap className="w-4 h-4 text-white" />
              </div>
              <span className="font-heading font-bold text-navy-900 dark:text-white">One Word Closer</span>
            </div>
            <p className="text-sm text-navy-500 dark:text-navy-400">
              {isEn ? 'A platform for learning English and preparing for NMT.' : 'Платформа для вивчення англійської мови та підготовки до НМТ.'}
            </p>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-navy-800 dark:text-navy-200 mb-3">{isEn ? 'Platform' : 'Платформа'}</h4>
            <ul className="space-y-2">
              <li><button onClick={() => navigate('/about')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'About' : 'Про платформу'}</button></li>
              <li><button onClick={() => navigate('/features')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'Features' : 'Можливості'}</button></li>
              <li><button onClick={() => navigate('/courses')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'Courses' : 'Курси'}</button></li>
              <li><button onClick={() => navigate('/nmt')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'NMT Prep' : 'Підготовка до НМТ'}</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-navy-800 dark:text-navy-200 mb-3">{isEn ? 'Learning' : 'Навчання'}</h4>
            <ul className="space-y-2">
              <li><button onClick={() => navigate('/nmt')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'NMT Prep' : 'Підготовка до НМТ'}</button></li>
              <li><button onClick={() => navigate('/faq')} className="text-sm text-navy-500 hover:text-primary-600">FAQ</button></li>
              <li><button onClick={() => navigate('/contact')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'Support' : 'Підтримка'}</button></li>
            </ul>
          </div>
          <div>
            <h4 className="text-sm font-semibold text-navy-800 dark:text-navy-200 mb-3">{isEn ? 'Legal' : 'Правове'}</h4>
            <ul className="space-y-2">
              <li><button onClick={() => navigate('/privacy')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'Privacy' : 'Конфіденційність'}</button></li>
              <li><button onClick={() => navigate('/terms')} className="text-sm text-navy-500 hover:text-primary-600">{isEn ? 'Terms' : 'Умови користування'}</button></li>

            </ul>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-navy-200 dark:border-navy-800 flex flex-col sm:flex-row justify-between gap-4">
          <p className="text-sm text-navy-400">© 2026 One Word Closer. {isEn ? 'All rights reserved.' : 'Усі права захищені.'}</p>
          <p className="text-xs text-navy-400">{isEn ? 'Educational materials are original training resources, not official NMT tasks.' : 'Навчальні матеріали є авторськими тренувальними ресурсами, не офіційними завданнями НМТ.'}</p>
        </div>
      </div>
    </footer>
  );
}
