import { useState } from 'react';
import {
  LayoutDashboard, BookOpen, Layers, Repeat, Trophy,
  BarChart3, Settings, LogOut, GraduationCap, Target,
  Sun, Moon, Menu, X, ClipboardCheck, Globe
} from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useI18n } from '@/context/I18nContext';
import { cn } from '@/lib/utils';

export function AppSidebar() {
  const { path, navigate } = useRouter();
  const { profile, signOut } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { lang, setLang, t } = useI18n();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { label: t('nav.dashboard'), path: '/dashboard', icon: LayoutDashboard },
    { label: t('nav.vocabulary'), path: '/vocabulary', icon: BookOpen },
    { label: t('nav.review'), path: '/review', icon: Repeat },
    { label: t('nav.trainers'), path: '/trainers', icon: Layers },
    { label: t('nav.courses'), path: '/courses-app', icon: GraduationCap },
    { label: t('nav.nmt'), path: '/nmt-prep', icon: Target },
    { label: t('nav.exam'), path: '/exam', icon: ClipboardCheck },
    { label: t('nav.analytics'), path: '/analytics', icon: BarChart3 },
    { label: t('nav.achievements'), path: '/achievements', icon: Trophy },
    { label: t('nav.settings'), path: '/settings', icon: Settings },
  ];

  const isActive = (p: string) => path === p || path.startsWith(p + '/');

  const handleNav = (to: string) => {
    navigate(to);
    setMobileOpen(false);
  };

  return (
    <>
      {/* Mobile top bar */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-40 h-16 bg-white dark:bg-navy-950 border-b border-navy-200 dark:border-navy-800 flex items-center justify-between px-4">
        <button onClick={() => setMobileOpen(true)} className="btn-ghost p-2">
          <Menu className="w-5 h-5" />
        </button>
        <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
            <GraduationCap className="w-4 h-4 text-white" />
          </div>
          <span className="font-heading font-bold text-navy-900 dark:text-white">OWC</span>
        </button>
        <button onClick={toggleTheme} className="btn-ghost p-2">
          {theme === 'light' ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
        </button>
        <button
          onClick={() => setLang(lang === 'uk' ? 'en' : 'uk')}
          className="btn-ghost p-2"
          aria-label="Switch language"
        >
          <Globe className="w-5 h-5" />
        </button>
      </div>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-navy-950/50 backdrop-blur-sm" onClick={() => setMobileOpen(false)} />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-72 bg-white dark:bg-navy-950 border-r border-navy-200 dark:border-navy-800 flex flex-col transition-transform duration-300',
          'lg:translate-x-0',
          mobileOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="h-16 flex items-center justify-between px-5 border-b border-navy-200 dark:border-navy-800">
          <button onClick={() => handleNav('/dashboard')} className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-sm">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="font-heading font-bold text-navy-900 dark:text-white text-sm leading-tight">One Word Closer</div>
              <div className="text-xs text-navy-400">{lang === 'en' ? 'Education platform' : 'Освітня платформа'}</div>
            </div>
          </button>
          <button onClick={() => setMobileOpen(false)} className="btn-ghost p-1.5 lg:hidden">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                className={cn(
                  'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all',
                  isActive(item.path)
                    ? 'bg-primary-50 dark:bg-primary-950/40 text-primary-700 dark:text-primary-300 shadow-sm'
                    : 'text-navy-600 dark:text-navy-300 hover:bg-navy-100 dark:hover:bg-navy-800/50'
                )}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-navy-200 dark:border-navy-800 space-y-2">
          <div className="flex items-center gap-3 px-3 py-2 rounded-xl bg-navy-50 dark:bg-navy-900">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center text-white text-sm font-semibold flex-shrink-0">
              {profile?.display_name?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="min-w-0 flex-1">
              <div className="text-sm font-medium text-navy-800 dark:text-navy-100 truncate">
                {profile?.display_name || 'Користувач'}
              </div>
              <div className="text-xs text-navy-400 truncate">{profile?.email}</div>
            </div>
          </div>
          <button
            onClick={() => signOut()}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-error-600 dark:text-error-400 hover:bg-error-50 dark:hover:bg-error-950/30 transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span>{t('nav.logout')}</span>
          </button>
        </div>
      </aside>
    </>
  );
}

export function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <AppSidebar />
      <main className="lg:ml-72 pt-16 lg:pt-0 min-h-screen">
        <div className="p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto animate-fade-in">
          {children}
        </div>
      </main>
    </div>
  );
}
