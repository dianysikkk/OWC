import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface ProgressRingProps {
  value: number;
  size?: number;
  strokeWidth?: number;
  className?: string;
  children?: ReactNode;
}

export function ProgressRing({ value, size = 64, strokeWidth = 6, className, children }: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (Math.min(100, value) / 100) * circumference;

  return (
    <div className={cn('relative inline-flex items-center justify-center', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={strokeWidth}
          className="stroke-navy-200 dark:stroke-navy-800"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          className="stroke-primary-500 transition-all duration-500"
          style={{ transitionProperty: 'stroke-dashoffset' }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

interface ProgressBarProps {
  value: number;
  max?: number;
  className?: string;
  barClassName?: string;
}

export function ProgressBar({ value, max = 100, className, barClassName }: ProgressBarProps) {
  const percent = Math.min(100, (value / max) * 100);
  return (
    <div className={cn('h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden', className)}>
      <div
        className={cn('h-full rounded-full bg-primary-500 transition-all duration-500', barClassName)}
        style={{ width: `${percent}%`, transitionProperty: 'width' }}
      />
    </div>
  );
}
