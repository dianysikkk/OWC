import { cn } from '@/lib/utils';

export function EmptyState({
  icon: Icon,
  title,
  description,
  action,
  className,
}: {
  icon?: React.ComponentType<{ className?: string }>;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn('flex flex-col items-center justify-center text-center py-12 px-4', className)}>
      {Icon && (
        <div className="mb-4 w-16 h-16 rounded-2xl bg-navy-100 dark:bg-navy-800 flex items-center justify-center">
          <Icon className="w-8 h-8 text-navy-400 dark:text-navy-500" />
        </div>
      )}
      <h3 className="text-base font-semibold text-navy-800 dark:text-navy-100 mb-1">{title}</h3>
      {description && <p className="text-sm text-navy-500 dark:text-navy-400 max-w-sm">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function LoadingState({ message = 'Завантаження...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="w-10 h-10 border-3 border-primary-200 dark:border-primary-800 border-t-primary-600 rounded-full animate-spin" />
      <p className="mt-3 text-sm text-navy-500 dark:text-navy-400">{message}</p>
    </div>
  );
}

export function SkeletonCard() {
  return (
    <div className="card p-5 animate-pulse">
      <div className="h-4 bg-navy-100 dark:bg-navy-800 rounded w-1/3 mb-3" />
      <div className="h-3 bg-navy-100 dark:bg-navy-800 rounded w-2/3 mb-2" />
      <div className="h-3 bg-navy-100 dark:bg-navy-800 rounded w-1/2" />
    </div>
  );
}
