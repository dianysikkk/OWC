import { createContext, useContext, useState, useCallback, ReactNode } from 'react';

type Lang = 'uk' | 'en';

interface I18nContextValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  t: (key: string, params?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nContextValue | undefined>(undefined);

const translations: Record<Lang, Record<string, string>> = {
  uk: {
    // App sidebar
    'nav.dashboard': 'Панель',
    'nav.vocabulary': 'Словник',
    'nav.review': 'Повторення',
    'nav.trainers': 'Тренажери',
    'nav.courses': 'Курси',
    'nav.nmt': 'НМТ',
    'nav.exam': 'Симулятор',
    'nav.analytics': 'Аналітика',
    'nav.achievements': 'Досягнення',
    'nav.settings': 'Налаштування',
    'nav.logout': 'Вийти',
    // Public navbar
    'nav.home': 'Головна',
    'nav.about': 'Про платформу',
    'nav.features': 'Можливості',
    'nav.coursesPublic': 'Курси',
    'nav.nmtPublic': 'НМТ',
    'nav.faq': 'FAQ',
    'nav.login': 'Увійти',
    'nav.start': 'Почати',
    'nav.cabinet': 'Кабінет',
    // Dashboard
    'dash.greetingMorning': 'Доброго ранку',
    'dash.greetingDay': 'Доброго дня',
    'dash.greetingEvening': 'Доброго вечора',
    'dash.today': 'Сьогодні',
    'dash.wordsLearned': 'Слів вивчено',
    'dash.dueReviews': 'Повторити',
    'dash.lessonsCompleted': 'завершено',
    'dash.lessons': 'Уроків',
    'dash.continueLearning': 'Продовжити навчання',
    'dash.todayPlan': 'План на сьогодні',
    'dash.weekActivity': 'Активність за тиждень',
    'dash.quickStart': 'Швидкий старт',
    'dash.repetition': 'Повторення',
    'dash.trainers': 'Тренажери',
    'dash.nmtSimulator': 'Симулятор НМТ',
    'dash.practiceTest': 'Пробний тест',
    'dash.streak': 'днів поспіль',
    'dash.achievements': 'Досягнення',
    'dash.goalsProgress': 'Мета та прогрес',
    'dash.studyCalendar': 'Календар навчання',
    'dash.all': 'Усі',
    'dash.less': 'Менше',
    'dash.more': 'Більше',
    'dash.totalWeek': 'Всього за тиждень',
    'dash.details': 'Детальніше',
    'dash.continue': 'Продовжити',
    'dash.startExercise': 'Почати вправу',
    'dash.completed': 'виконано',
    // Common
    'common.loading': 'Завантаження...',
    'common.back': 'Назад',
    'common.next': 'Далі',
    'common.finish': 'Завершити',
    'common.check': 'Перевірити',
    'common.correct': 'Правильно',
    'common.incorrect': 'Невірно',
    'common.start': 'Почати',
    'common.save': 'Зберегти',
    'common.cancel': 'Скасувати',
    'common.search': 'Пошук',
    // Trainers
    'trainers.title': 'Тренажери',
    'trainers.subtitle': 'Оберіть тип вправи для тренування',
    'trainers.flashcards': 'Флеш-карти',
    'trainers.multipleChoice': 'Вибір відповіді',
    'trainers.fillBlank': 'Заповнення пропусків',
    'trainers.spelling': 'Орфографія',
    'trainers.wordMatch': 'Зіставлення',
    'trainers.translation': 'Переклад речень',
    'trainers.grammar': 'Граматика',
    'trainers.listening': 'Аудіювання',
    'trainers.errorTrainer': 'Повторення помилок',
    'trainers.completed': 'Вправу завершено!',
    'trainers.correctAnswers': 'Правильно',
    'trainers.mistakes': 'Помилки',
    'trainers.accuracy': 'Точність',
    'trainers.otherTrainers': 'Інші тренажери',
    // Vocabulary
    'vocab.title': 'Словник',
    'vocab.searchPlaceholder': 'Пошук слова або перекладу...',
    'vocab.allCategories': 'Усі категорії',
    'vocab.allLevels': 'Усі рівні',
    'vocab.inVocab': 'У словнику',
    'vocab.add': 'Додати',
    'vocab.addToDeck': 'У набір',
    // Settings
    'settings.title': 'Налаштування',
    'settings.profile': 'Профіль',
    'settings.appearance': 'Зовнішній вигляд',
    'settings.theme': 'Тема',
    'settings.language': 'Мова інтерфейсу',
    'settings.notifications': 'Сповіщення',
    'settings.data': 'Дані та конфіденційність',
    // Exam
    'exam.title': 'Симулятор НМТ',
    'exam.start': 'Почати тест',
    'exam.finish': 'Завершити тест',
    'exam.results': 'Тест завершено!',
    'exam.review': 'Розбір помилок',
  },
  en: {
    // App sidebar
    'nav.dashboard': 'Dashboard',
    'nav.vocabulary': 'Vocabulary',
    'nav.review': 'Review',
    'nav.trainers': 'Trainers',
    'nav.courses': 'Courses',
    'nav.nmt': 'NMT',
    'nav.exam': 'Simulator',
    'nav.analytics': 'Analytics',
    'nav.achievements': 'Achievements',
    'nav.settings': 'Settings',
    'nav.logout': 'Log out',
    // Public navbar
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.features': 'Features',
    'nav.coursesPublic': 'Courses',
    'nav.nmtPublic': 'NMT',
    'nav.faq': 'FAQ',
    'nav.login': 'Log in',
    'nav.start': 'Start',
    'nav.cabinet': 'Dashboard',
    // Dashboard
    'dash.greetingMorning': 'Good morning',
    'dash.greetingDay': 'Good afternoon',
    'dash.greetingEvening': 'Good evening',
    'dash.today': 'Today',
    'dash.wordsLearned': 'Words learned',
    'dash.dueReviews': 'Review',
    'dash.lessonsCompleted': 'completed',
    'dash.lessons': 'Lessons',
    'dash.continueLearning': 'Continue learning',
    'dash.todayPlan': 'Today\'s plan',
    'dash.weekActivity': 'Week activity',
    'dash.quickStart': 'Quick start',
    'dash.repetition': 'Review',
    'dash.trainers': 'Trainers',
    'dash.nmtSimulator': 'NMT Simulator',
    'dash.practiceTest': 'Practice test',
    'dash.streak': 'days streak',
    'dash.achievements': 'Achievements',
    'dash.goalsProgress': 'Goals & progress',
    'dash.studyCalendar': 'Study calendar',
    'dash.all': 'All',
    'dash.less': 'Less',
    'dash.more': 'More',
    'dash.totalWeek': 'Total this week',
    'dash.details': 'Details',
    'dash.continue': 'Continue',
    'dash.startExercise': 'Start exercise',
    'dash.completed': 'done',
    // Common
    'common.loading': 'Loading...',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.finish': 'Finish',
    'common.check': 'Check',
    'common.correct': 'Correct',
    'common.incorrect': 'Incorrect',
    'common.start': 'Start',
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.search': 'Search',
    // Trainers
    'trainers.title': 'Trainers',
    'trainers.subtitle': 'Choose an exercise type to practice',
    'trainers.flashcards': 'Flashcards',
    'trainers.multipleChoice': 'Multiple choice',
    'trainers.fillBlank': 'Fill in the blanks',
    'trainers.spelling': 'Spelling',
    'trainers.wordMatch': 'Word match',
    'trainers.translation': 'Sentence translation',
    'trainers.grammar': 'Grammar',
    'trainers.listening': 'Listening',
    'trainers.errorTrainer': 'Error practice',
    'trainers.completed': 'Exercise completed!',
    'trainers.correctAnswers': 'Correct',
    'trainers.mistakes': 'Mistakes',
    'trainers.accuracy': 'Accuracy',
    'trainers.otherTrainers': 'Other trainers',
    // Vocabulary
    'vocab.title': 'Vocabulary',
    'vocab.searchPlaceholder': 'Search word or translation...',
    'vocab.allCategories': 'All categories',
    'vocab.allLevels': 'All levels',
    'vocab.inVocab': 'In vocabulary',
    'vocab.add': 'Add',
    'vocab.addToDeck': 'Add to deck',
    // Settings
    'settings.title': 'Settings',
    'settings.profile': 'Profile',
    'settings.appearance': 'Appearance',
    'settings.theme': 'Theme',
    'settings.language': 'Interface language',
    'settings.notifications': 'Notifications',
    'settings.data': 'Data & privacy',
    // Exam
    'exam.title': 'NMT Simulator',
    'exam.start': 'Start test',
    'exam.finish': 'Finish test',
    'exam.results': 'Test completed!',
    'exam.review': 'Answer review',
  },
};

export function I18nProvider({ children, initialLang }: { children: ReactNode; initialLang: Lang }) {
  const [lang, setLangState] = useState<Lang>(initialLang);

  const setLang = useCallback((l: Lang) => {
    setLangState(l);
  }, []);

  const t = useCallback((key: string, params?: Record<string, string | number>) => {
    let str = translations[lang][key] || translations.uk[key] || key;
    if (params) {
      for (const [k, v] of Object.entries(params)) {
        str = str.replace(new RegExp(`{${k}}`, 'g'), String(v));
      }
    }
    return str;
  }, [lang]);

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
