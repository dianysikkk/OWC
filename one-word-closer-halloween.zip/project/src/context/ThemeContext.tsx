import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { useAuth } from './AuthContext';
import { supabase } from '@/lib/supabase';

type Theme = 'light' | 'dark' | 'halloween';

const ThemeContext = createContext<{ theme: Theme; toggleTheme: () => void; setHalloweenTheme: (enabled: boolean) => void } | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const { settings, user } = useAuth();
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('theme');
      if (saved === 'dark' || saved === 'light' || saved === 'halloween') return saved;
      if (window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
    }
    return 'light';
  });

  useEffect(() => {
    if (settings?.theme) {
      setTheme(settings.theme);
    }
  }, [settings?.theme]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark' || theme === 'halloween');
    document.documentElement.classList.toggle('halloween', theme === 'halloween');
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    if (user) {
      supabase.from('user_settings').update({ theme: next }).eq('user_id', user.id).then(() => {});
    }
  };

  const setHalloweenTheme = (enabled: boolean) => {
    const next: Theme = enabled ? 'halloween' : 'light';
    setTheme(next);
    if (user) {
      supabase.from('user_settings').update({ theme: next }).eq('user_id', user.id).then(() => {});
    }
  };

  return <ThemeContext.Provider value={{ theme, toggleTheme, setHalloweenTheme }}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
