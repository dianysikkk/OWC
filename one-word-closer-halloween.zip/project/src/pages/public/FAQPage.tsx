import { useState } from 'react';
import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';

export function FAQPage() {
  const { navigate } = useRouter();
  const [open, setOpen] = useState<number | null>(0);

  const faqs = [
    { q: 'Чи безкоштовно платформа?', a: 'Так, усі навчальні функції платформи безкоштовні — словник, тренажери, повторення, тести НМТ та аналітика.' },
    { q: 'Чи це офіційна підготовка до НМТ?', a: 'Ні. Наші матеріали — авторські тренувальні ресурси. Вони не є офіційними завданнями НМТ. Походження всіх матеріалів чітко позначено.' },
    { q: 'Як працює інтервальне повторення?', a: 'Використовується алгоритм SM-2. Система відстежує ваші результати та планує повторення слів у оптимальні моменти для запам\'ятовування.' },
    { q: 'Чи зберігається мій прогрес?', a: 'Так, весь прогрес зберігається у базі даних. Ви можете продовжити з будь-якого пристрою після входу.' },
    { q: 'Чи можна змінити рівень або ціль?', a: 'Так, у налаштуваннях профілю ви можете змінити рівень, ціль та денну норму часу.' },
    { q: 'Чи є мобільна версія?', a: 'Платформа адаптована для мобільних пристроїв, планшетів та комп\'ютерів. Окремий застосунок не потрібен.' },
    { q: 'Які мови підтримує інтерфейс?', a: 'Українська та англійська. Основна мова пояснень — українська.' },
    { q: 'Що робити, якщо щось не працює?', a: 'Напишіть нам через форму підтримки на сторінці контактів. Ми відповідаємо на всі звернення.' },
    { q: 'Чи використовуєте ви мої дані для реклами?', a: 'Ні. Ми не передаємо ваші дані третім сторонам. Детально — у політиці конфіденційності.' },
  ];

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <HelpCircle className="w-12 h-12 text-primary-500 mx-auto mb-4" />
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-3">Часті запитання</h1>
          <p className="text-navy-600 dark:text-navy-300">Не знайшли відповідь? <button onClick={() => navigate('/contact')} className="text-primary-600 font-medium">Напишіть нам</button></p>
        </div>
        <div className="space-y-3">
          {faqs.map((faq, i) => (
            <div key={i} className="card overflow-hidden">
              <button onClick={() => setOpen(open === i ? null : i)} className="w-full flex items-center justify-between p-5 text-left">
                <span className="font-medium text-navy-800 dark:text-navy-100">{faq.q}</span>
                <ChevronDown className={`w-5 h-5 text-navy-400 transition-transform ${open === i ? 'rotate-180' : ''}`} />
              </button>
              {open === i && <div className="px-5 pb-5 text-sm text-navy-600 dark:text-navy-300 animate-slide-down">{faq.a}</div>}
            </div>
          ))}
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}
