import { useState, FormEvent } from 'react';
import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { Mail, MessageSquare, Send, Check, AlertCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { supabase } from '@/lib/supabase';

export function ContactPage() {
  const { user } = useAuth();
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('general');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) { setError('Увійдіть в акаунт для надсилання звернення'); return; }
    setLoading(true);
    setError('');
    const { error } = await supabase.from('support_tickets').insert({
      user_id: user.id, subject, category, message,
    });
    setLoading(false);
    if (error) setError(error.message);
    else { setSuccess(true); setSubject(''); setMessage(''); }
  };

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-3">Підтримка</h1>
          <p className="text-navy-600 dark:text-navy-300">Ми тут, щоб допомогти. Залиште своє звернення.</p>
        </div>
        <div className="card p-6">
          {success ? (
            <div className="text-center py-8">
              <div className="w-14 h-14 rounded-2xl bg-success-100 dark:bg-success-900/30 flex items-center justify-center mx-auto mb-4">
                <Check className="w-7 h-7 text-success-600" />
              </div>
              <h3 className="font-semibold text-navy-800 dark:text-navy-100 mb-2">Звернення надіслано</h3>
              <p className="text-sm text-navy-500 dark:text-navy-400 mb-4">Ми відповімо на вашу пошту найближчим часом.</p>
              <button onClick={() => setSuccess(false)} className="btn-secondary">Нове звернення</button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Тема</label>
                <input type="text" required value={subject} onChange={(e) => setSubject(e.target.value)} className="input" placeholder="Коротко опишіть проблему" />
              </div>
              <div>
                <label className="label">Категорія</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)} className="input">
                  <option value="general">Загальне</option>
                  <option value="technical">Технічне</option>
                  <option value="content">Контент</option>
                </select>
              </div>
              <div>
                <label className="label">Повідомлення</label>
                <textarea required value={message} onChange={(e) => setMessage(e.target.value)} className="input min-h-[120px] resize-y" placeholder="Детально опишіть ваше звернення" />
              </div>
              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-error-50 dark:bg-error-950/30 text-error-700 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /> {error}
                </div>
              )}
              <button type="submit" disabled={loading || !user} className="btn-primary w-full">
                {loading ? 'Надсилання...' : 'Надіслати'}
                {!loading && <Send className="w-4 h-4" />}
              </button>
              {!user && <p className="text-xs text-navy-400 text-center">Увійдіть в акаунт для надсилання звернення</p>}
            </form>
          )}
        </div>
        <div className="grid sm:grid-cols-2 gap-4 mt-6">
          <div className="card p-5 flex items-center gap-3">
            <Mail className="w-5 h-5 text-primary-500" />
            <div><div className="text-sm font-medium text-navy-700 dark:text-navy-200">Email</div><div className="text-xs text-navy-400">support@onewordcloser.edu</div></div>
          </div>
          <div className="card p-5 flex items-center gap-3">
            <MessageSquare className="w-5 h-5 text-primary-500" />
            <div><div className="text-sm font-medium text-navy-700 dark:text-navy-200">Час відповіді</div><div className="text-xs text-navy-400">Зазвичай до 24 годин</div></div>
          </div>
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}
