import { useState } from 'react';
import {
  ArrowRight, Sparkles, Brain, Repeat, Target, BarChart3,
  GraduationCap, Zap, Trophy, BookOpen, Check, ChevronDown,
  Layers, ClipboardCheck, Users, Clock, TrendingUp, Languages
} from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { ProgressBar } from '@/components/ui/Progress';

export function LandingPage() {
  const { navigate } = useRouter();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const features = [
    { icon: Brain, title: 'Розумне повторення', desc: 'Алгоритм SM-2 адаптує графік повторення слів під вашу пам\'ять. Складні слова повторюються частіше, легкі — рідше.' },
    { icon: Layers, title: '12 тренажерів', desc: 'Флеш-карти, вибір відповіді, орфографія, переклад, аудіювання, конструктор речень та інші інтерактивні вправи.' },
    { icon: Target, title: 'Підготовка до НМТ', desc: 'Повний центр підготовки: словник, граматика, читання, тренувальні тести та симулятор екзамену.' },
    { icon: BarChart3, title: 'Детальна аналітика', desc: 'Відстежуйте прогрес за навичками, часом навчання, точністю відповідей та динамікою результатів.' },
    { icon: BookOpen, title: 'Тематичний словник', desc: 'Сотні слів за 20 категоріями з прикладами, транскрипцією, синонімами та типовими помилками.' },
    { icon: Trophy, title: 'Мотивація без тиску', desc: 'Досягнення, серії днів та навчальні челенджі. Без штучного дефіциту чи маніпуляцій.' },
  ];

  const faqs = [
    { q: 'Чи безкоштовно платформа?', a: 'Так, усі навчальні функції платформи безкоштовні — словник, тренажери, повторення, тести НМТ та аналітика.' },
    { q: 'Чи це офіційна підготовка до НМТ?', a: 'Ні. Наші тренувальні матеріали є авторськими ресурсами для підготовки. Вони не є офіційними завданнями НМТ. Ми чітко позначаємо походження всіх матеріалів.' },
    { q: 'Як працює розумне повторення?', a: 'Ми використовуємо алгоритм SM-2 — науково обґрунтований метод інтервального повторення. Система враховує ваші результати та планує повторення слів у оптимальні моменти.' },
    { q: 'Чи зберігається мій прогрес?', a: 'Так, весь ваш прогрес зберігається у базі даних. Ви можете продовжити навчання з будь-якого пристрою після входу в акаунт.' },
  ];

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary-200/20 dark:bg-primary-800/10 rounded-full blur-3xl -z-0" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-accent-200/15 dark:bg-accent-800/5 rounded-full blur-3xl -z-0" />

        <div className="max-w-7xl mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              <div className="badge-primary mb-4 px-3 py-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                Новітня освітня платформа
              </div>
              <h1 className="font-heading text-4xl sm:text-5xl lg:text-6xl font-bold text-navy-900 dark:text-white leading-tight mb-6">
                Один крок ближче до{' '}
                <span className="bg-gradient-to-r from-primary-600 to-primary-400 bg-clip-text text-transparent">
                  вільної англійської
                </span>
              </h1>
              <p className="text-lg text-navy-600 dark:text-navy-300 mb-8 max-w-xl">
                Інтервальне повторення, інтерактивні тренажери, симулятор НМТ та персональна аналітика.
                Усе для того, щоб виправдати кожну витрачену хвилину.
              </p>
              <div className="flex flex-wrap gap-3">
                <button onClick={() => navigate('/register')} className="btn-primary text-base px-6 py-3">
                  Почати безкоштовно
                  <ArrowRight className="w-5 h-5" />
                </button>
                <button onClick={() => navigate('/about')} className="btn-secondary text-base px-6 py-3">
                  Дізнатися більше
                </button>
              </div>
              <div className="flex items-center gap-6 mt-8 text-sm text-navy-500 dark:text-navy-400">
                <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-success-500" /> Без кредитної картки</span>
                <span className="flex items-center gap-1.5"><Check className="w-4 h-4 text-success-500" /> Українською</span>
              </div>
            </div>

            {/* Demo card */}
            <div className="relative animate-scale-in">
              <div className="card p-6 shadow-xl">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
                      <GraduationCap className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <div className="font-semibold text-sm text-navy-800 dark:text-navy-100">Прогрес уроку</div>
                      <div className="text-xs text-navy-400">Демонстраційні дані</div>
                    </div>
                  </div>
                  <span className="badge-primary">A2 · Урок 3</span>
                </div>
                <ProgressBar value={65} className="mb-4" />
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="rounded-xl bg-navy-50 dark:bg-navy-800/50 p-3 text-center">
                    <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">42</div>
                    <div className="text-xs text-navy-400">Слів</div>
                  </div>
                  <div className="rounded-xl bg-navy-50 dark:bg-navy-800/50 p-3 text-center">
                    <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">7</div>
                    <div className="text-xs text-navy-400">Днів</div>
                  </div>
                  <div className="rounded-xl bg-navy-50 dark:bg-navy-800/50 p-3 text-center">
                    <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">85%</div>
                    <div className="text-xs text-navy-400">Точність</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-navy-600 dark:text-navy-300">
                    <Repeat className="w-4 h-4 text-primary-500" />
                    12 слів до повторення
                  </div>
                  <div className="flex items-center gap-2 text-sm text-navy-600 dark:text-navy-300">
                    <Zap className="w-4 h-4 text-accent-500" />
                    Наступний урок: Present Perfect
                  </div>
                </div>
              </div>
              <div className="absolute -top-4 -right-4 card p-3 shadow-lg animate-pulse-slow hidden sm:block">
                <div className="flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-accent-500" />
                  <span className="text-xs font-medium text-navy-700 dark:text-navy-200">Досягнення: Тиждень практики</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-navy-900 dark:text-white mb-3">
              Усе для ефективного навчання
            </h2>
            <p className="text-navy-500 dark:text-navy-400 max-w-2xl mx-auto">
              Не просто флеш-карти. Повноцінна платформа з науковим підходом до вивчення мови.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, i) => {
              const Icon = f.icon;
              return (
                <div key={i} className="card card-hover p-6">
                  <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-950/40 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                  </div>
                  <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-2">{f.title}</h3>
                  <p className="text-sm text-navy-500 dark:text-navy-400">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* NMT Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-navy-100 to-primary-50 dark:from-navy-900 dark:to-primary-950/20">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="badge-primary mb-4 px-3 py-1.5">
                <Target className="w-3.5 h-3.5" />
                Підготовка до НМТ
              </div>
              <h2 className="font-heading text-3xl sm:text-4xl font-bold text-navy-900 dark:text-white mb-4">
                Симулятор НМТ з англійської
              </h2>
              <p className="text-navy-600 dark:text-navy-300 mb-6">
                Тренувальний симулятор з таймером, навігацією між завданнями, позначкою для повернення
                та детальним розбором помилок. Словник і граматика, відібрані під формат тесту.
              </p>
              <ul className="space-y-3 mb-6">
                {['Тренувальні варіанти з таймером', 'Аналіз помилок за темами', 'Персональний календар підготовки', 'Словник для НМТ'].map((item) => (
                  <li key={item} className="flex items-center gap-2 text-navy-700 dark:text-navy-200">
                    <Check className="w-5 h-5 text-success-500" /> {item}
                  </li>
                ))}
              </ul>
              <button onClick={() => navigate('/nmt')} className="btn-primary">
                Дізнатися про НМТ-підготовку
                <ArrowRight className="w-4 h-4" />
              </button>
              <p className="text-xs text-navy-400 mt-4">
                Навчальні матеріали є авторськими тренувальними ресурсами, не офіційними завданнями НМТ.
              </p>
            </div>
            <div className="card p-6 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <ClipboardCheck className="w-5 h-5 text-primary-600" />
                  <span className="font-semibold text-navy-800 dark:text-navy-100">Тренувальний варіант №1</span>
                </div>
                <span className="badge-warning">60 хв</span>
              </div>
              <div className="grid grid-cols-5 gap-1.5 mb-4">
                {Array.from({ length: 15 }).map((_, i) => (
                  <div key={i} className={`aspect-square rounded-lg flex items-center justify-center text-xs font-medium ${
                    i < 8 ? 'bg-success-100 dark:bg-success-900/30 text-success-600' :
                    i < 11 ? 'bg-warning-100 dark:bg-warning-900/30 text-warning-600' :
                    'bg-navy-100 dark:bg-navy-800 text-navy-400'
                  }`}>
                    {i + 1}
                  </div>
                ))}
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-navy-500">Правильні:</span><span className="font-semibold text-success-600">8</span></div>
                <div className="flex justify-between"><span className="text-navy-500">Помилки:</span><span className="font-semibold text-error-500">3</span></div>
                <div className="flex justify-between"><span className="text-navy-500">Без відповіді:</span><span className="font-semibold text-navy-500">4</span></div>
                <div className="flex justify-between"><span className="text-navy-500">Тема:</span><span className="font-semibold text-navy-700 dark:text-navy-200">Present Perfect</span></div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats / social proof */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto text-center">
          <h2 className="font-heading text-3xl font-bold text-navy-900 dark:text-white mb-4">
            Створено для результату
          </h2>
          <p className="text-navy-500 dark:text-navy-400 mb-12 max-w-2xl mx-auto">
            Кожна вправа, кожне слово і кожен тест зберігаються. Ваш прогрес — не випадкові числа, а реальна статистика.
          </p>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: BookOpen, label: 'Слів у базі', value: '90+', note: 'постійно поповнюється' },
              { icon: Layers, label: 'Тренажерів', value: '9', note: 'різні типи вправ' },
              { icon: ClipboardCheck, label: 'Тестів НМТ', value: '15+', note: 'з розбором' },
              { icon: Languages, label: 'Рівні CEFR', value: '6', note: 'A1 до C2' },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <div key={i} className="card p-6">
                  <Icon className="w-8 h-8 text-primary-500 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-navy-800 dark:text-navy-100 mb-1">{s.value}</div>
                  <div className="text-sm font-medium text-navy-600 dark:text-navy-300">{s.label}</div>
                  <div className="text-xs text-navy-400 mt-1">{s.note}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="font-heading text-3xl font-bold text-navy-900 dark:text-white mb-3">
              Часті запитання
            </h2>
          </div>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="card overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-medium text-navy-800 dark:text-navy-100">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-navy-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-5 text-sm text-navy-600 dark:text-navy-300 animate-slide-down">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <button onClick={() => navigate('/faq')} className="text-primary-600 hover:text-primary-700 text-sm font-medium">
              Усі запитання →
            </button>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto card p-10 sm:p-14 text-center bg-gradient-to-br from-primary-600 to-primary-800 dark:from-primary-700 dark:to-primary-900 border-0">
          <h2 className="font-heading text-3xl sm:text-4xl font-bold text-white mb-4">
            Готові почати?
          </h2>
          <p className="text-primary-100 mb-8 max-w-xl mx-auto">
            Створіть безкоштовний акаунт і пройдіть коротке опитування.
            Ми сформуємо персональну траєкторію навчання.
          </p>
          <button onClick={() => navigate('/register')} className="btn bg-white text-primary-700 hover:bg-primary-50 text-base px-6 py-3 shadow-lg">
            Почати безкоштовно
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      <PublicFooter />
    </div>
  );
}
