import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { Brain, Layers, Repeat, BarChart3, BookOpen, Trophy, Target, Languages, Clock, ClipboardCheck, Sparkles, Check } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';

export function FeaturesPage() {
  const { navigate } = useRouter();
  const features = [
    { icon: Repeat, title: 'Інтервальне повторення (SM-2)', desc: 'Алгоритм аналізує ваші результати та будує індивідуальний графік повторення. Складні слова повертаються швидше, легкі — з більшими інтервалами.' },
    { icon: Layers, title: '12 інтерактивних тренажерів', desc: 'Флеш-карти, вибір відповіді, заповнення пропусків, переклад, орфографія, аудіювання, конструктор речень, граматика, тренажер помилок, змішана практика та швидкісний челендж.' },
    { icon: BookOpen, title: 'Тематичний словник', desc: 'Слова за 20 категоріями: від повсякденного життя до академічної лексики та слів для НМТ. Кожне слово — з транскрипцією, прикладом, синонімами та типовими помилками.' },
    { icon: Target, title: 'Центр підготовки до НМТ', desc: 'Навчальний план, лексика, граматика, читання, тренувальні завдання та повноцінний симулятор тесту з таймером і розбором помилок.' },
    { icon: BarChart3, title: 'Аналітика навчання', desc: 'Графіки активності, точність за навичками, динаміка результатів, сильні та слабкі теми. Усе на основі реальних даних.' },
    { icon: Trophy, title: 'Гейміфікація без тиску', desc: 'Досягнення, серії днів, навчальні XP. Можна вимкнути нагадування та гейміфікацію, якщо відволікає.' },
    { icon: Languages, title: 'Рівні CEFR', desc: 'Матеріали структуровані за рівнями A1–C2. Початкове оцінювання допомагає визначити ваш рівень.' },
    { icon: ClipboardCheck, title: 'Симулятор тесту', desc: 'Таймер, навігація, позначка для повернення, проміжне збереження, підрахунок балів, пояснення відповідей та історія спроб.' },
    { icon: Brain, title: 'Персональний план', desc: 'На основі цілей та доступного часу формується план на день та тиждень. Пропущений день не карається — план оновлюється.' },
    { icon: Clock, title: 'Навчальний календар', desc: 'Плануйте заняття, відстежуйте виконання, переглядайте історію активності.' },
  ];

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="badge-primary mb-4 px-3 py-1.5 inline-flex"><Sparkles className="w-3.5 h-3.5" />Можливості</div>
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-4">Усе, що потрібно для навчання</h1>
          <p className="text-lg text-navy-600 dark:text-navy-300 max-w-2xl mx-auto">
            Професійні інструменти, науковий підхід та уважний дизайн.
          </p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-12">
          {features.map((f, i) => {
            const Icon = f.icon;
            return (
              <div key={i} className="card card-hover p-6">
                <div className="w-12 h-12 rounded-xl bg-primary-50 dark:bg-primary-950/40 flex items-center justify-center mb-4">
                  <Icon className="w-6 h-6 text-primary-600 dark:text-primary-400" />
                </div>
                <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-2">{f.title}</h3>
                <p className="text-sm text-navy-500 dark:text-navy-400">{f.desc}</p>
              </div>
            );
          })}
        </div>
        <div className="card p-8 text-center bg-gradient-to-br from-primary-600 to-primary-800 border-0">
          <h2 className="font-heading text-2xl font-bold text-white mb-3">Спробуйте безкоштовно</h2>
          <p className="text-primary-100 mb-6">Без кредитної картки. Реєстрація за хвилину.</p>
          <button onClick={() => navigate('/register')} className="btn bg-white text-primary-700 hover:bg-primary-50">
            Почати
            <ArrowRightLucide />
          </button>
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}

function ArrowRightLucide() {
  return <Check className="w-4 h-4" />;
}
