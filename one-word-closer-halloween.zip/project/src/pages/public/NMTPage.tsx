import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { Target, BookOpen, ClipboardCheck, Check, ArrowRight } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';

export function NMTPage() {
  const { navigate } = useRouter();
  const sections = [
    { icon: BookOpen, title: 'Навчальний план', desc: 'Структурована програма підготовки за темами.' },
    { icon: Target, title: 'Тематичні тренування', desc: 'Вправи на граматику, лексику та читання.' },
    { icon: ClipboardCheck, title: 'Пробні тести', desc: 'Тренувальні варіанти з таймером та розбором.' },
    { icon: Check, title: 'Аналіз помилок', desc: 'Персональні рекомендації для повторення.' },
  ];

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <div className="badge-primary mb-4 px-3 py-1.5 inline-flex"><Target className="w-3.5 h-3.5" />Підготовка до НМТ</div>
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-4">
            Центр підготовки до НМТ
          </h1>
          <p className="text-lg text-navy-600 dark:text-navy-300 max-w-2xl mx-auto">
            Повноцінний центр для підготовки до Національного мультивипробування з англійської мови.
          </p>
          <p className="text-sm text-navy-400 mt-4 max-w-xl mx-auto">
            Усі тренувальні матеріали є авторськими ресурсами. Вони не є офіційними завданнями НМТ.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-8">
          {sections.map((s, i) => {
            const Icon = s.icon;
            return (
              <div key={i} className="card p-6">
                <Icon className="w-8 h-8 text-primary-500 mb-3" />
                <h3 className="font-semibold text-navy-800 dark:text-navy-100 mb-1">{s.title}</h3>
                <p className="text-sm text-navy-500 dark:text-navy-400">{s.desc}</p>
              </div>
            );
          })}
        </div>

        <div className="card p-8 bg-gradient-to-br from-primary-600 to-primary-800 border-0 text-center">
          <h2 className="font-heading text-2xl font-bold text-white mb-3">Готові почати підготовку?</h2>
          <p className="text-primary-100 mb-6">Створіть акаунт для доступу до тренувальних матеріалів та симулятора.</p>
          <button onClick={() => navigate('/register')} className="btn bg-white text-primary-700 hover:bg-primary-50">
            Почати підготовку
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}
