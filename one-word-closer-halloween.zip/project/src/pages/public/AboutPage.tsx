import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { Target, Heart, Eye, Zap, Trophy, ArrowRight, Check } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';

export function AboutPage() {
  const { navigate } = useRouter();
  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-4">Про платформу</h1>
          <p className="text-lg text-navy-600 dark:text-navy-300">
            One Word Closer — освітня платформа для вивчення англійської мови та підготовки до НМТ,
            створена з вірою, що кожне нове слово наближає до мети.
          </p>
        </div>

        <div className="card p-8 mb-6">
          <h2 className="font-heading text-xl font-semibold text-navy-800 dark:text-navy-100 mb-3">Наша місія</h2>
          <p className="text-navy-600 dark:text-navy-300 mb-4">
            Зробити якісну освіту доступною. Ми поєднуємо науково обґрунтовані методики — інтервальне
            повторення, інтерактивні вправи, детальна аналітика — у простий та приємний інструмент.
          </p>
          <p className="text-navy-600 dark:text-navy-300">
            Платформа створена для українських учнів, студентів та всіх, хто хоче покращити свою англійську.
            Основна мова пояснень — українська.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 gap-4 mb-6">
          {[
            { icon: Heart, title: 'Чесність', desc: 'Без фальшивих відгуків, вигаданих рейтингів чи маніпуляцій. Демонстраційні дані позначені явно.' },
            { icon: Target, title: 'Результат', desc: 'Кожна функція працює реально або чітко позначена як запланована. Без імітації.' },
            { icon: Eye, title: 'Прозорість', desc: 'Ви знаєте, що відбувається з вашими даними. Умови користування та конфіденційності відкриті.' },
            { icon: Zap, title: 'Ефективність', desc: 'Алгоритм SM-2 оптимізує повторення, економлячи ваш час.' },
          ].map((v, i) => {
            const Icon = v.icon;
            return (
              <div key={i} className="card p-6">
                <Icon className="w-8 h-8 text-primary-500 mb-3" />
                <h3 className="font-semibold text-navy-800 dark:text-navy-100 mb-1">{v.title}</h3>
                <p className="text-sm text-navy-500 dark:text-navy-400">{v.desc}</p>
              </div>
            );
          })}
        </div>

        <div className="card p-8">
          <h2 className="font-heading text-xl font-semibold text-navy-800 dark:text-navy-100 mb-3">Технології</h2>
          <p className="text-sm text-navy-600 dark:text-navy-300 mb-4">
            Платформа побудована на сучасному стеку: React, TypeScript, Tailwind CSS, Supabase (PostgreSQL).
            Усі дані зберігаються у надійній базі з налаштованими правами доступу (Row Level Security).
          </p>
          <button onClick={() => navigate('/register')} className="btn-primary">
            Приєднатися
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}
