import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import type { Course, Module } from '@/lib/types';
import { ArrowLeft, GraduationCap, ChevronRight, Check, X, BookOpen } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';

export function CoursesPage() {
  const { navigate } = useRouter();
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [modules, setModules] = useState<Module[]>([]);
  const [loadingModules, setLoadingModules] = useState(false);

  useEffect(() => {
    supabase.from('courses').select('*').order('sort_order').then(({ data }) => {
      setCourses(data || []);
      setLoading(false);
    });
  }, []);

  const openCourseDetail = async (course: Course) => {
    setSelectedCourse(course);
    setLoadingModules(true);
    const { data } = await supabase
      .from('modules')
      .select('*')
      .eq('course_id', course.id)
      .order('sort_order');
    setModules(data || []);
    setLoadingModules(false);
  };

  const levelColors: Record<string, string> = {
    A1: 'bg-success-100 text-success-700 dark:bg-success-900/30 dark:text-success-300',
    A2: 'bg-primary-100 text-primary-700 dark:bg-primary-900/30 dark:text-primary-300',
    B1: 'bg-warning-100 text-warning-700 dark:bg-warning-900/30 dark:text-warning-300',
    B2: 'bg-accent-100 text-accent-700 dark:bg-accent-900/30 dark:text-accent-300',
  };

  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="mb-8">
          <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-3">Каталог курсів</h1>
          <p className="text-navy-600 dark:text-navy-300">Структуровані курси за рівнями CEFR від A1 до C2. Усі курси безкоштовні.</p>
        </div>
        {loading ? (
          <div className="grid sm:grid-cols-2 gap-4">
            {[1,2,3,4].map(i => <div key={i} className="card p-6 animate-pulse h-40" />)}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-5">
            {courses.map((course) => (
              <div key={course.id} className="card card-hover p-6 cursor-pointer" onClick={() => openCourseDetail(course)}>
                <div className="flex items-start justify-between mb-3">
                  <div className="text-4xl">{course.cover_emoji}</div>
                  <span className={`badge ${levelColors[course.cefr_level] || levelColors.A1}`}>{course.cefr_level}</span>
                </div>
                <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-2">{course.title}</h3>
                <p className="text-sm text-navy-500 dark:text-navy-400 mb-4 line-clamp-2">{course.description}</p>
                <div className="flex items-center gap-1 text-primary-600 text-sm font-medium">
                  Детальніше <ChevronRight className="w-4 h-4" />
                </div>
              </div>
            ))}
          </div>
        )}
        <div className="card p-6 mt-8 text-center">
          <GraduationCap className="w-10 h-10 text-primary-500 mx-auto mb-3" />
          <p className="text-navy-600 dark:text-navy-300 mb-4">Для доступу до уроків та відстеження прогресу необхідний безкоштовний акаунт.</p>
          <button onClick={() => navigate(user ? '/courses-app' : '/register')} className="btn-primary">
            {user ? 'Перейти до навчання' : 'Зареєструватися безкоштовно'}
            <Check className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Course Detail Modal */}
      {selectedCourse && (
        <div className="fixed inset-0 z-50 bg-navy-950/50 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setSelectedCourse(null)}>
          <div className="bg-white dark:bg-navy-900 rounded-2xl shadow-xl max-w-2xl w-full max-h-[85vh] overflow-y-auto animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="sticky top-0 bg-white dark:bg-navy-900 border-b border-navy-200 dark:border-navy-800 px-6 py-4 flex items-center justify-between rounded-t-2xl">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedCourse.cover_emoji}</span>
                <div>
                  <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white">{selectedCourse.title}</h2>
                  <span className={`badge ${levelColors[selectedCourse.cefr_level] || levelColors.A1}`}>{selectedCourse.cefr_level}</span>
                </div>
              </div>
              <button onClick={() => setSelectedCourse(null)} className="btn-ghost p-2"><X className="w-5 h-5" /></button>
            </div>
            <div className="px-6 py-5 space-y-4">
              <p className="text-sm text-navy-600 dark:text-navy-300">{selectedCourse.description}</p>
              <div className="flex items-center gap-4 text-sm text-navy-400">
                <span className="flex items-center gap-1"><BookOpen className="w-4 h-4" /> {modules.length} модулів</span>
              </div>
              {loadingModules ? (
                <div className="space-y-2">
                  {[1,2,3].map(i => <div key={i} className="h-16 rounded-xl bg-navy-100 dark:bg-navy-800 animate-pulse" />)}
                </div>
              ) : modules.length > 0 ? (
                <div className="space-y-2">
                  <h3 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-200 mt-2">Модулі курсу</h3>
                  {modules.map((m, i) => (
                    <div key={m.id} className="rounded-xl border border-navy-200 dark:border-navy-800 p-4">
                      <div className="flex items-center gap-3">
                        <span className="w-7 h-7 rounded-lg bg-primary-100 dark:bg-primary-900/30 text-primary-600 flex items-center justify-center text-sm font-semibold">{i + 1}</span>
                        <div>
                          <div className="text-sm font-medium text-navy-800 dark:text-navy-100">{m.title}</div>
                          <div className="text-xs text-navy-400">Модуль {i + 1}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-navy-400">Модулі будуть додані найближчим часом.</p>
              )}
              <button
                onClick={() => { setSelectedCourse(null); navigate(user ? '/courses-app' : '/register'); }}
                className="btn-primary w-full mt-2"
              >
                {user ? 'Почати вивчення' : 'Зареєструватися для старту'}
                <ArrowLeft className="w-4 h-4 rotate-180" />
              </button>
            </div>
          </div>
        </div>
      )}

      <PublicFooter />
    </div>
  );
}
