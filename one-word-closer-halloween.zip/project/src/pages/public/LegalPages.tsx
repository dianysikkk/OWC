import { PublicNavbar, PublicFooter } from '@/components/layout/PublicLayout';

function LegalLayout({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950">
      <PublicNavbar />
      <div className="pt-32 pb-20 px-4 sm:px-6 lg:px-8 max-w-3xl mx-auto">
        <h1 className="font-heading text-4xl font-bold text-navy-900 dark:text-white mb-2">{title}</h1>
        <p className="text-sm text-navy-400 mb-8">Останнє оновлення: {updated}</p>
        <div className="card p-8 prose prose-sm dark:prose-invert max-w-none text-navy-600 dark:text-navy-300 space-y-4">
          {children}
        </div>
      </div>
      <PublicFooter />
    </div>
  );
}

export function PrivacyPage() {
  return (
    <LegalLayout title="Політика конфіденційності" updated="22 жовтня 2026">
      <p>Ця політика описує, як One Word Closer збирає, використовує та захищає ваші дані.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">1. Дані, що збираються</h2>
      <p>Ми зберігаємо: email, ім'я, налаштування профілю, навчальний прогрес, результати тестів та звернення до підтримки. Паролі зберігаються у захищеному вигляді через систему авторизації Supabase.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">2. Використання даних</h2>
      <p>Дані використовуються для надання навчальних послуг, персоналізації, аналітики та комунікації. Ми не передаємо ваші дані третім сторонам для реклами.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">3. Захист</h2>
      <p>Усі таблиці з персональними даними захищені Row Level Security. Кожен користувач має доступ лише до власних даних.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">4. Ваші права</h2>
      <p>Ви можете експортувати свої дані, змінити налаштування або видалити акаунт у налаштуваннях профілю.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">5. Безкоштовний доступ</h2>
      <p>Усі навчальні функції платформи безкоштовні. Ми не зберігаємо дані банківських карток, оскільки оплата не здійснюється.</p>
    </LegalLayout>
  );
}

export function TermsPage() {
  return (
    <LegalLayout title="Умови користування" updated="22 жовтня 2026">
      <p>Використовуючи платформу One Word Closer, ви погоджуєтесь з цими умовами.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">1. Призначення</h2>
      <p>Платформа призначена для вивчення англійської мови та підготовки до НМТ. Навчальні матеріали є авторськими тренувальними ресурсами.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">2. Акаунт</h2>
      <p>Ви несете відповідальність за збереження пароля. Заборонено створювати декілька акаунтів для обходу обмежень.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">3. Контент</h2>
      <p>Всі матеріали захищені авторським правом. Заборонено копіювати, поширювати або використовувати матеріали у комерційних цілях без дозволу.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">4. НМТ</h2>
      <p>Тренувальні матеріали не є офіційними завданнями НМТ. Результати тренувальних тестів є орієнтовними.</p>
      <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">5. Відповідальність</h2>
      <p>Платформа надається "як є". Ми не гарантуємо конкретних результатів навчання чи складання іспитів.</p>
    </LegalLayout>
  );
}

export function RefundPage() {
  return null;
}

export function NotFoundPage() {
  return (
    <div className="min-h-screen bg-navy-50 dark:bg-navy-950 flex items-center justify-center p-4">
      <div className="text-center">
        <div className="font-heading text-8xl font-bold text-primary-500 mb-4">404</div>
        <h1 className="font-heading text-2xl font-bold text-navy-800 dark:text-navy-100 mb-2">Сторінку не знайдено</h1>
        <p className="text-navy-500 dark:text-navy-400 mb-6">Можливо, сторінка була переміщена або видалена.</p>
        <button onClick={() => window.location.hash = '/'} className="btn-primary">
          На головну
        </button>
      </div>
    </div>
  );
}
