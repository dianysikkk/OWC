import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { Course, Module, Lesson, LessonProgress } from '@/lib/types';
import { LoadingState, EmptyState } from '@/components/ui/States';
import { ProgressBar } from '@/components/ui/Progress';
import {
  ChevronRight, ChevronLeft, Check, BookOpen, Clock, PlayCircle,
  PenTool, X, Lightbulb, ArrowRight, Trophy
} from 'lucide-react';

interface ExerciseWithData {
  id: string;
  title: string;
  description: string;
  questions: {
    id: string;
    question_text: string;
    correct_answer: string;
    hint: string;
    explanation: string;
    options: { id: string; option_text: string; is_correct: boolean }[];
  }[];
}

type LessonTab = 'theory' | 'exercises' | 'results';

export function CoursesAppPage() {
  const { user } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [selectedCourse, setSelectedCourse] = useState<Course | null>(null);
  const [modules, setModules] = useState<(Module & { lessons?: Lesson[] })[]>([]);
  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);
  const [progressMap, setProgressMap] = useState<Record<string, LessonProgress>>({});
  const [loading, setLoading] = useState(true);
  const [lessonTab, setLessonTab] = useState<LessonTab>('theory');
  const [exercises, setExercises] = useState<ExerciseWithData[]>([]);
  const [loadingExercises, setLoadingExercises] = useState(false);
  const [currentExerciseIdx, setCurrentExerciseIdx] = useState(0);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showHint, setShowHint] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [exerciseResults, setExerciseResults] = useState<boolean[]>([]);

  const loadCourses = useCallback(async () => {
    const { data } = await supabase.from('courses').select('*').eq('is_published', true).order('sort_order');
    if (data) setCourses(data);
    setLoading(false);
  }, []);

  const loadCourseDetail = useCallback(async (course: Course) => {
    const { data: mods } = await supabase.from('modules').select('*, lessons(*)').eq('course_id', course.id).order('sort_order');
    if (mods) setModules(mods as (Module & { lessons?: Lesson[] })[]);

    if (user) {
      const lessonIds = (mods || []).flatMap(m => (m.lessons || []).map((l: Lesson) => l.id));
      if (lessonIds.length > 0) {
        const { data: progress } = await supabase.from('lesson_progress').select('*').eq('user_id', user.id).in('lesson_id', lessonIds);
        const map: Record<string, LessonProgress> = {};
        (progress || []).forEach(p => { map[p.lesson_id] = p; });
        setProgressMap(map);
      }
    }
  }, [user]);

  const loadExercises = useCallback(async (lessonId: string) => {
    setLoadingExercises(true);
    const { data: exs } = await supabase
      .from('exercises')
      .select('id, title, description')
      .eq('lesson_id', lessonId)
      .order('created_at');

    if (!exs || exs.length === 0) {
      setExercises([]);
      setLoadingExercises(false);
      return;
    }

    const exercisesWithData: ExerciseWithData[] = [];
    for (const ex of exs) {
      const { data: qs } = await supabase
        .from('exercise_questions')
        .select('id, question_text, correct_answer, hint, explanation, sort_order')
        .eq('exercise_id', ex.id)
        .order('sort_order');

      if (!qs || qs.length === 0) continue;

      const questions = [];
      for (const q of qs) {
        const { data: opts } = await supabase
          .from('exercise_options')
          .select('id, option_text, is_correct, sort_order')
          .eq('question_id', q.id)
          .order('sort_order');

        questions.push({
          id: q.id,
          question_text: q.question_text,
          correct_answer: q.correct_answer,
          hint: q.hint || '',
          explanation: q.explanation || '',
          options: (opts || []).map(o => ({ id: o.id, option_text: o.option_text, is_correct: o.is_correct })),
        });
      }
      exercisesWithData.push({ id: ex.id, title: ex.title, description: ex.description || '', questions });
    }

    setExercises(exercisesWithData);
    setLoadingExercises(false);
  }, []);

  const startLesson = async (lesson: Lesson) => {
    if (!user) return;
    const existing = progressMap[lesson.id];
    if (!existing) {
      const { data } = await supabase.from('lesson_progress').insert({
        user_id: user.id,
        lesson_id: lesson.id,
        status: 'in_progress',
        progress_percent: 10,
        started_at: new Date().toISOString(),
      }).select().single();
      if (data) setProgressMap({ ...progressMap, [lesson.id]: data as LessonProgress });
    }
    setSelectedLesson(lesson);
    setLessonTab('theory');
    setCurrentExerciseIdx(0);
    setCurrentQuestionIdx(0);
    setSelectedAnswer(null);
    setShowHint(false);
    setShowResult(false);
    setExerciseResults([]);
    loadExercises(lesson.id);
  };

  const completeLesson = async (lesson: Lesson) => {
    if (!user) return;
    await supabase.from('lesson_progress').upsert({
      user_id: user.id,
      lesson_id: lesson.id,
      status: 'completed',
      progress_percent: 100,
      completed_at: new Date().toISOString(),
      started_at: progressMap[lesson.id]?.started_at || new Date().toISOString(),
    });
    setSelectedLesson(null);
    if (selectedCourse) loadCourseDetail(selectedCourse);
  };

  const saveExerciseAttempt = async (correctCount: number, totalQuestions: number) => {
    if (!user || exercises.length === 0) return;
    const ex = exercises[currentExerciseIdx];
    await supabase.from('exercise_attempts').insert({
      user_id: user.id,
      exercise_id: ex.id,
      score: correctCount,
      total_questions: totalQuestions,
      time_spent_seconds: 0,
    });
  };

  useEffect(() => { loadCourses(); }, [loadCourses]);

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  // Exercise results view
  if (selectedLesson && lessonTab === 'results') {
    const correctCount = exerciseResults.filter(r => r).length;
    const total = exerciseResults.length;
    const accuracy = total > 0 ? Math.round((correctCount / total) * 100) : 0;
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <div className="card p-8 text-center">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 ${
              accuracy >= 70 ? 'bg-gradient-to-br from-success-500 to-success-700' :
              accuracy >= 50 ? 'bg-gradient-to-br from-warning-500 to-warning-700' :
              'bg-gradient-to-br from-error-500 to-error-700'
            }`}>
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">Вправу завершено!</h2>
            <div className="grid grid-cols-3 gap-4 my-6">
              <div className="p-4 rounded-xl bg-success-50 dark:bg-success-950/20">
                <div className="text-2xl font-bold text-success-600">{correctCount}</div>
                <div className="text-xs text-navy-400">Правильно</div>
              </div>
              <div className="p-4 rounded-xl bg-error-50 dark:bg-error-950/20">
                <div className="text-2xl font-bold text-error-500">{total - correctCount}</div>
                <div className="text-xs text-navy-400">Помилки</div>
              </div>
              <div className="p-4 rounded-xl bg-primary-50 dark:bg-primary-950/20">
                <div className="text-2xl font-bold text-primary-600">{accuracy}%</div>
                <div className="text-xs text-navy-400">Точність</div>
              </div>
            </div>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => {
                  setLessonTab('theory');
                  setCurrentExerciseIdx(0);
                  setCurrentQuestionIdx(0);
                  setSelectedAnswer(null);
                  setShowHint(false);
                  setShowResult(false);
                  setExerciseResults([]);
                }}
                className="btn-secondary"
              >
                <BookOpen className="w-4 h-4" /> До уроку
              </button>
              <button onClick={() => completeLesson(selectedLesson)} className="btn-primary">
                <Check className="w-4 h-4" /> Завершити урок
              </button>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Exercise taking view
  if (selectedLesson && lessonTab === 'exercises' && exercises.length > 0) {
    const ex = exercises[currentExerciseIdx];
    const q = ex.questions[currentQuestionIdx];
    const isCorrect = selectedAnswer ? (q.options.find(o => o.id === selectedAnswer)?.is_correct ?? false) : false;

    const handleNext = () => {
      const newResults = [...exerciseResults, isCorrect];
      setExerciseResults(newResults);

      if (currentQuestionIdx + 1 < ex.questions.length) {
        setCurrentQuestionIdx(currentQuestionIdx + 1);
        setSelectedAnswer(null);
        setShowHint(false);
        setShowResult(false);
      } else if (currentExerciseIdx + 1 < exercises.length) {
        saveExerciseAttempt(newResults.filter(r => r).length, newResults.length);
        setCurrentExerciseIdx(currentExerciseIdx + 1);
        setCurrentQuestionIdx(0);
        setSelectedAnswer(null);
        setShowHint(false);
        setShowResult(false);
        setExerciseResults([]);
      } else {
        saveExerciseAttempt(newResults.filter(r => r).length, newResults.length);
        setExerciseResults(newResults);
        setLessonTab('results');
      }
    };

    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <button onClick={() => setLessonTab('theory')} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> До теорії
          </button>

          {/* Progress */}
          <div className="mb-4">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-navy-600 dark:text-navy-300 font-medium">{ex.title}</span>
              <span className="text-navy-400">
                Вправа {currentExerciseIdx + 1}/{exercises.length} · Питання {currentQuestionIdx + 1}/{ex.questions.length}
              </span>
            </div>
            <ProgressBar value={currentQuestionIdx} max={ex.questions.length} />
          </div>

          {/* Question */}
          <div className="card p-6 mb-4">
            <p className="text-lg text-navy-800 dark:text-navy-100 mb-6">{q.question_text}</p>
            <div className="space-y-2">
              {q.options.map((opt) => {
                const isSelected = selectedAnswer === opt.id;
                const showCorrect = showResult && opt.is_correct;
                const showWrong = showResult && isSelected && !opt.is_correct;
                return (
                  <button
                    key={opt.id}
                    onClick={() => { if (!showResult) setSelectedAnswer(opt.id); }}
                    disabled={showResult}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                      showCorrect ? 'border-success-500 bg-success-50 dark:bg-success-950/20' :
                      showWrong ? 'border-error-500 bg-error-50 dark:bg-error-950/20' :
                      isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                      'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                      showCorrect ? 'bg-success-500 text-white' :
                      showWrong ? 'bg-error-500 text-white' :
                      isSelected ? 'bg-primary-500 text-white' : 'bg-navy-100 dark:bg-navy-800 text-navy-500'
                    }`}>
                      {showCorrect ? <Check className="w-4 h-4" /> : showWrong ? <X className="w-4 h-4" /> : String.fromCharCode(65 + q.options.indexOf(opt))}
                    </span>
                    <span className="text-sm text-navy-700 dark:text-navy-200">{opt.option_text}</span>
                  </button>
                );
              })}
            </div>

            {/* Hint */}
            {showHint && !showResult && q.hint && (
              <div className="mt-4 p-3 rounded-xl bg-warning-50 dark:bg-warning-950/20 flex items-start gap-2">
                <Lightbulb className="w-4 h-4 text-warning-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-navy-600 dark:text-navy-300">{q.hint}</p>
              </div>
            )}

            {/* Explanation after answer */}
            {showResult && (
              <div className={`mt-4 p-4 rounded-xl ${isCorrect ? 'bg-success-50 dark:bg-success-950/20' : 'bg-error-50 dark:bg-error-950/20'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {isCorrect ? <Check className="w-5 h-5 text-success-600" /> : <X className="w-5 h-5 text-error-500" />}
                  <span className={`font-medium ${isCorrect ? 'text-success-600' : 'text-error-500'}`}>
                    {isCorrect ? 'Правильно!' : 'Невірно'}
                  </span>
                </div>
                {q.explanation && <p className="text-sm text-navy-600 dark:text-navy-300">{q.explanation}</p>}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex gap-2">
              {!showResult && q.hint && (
                <button onClick={() => setShowHint(!showHint)} className="btn-secondary">
                  <Lightbulb className="w-4 h-4" /> {showHint ? 'Сховати' : 'Підказка'}
                </button>
              )}
            </div>
            {!showResult ? (
              <button
                onClick={() => setShowResult(true)}
                disabled={!selectedAnswer}
                className="btn-primary"
              >
                Перевірити <Check className="w-4 h-4" />
              </button>
            ) : (
              <button onClick={handleNext} className="btn-primary">
                {currentQuestionIdx + 1 >= ex.questions.length && currentExerciseIdx + 1 >= exercises.length
                  ? 'Завершити' : 'Далі'}
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </AppLayout>
    );
  }

  // Lesson view (theory + exercise tabs)
  if (selectedLesson) {
    const hasExercises = exercises.length > 0;
    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          <button onClick={() => setSelectedLesson(null)} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> Назад до курсу
          </button>
          <div className="card p-8">
            <div className="flex items-center gap-2 mb-4">
              <span className="badge-primary">{selectedCourse?.cefr_level}</span>
              <span className="badge-neutral"><Clock className="w-3 h-3" /> {selectedLesson.estimated_minutes} хв</span>
            </div>
            <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-4">{selectedLesson.title}</h1>

            {/* Tabs */}
            {hasExercises && (
              <div className="flex gap-1 p-1 rounded-xl bg-navy-100 dark:bg-navy-800 mb-6">
                <button
                  onClick={() => setLessonTab('theory')}
                  className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    lessonTab === 'theory' ? 'bg-white dark:bg-navy-700 text-navy-800 dark:text-navy-100 shadow-sm' : 'text-navy-500'
                  }`}
                >
                  <BookOpen className="w-4 h-4 inline mr-1" /> Теорія
                </button>
                <button
                  onClick={() => setLessonTab('exercises')}
                  className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    lessonTab === 'exercises' ? 'bg-white dark:bg-navy-700 text-navy-800 dark:text-navy-100 shadow-sm' : 'text-navy-500'
                  }`}
                >
                  <PenTool className="w-4 h-4 inline mr-1" /> Вправи ({exercises.length})
                </button>
              </div>
            )}

            {lessonTab === 'theory' || !hasExercises ? (
              <>
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <p className="text-navy-600 dark:text-navy-300 whitespace-pre-wrap leading-relaxed">{selectedLesson.content}</p>
                </div>
                <div className="flex flex-wrap justify-end gap-2 mt-8 pt-6 border-t border-navy-200 dark:border-navy-800">
                  {hasExercises && (
                    <button onClick={() => setLessonTab('exercises')} className="btn-secondary">
                      <PenTool className="w-4 h-4" /> Практичні вправи
                    </button>
                  )}
                  <button onClick={() => completeLesson(selectedLesson)} className="btn-primary">
                    <Check className="w-4 h-4" /> Завершити урок
                  </button>
                </div>
              </>
            ) : loadingExercises ? (
              <LoadingState />
            ) : (
              <EmptyState icon={PenTool} title="Вправи завантажуються..." />
            )}
          </div>
        </div>
      </AppLayout>
    );
  }

  // Course detail view
  if (selectedCourse) {
    const totalLessons = modules.reduce((sum, m) => sum + (m.lessons?.length || 0), 0);
    const completedLessons = Object.values(progressMap).filter(p => p.status === 'completed').length;
    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          <button onClick={() => { setSelectedCourse(null); setModules([]); }} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> Усі курси
          </button>
          <div className="card p-6 mb-6">
            <div className="flex items-start gap-4">
              <div className="text-5xl">{selectedCourse.cover_emoji}</div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white">{selectedCourse.title}</h1>
                  <span className="badge-primary">{selectedCourse.cefr_level}</span>
                </div>
                <p className="text-sm text-navy-500 dark:text-navy-400 mb-3">{selectedCourse.description}</p>
                <div className="flex items-center gap-3">
                  <ProgressBar value={completedLessons} max={totalLessons} className="flex-1" />
                  <span className="text-sm text-navy-500">{completedLessons}/{totalLessons}</span>
                </div>
              </div>
            </div>
          </div>

          {modules.map((mod, mi) => (
            <div key={mod.id} className="mb-6">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-3">
                {mi + 1}. {mod.title}
              </h2>
              <div className="space-y-2">
                {(mod.lessons || []).sort((a, b) => a.sort_order - b.sort_order).map((lesson, li) => {
                  const prog = progressMap[lesson.id];
                  const isCompleted = prog?.status === 'completed';
                  const isInProgress = prog?.status === 'in_progress';
                  return (
                    <button
                      key={lesson.id}
                      onClick={() => startLesson(lesson)}
                      className="w-full flex items-center gap-3 p-4 rounded-xl card card-hover text-left"
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        isCompleted ? 'bg-success-100 dark:bg-success-900/30 text-success-600' :
                        isInProgress ? 'bg-primary-100 dark:bg-primary-900/30 text-primary-600' :
                        'bg-navy-100 dark:bg-navy-800 text-navy-400'
                      }`}>
                        {isCompleted ? <Check className="w-5 h-5" /> : <PlayCircle className="w-5 h-5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className={`text-sm font-medium ${isCompleted ? 'text-navy-500' : 'text-navy-800 dark:text-navy-100'}`}>
                          {mi + 1}.{li + 1} {lesson.title}
                        </div>
                        <div className="text-xs text-navy-400">{lesson.lesson_type} · {lesson.estimated_minutes} хв</div>
                      </div>
                      {isInProgress && <ProgressBar value={prog?.progress_percent || 0} className="w-20" />}
                      <ChevronRight className="w-5 h-5 text-navy-300 flex-shrink-0" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}

          {modules.length === 0 && <EmptyState icon={BookOpen} title="Модулів ще немає" description="Курс у процесі наповнення" />}
        </div>
      </AppLayout>
    );
  }

  // Course list
  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Курси</h1>
        <p className="text-sm text-navy-500 dark:text-navy-400">Структуровані курси за рівнями CEFR</p>
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        {courses.map((course) => (
          <button key={course.id} onClick={() => { setSelectedCourse(course); loadCourseDetail(course); }} className="card card-hover p-6 text-left">
            <div className="flex items-start justify-between mb-3">
              <div className="text-4xl">{course.cover_emoji}</div>
              <span className="badge-primary">{course.cefr_level}</span>
            </div>
            <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-1">{course.title}</h3>
            <p className="text-sm text-navy-500 dark:text-navy-400 line-clamp-2">{course.description}</p>
          </button>
        ))}
      </div>
    </AppLayout>
  );
}
