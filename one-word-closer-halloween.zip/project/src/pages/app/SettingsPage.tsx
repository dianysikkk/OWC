import { useState, FormEvent } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useTheme } from '@/context/ThemeContext';
import { useI18n } from '@/context/I18nContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { Modal } from '@/components/ui/Modal';
import {
  Settings, User, Palette, Bell, Shield, Download,
  Check, AlertCircle, Sun, Moon, Globe, LogOut, Ghost
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import type { UserSettings } from '@/lib/types';

export function SettingsPage() {
  const { user, profile, settings, updateProfile, updateSettings, signOut } = useAuth();
  const { theme, toggleTheme, setHalloweenTheme } = useTheme();
  const { lang, setLang } = useI18n();
  const [name, setName] = useState(profile?.display_name || '');
  const [bio, setBio] = useState(profile?.bio || '');
  const [dailyGoal, setDailyGoal] = useState(profile?.daily_goal_minutes || 15);
  const [currentLevel, setCurrentLevel] = useState(profile?.current_level || 'A1');
  const [targetLevel, setTargetLevel] = useState(profile?.target_level || 'B1');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState('');
  const [showDelete, setShowDelete] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState('');

  const handleSaveProfile = async (e: FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    const { error } = await updateProfile({
      display_name: name,
      bio,
      daily_goal_minutes: dailyGoal,
      current_level: currentLevel,
      target_level: targetLevel,
    });
    setSaving(false);
    if (error) setError(error);
    else { setSaved(true); setTimeout(() => setSaved(false), 2000); }
  };

  const handleSettingToggle = async (key: keyof UserSettings, value: boolean) => {
    if (!settings) return;
    await updateSettings({ [key]: value });
  };

  const handleLanguageChange = async (l: 'uk' | 'en') => {
    setLang(l);
    await updateSettings({ interface_language: l });
  };

  const handleExport = async () => {
    if (!user) return;
    const [p, uv, ss, ea, xa] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).maybeSingle(),
      supabase.from('user_vocabulary').select('*, vocabulary:vocabulary(word, translation_uk)').eq('user_id', user.id),
      supabase.from('study_sessions').select('*').eq('user_id', user.id).order('created_at', { ascending: false }),
      supabase.from('exercise_attempts').select('*').eq('user_id', user.id).order('completed_at', { ascending: false }),
      supabase.from('exam_attempts').select('*').eq('user_id', user.id).order('started_at', { ascending: false }),
    ]);
    const data = {
      profile: p.data,
      vocabulary: uv.data,
      studySessions: ss.data,
      exerciseAttempts: ea.data,
      examAttempts: xa.data,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `owc-data-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDeleteAccount = async () => {
    if (!user || deleteConfirm !== 'ВИДАЛИТИ') return;
    await supabase.from('profiles').delete().eq('id', user.id);
    await supabase.auth.signOut();
    window.location.hash = '/';
  };

  const levels = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Налаштування</h1>
        <p className="text-sm text-navy-500 dark:text-navy-400">Керуйте профілем та вподобаннями</p>
      </div>

      <div className="space-y-6 max-w-3xl">
        {/* Profile */}
        <form onSubmit={handleSaveProfile} className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <User className="w-5 h-5 text-primary-500" />
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">Профіль</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="label">Ім'я</label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input" />
            </div>
            <div>
              <label className="label">Email</label>
              <input type="email" value={profile?.email || ''} disabled className="input opacity-60" />
            </div>
            <div>
              <label className="label">Про себе</label>
              <textarea value={bio} onChange={(e) => setBio(e.target.value)} className="input min-h-[80px] resize-y" placeholder="Кілька слів про себе" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Поточний рівень</label>
                <select value={currentLevel} onChange={(e) => setCurrentLevel(e.target.value)} className="input">
                  {levels.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label className="label">Цільовий рівень</label>
                <select value={targetLevel} onChange={(e) => setTargetLevel(e.target.value)} className="input">
                  {levels.map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
            </div>
            <div>
              <label className="label">Денна ціль (хвилин)</label>
              <div className="flex gap-2">
                {[10, 15, 30, 45, 60].map(m => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setDailyGoal(m)}
                    className={`flex-1 p-2 rounded-xl border-2 text-sm font-medium transition-all ${
                      dailyGoal === m ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30 text-primary-700' : 'border-navy-200 dark:border-navy-800 text-navy-500'
                    }`}
                  >
                    {m}хв
                  </button>
                ))}
              </div>
            </div>
            {error && <p className="text-sm text-error-500 flex items-center gap-1"><AlertCircle className="w-4 h-4" /> {error}</p>}
            <div className="flex items-center gap-3">
              <button type="submit" disabled={saving} className="btn-primary">
                {saving ? 'Збереження...' : 'Зберегти'}
                {saved && <Check className="w-4 h-4" />}
              </button>
              {saved && <span className="text-sm text-success-600">Збережено!</span>}
            </div>
          </div>
        </form>

        {/* Appearance */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Palette className="w-5 h-5 text-primary-500" />
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">Зовнішній вигляд</h2>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-navy-700 dark:text-navy-200">Тема</div>
                <div className="text-xs text-navy-400">Світла, темна або святкова Halloween</div>
              </div>
              <button onClick={toggleTheme} className="btn-secondary">
                {theme === 'light' ? <><Sun className="w-4 h-4" /> Світла</> : theme === 'halloween' ? <><Ghost className="w-4 h-4" /> Halloween</> : <><Moon className="w-4 h-4" /> Темна</>}
              </button>
              <button onClick={() => setHalloweenTheme(theme !== 'halloween')} className={`btn-secondary ${theme === 'halloween' ? 'halloween-theme-active' : ''}`} aria-pressed={theme === 'halloween'}>
                <Ghost className="w-4 h-4" /> {theme === 'halloween' ? 'Вимкнути Halloween' : 'Halloween 🎃'}
              </button>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm font-medium text-navy-700 dark:text-navy-200">Мова інтерфейсу</div>
                <div className="text-xs text-navy-400">Укранська або English</div>
              </div>
              <div className="flex gap-1 p-1 rounded-xl bg-navy-100 dark:bg-navy-800">
                {(['uk', 'en'] as const).map(l => (
                  <button
                    key={l}
                    onClick={() => handleLanguageChange(l)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                      lang === l ? 'bg-white dark:bg-navy-700 text-navy-800 dark:text-navy-100 shadow-sm' : 'text-navy-500'
                    }`}
                  >
                    <Globe className="w-3 h-3 inline mr-1" />
                    {l === 'uk' ? 'Укр' : 'Eng'}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Notifications */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Bell className="w-5 h-5 text-primary-500" />
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">Сповіщення</h2>
          </div>
          <div className="space-y-3">
            {[
              { key: 'notification_reviews' as const, label: 'Нагадування про повторення слів', desc: 'Сповіщення, коли слова готові до повторення' },
              { key: 'notification_lessons' as const, label: 'Нагадування про уроки', desc: 'Нагадування продовжити навчання' },
              { key: 'notification_marketing' as const, label: 'Маркетингові повідомлення', desc: 'Новини та акції платформи' },
              { key: 'gamification_enabled' as const, label: 'Гейміфікація', desc: 'Серії днів, XP та досягнення' },
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{item.label}</div>
                  <div className="text-xs text-navy-400">{item.desc}</div>
                </div>
                <button
                  onClick={() => handleSettingToggle(item.key, !(settings?.[item.key] ?? false))}
                  className={`relative w-12 h-6 rounded-full transition-colors ${
                    (settings?.[item.key] ?? false) ? 'bg-primary-500' : 'bg-navy-300 dark:bg-navy-700'
                  }`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                    (settings?.[item.key] ?? false) ? 'left-6' : 'left-0.5'
                  }`} />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Data & Privacy */}
        <div className="card p-6">
          <div className="flex items-center gap-2 mb-4">
            <Shield className="w-5 h-5 text-primary-500" />
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">Дані та конфіденційність</h2>
          </div>
          <div className="space-y-3">
            <button onClick={handleExport} className="w-full flex items-center justify-between p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40 hover:bg-navy-100 dark:hover:bg-navy-800/60 transition-colors">
              <div className="flex items-center gap-3">
                <Download className="w-5 h-5 text-primary-500" />
                <div className="text-left">
                  <div className="text-sm font-medium text-navy-700 dark:text-navy-200">Експорт даних</div>
                  <div className="text-xs text-navy-400">Завантажити всі ваші навчальні дані</div>
                </div>
              </div>
            </button>
            <button
              onClick={() => setShowDelete(true)}
              className="w-full flex items-center justify-between p-3 rounded-xl bg-error-50 dark:bg-error-950/20 hover:bg-error-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <LogOut className="w-5 h-5 text-error-500" />
                <div className="text-left">
                  <div className="text-sm font-medium text-error-600 dark:text-error-400">Видалити акаунт</div>
                  <div className="text-xs text-navy-400">Безповоротне видалення всіх даних</div>
                </div>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Delete modal */}
      <Modal open={showDelete} onClose={() => setShowDelete(false)} title="Видалення акаунта" size="sm">
        <div className="space-y-4">
          <div className="p-4 rounded-xl bg-error-50 dark:bg-error-950/20">
            <AlertCircle className="w-6 h-6 text-error-500 mb-2" />
            <p className="text-sm text-navy-600 dark:text-navy-300">
              Це видалить ваш профіль, навчальний прогрес, словник та всі дані без можливості відновлення.
            </p>
          </div>
          <div>
            <label className="label">Введіть ВИДАЛИТИ для підтвердження</label>
            <input
              type="text"
              value={deleteConfirm}
              onChange={(e) => setDeleteConfirm(e.target.value)}
              className="input"
              placeholder="ВИДАЛИТИ"
            />
          </div>
          <div className="flex gap-2">
            <button onClick={() => setShowDelete(false)} className="btn-secondary flex-1">Скасувати</button>
            <button
              onClick={handleDeleteAccount}
              disabled={deleteConfirm !== 'ВИДАЛИТИ'}
              className="btn bg-error-500 text-white hover:bg-error-600 flex-1"
            >
              Видалити
            </button>
          </div>
        </div>
      </Modal>
    </AppLayout>
  );
}
