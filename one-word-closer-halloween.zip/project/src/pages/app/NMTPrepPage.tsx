import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { Course, Module, Lesson, LessonProgress } from '@/lib/types';
import { LoadingState, EmptyState } from '@/components/ui/States';
import { Target, BookOpen, ClipboardCheck, ChevronRight, ChevronLeft, Check, Clock, Repeat, BarChart3, AlertCircle } from 'lucide-react';

export function NMTPrepPage() {
  const { user } = useAuth();
  const { navigate } = useRouter();
  const [course, setCourse] = useState<Course | null>(null);
  const [modules, setModules] = useState<(Module & { lessons?: Lesson[] })[]>([]);
  const [progressMap, setProgressMap] = useState<Record<string, LessonProgress>>({});
  const [examCount, setExamCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    const { data: courses } = await supabase.from('courses').select('*').eq('title', 'Підготовка до НМТ').maybeSingle();
    if (courses) {
      setCourse(courses as Course);
      const { data: mods } = await supabase.from('modules').select('*, lessons(*)').eq('course_id', courses.id).order('sort_order');
      if (mods) setModules(mods as (Module & { lessons?: Lesson[] })[]);

      if (user) {
        const lessonIds = (mods || []).flatMap(m => (m.lessons || []).map((l: Lesson) => l.id));
        if (lessonIds.length > 0) {
          const { data: prog } = await supabase.from('lesson_progress').select('*').eq('user_id', user.id).in('lesson_id', lessonIds);
          const map: Record<string, LessonProgress> = {};
          (prog || []).forEach(p => { map[p.lesson_id] = p; });
          setProgressMap(map);
        }
        const { count } = await supabase.from('exam_attempts').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('status', 'completed');
        setExamCount(count || 0);
      }
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  const [selectedLesson, setSelectedLesson] = useState<Lesson | null>(null);

  const startLesson = async (lesson: Lesson) => {
    if (!user) return;
    if (!progressMap[lesson.id]) {
      const { data } = await supabase.from('lesson_progress').insert({
        user_id: user.id, lesson_id: lesson.id, status: 'in_progress', progress_percent: 10, started_at: new Date().toISOString(),
      }).select().single();
      if (data) setProgressMap({ ...progressMap, [lesson.id]: data as LessonProgress });
    }
    setSelectedLesson(lesson);
  };

  const completeLesson = async (lesson: Lesson) => {
    if (!user) return;
    await supabase.from('lesson_progress').upsert({
      user_id: user.id, lesson_id: lesson.id, status: 'completed', progress_percent: 100,
      completed_at: new Date().toISOString(), started_at: progressMap[lesson.id]?.started_at || new Date().toISOString(),
    });
    setSelectedLesson(null);
    loadData();
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  if (selectedLesson) {
    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          <button onClick={() => setSelectedLesson(null)} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> Назад
          </button>
          <div className="card p-8">
            <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-4">{selectedLesson.title}</h1>
            <p className="text-navy-600 dark:text-navy-300 whitespace-pre-wrap leading-relaxed">{selectedLesson.content}</p>
            <div className="flex justify-end mt-8 pt-6 border-t border-navy-200 dark:border-navy-800">
              <button onClick={() => completeLesson(selectedLesson)} className="btn-primary">
                <Check className="w-4 h-4" /> Завершити
              </button>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  const totalLessons = modules.reduce((sum, m) => sum + (m.lessons?.length || 0), 0);
  const completedLessons = Object.values(progressMap).filter(p => p.status === 'completed').length;

  const sections = [
    { icon: ClipboardCheck, title: 'Пробні тести', desc: 'Симулятор НМТ з таймером та розбором', action: () => navigate('/exam'), bgClass: 'bg-error-50 dark:bg-error-950/30', textClass: 'text-error-600 dark:text-error-400' },
    { icon: BookOpen, title: 'Словник для НМТ', desc: 'Слова, відібрані під формат тесту', action: () => navigate('/vocabulary'), bgClass: 'bg-primary-50 dark:bg-primary-950/30', textClass: 'text-primary-600 dark:text-primary-400' },
    { icon: Repeat, title: 'Повторення', desc: 'Інтервальне повторення слів', action: () => navigate('/review'), bgClass: 'bg-warning-50 dark:bg-warning-950/30', textClass: 'text-warning-600 dark:text-warning-400' },
    { icon: BarChart3, title: 'Мої результати', desc: 'Аналітика та прогрес', action: () => navigate('/analytics'), bgClass: 'bg-success-50 dark:bg-success-950/30', textClass: 'text-success-600 dark:text-success-400' },
  ];

  return (
    <AppLayout>
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-1">
          <Target className="w-6 h-6 text-primary-500" />
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white">Підготовка до НМТ</h1>
        </div>
        <p className="text-sm text-navy-500 dark:text-navy-400">
          Навчальні матеріали є авторськими тренувальними ресурсами, не офіційними завданнями НМТ.
        </p>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{completedLessons}/{totalLessons}</div>
          <div className="text-xs text-navy-400">Уроків</div>
        </div>
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{examCount}</div>
          <div className="text-xs text-navy-400">Тестів пройдено</div>
        </div>
        <div className="card p-4 text-center">
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{modules.length}</div>
          <div className="text-xs text-navy-400">Розділів</div>
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
        {sections.map((s, i) => {
          const Icon = s.icon;
          return (
            <button key={i} onClick={s.action} className="card card-hover p-4 text-center">
              <div className={`w-10 h-10 rounded-xl ${s.bgClass} flex items-center justify-center mx-auto mb-2`}>
                <Icon className={`w-5 h-5 ${s.textClass}`} />
              </div>
              <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{s.title}</div>
              <div className="text-xs text-navy-400 mt-1 hidden sm:block">{s.desc}</div>
            </button>
          );
        })}
      </div>

      {/* Course modules */}
      {course ? (
        <div>
          <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-3">Навчальний план</h2>
          {modules.map((mod, mi) => (
            <div key={mod.id} className="mb-6">
              <h3 className="font-medium text-navy-700 dark:text-navy-200 mb-2">{mi + 1}. {mod.title}</h3>
              <div className="space-y-2">
                {(mod.lessons || []).sort((a, b) => a.sort_order - b.sort_order).map((lesson, li) => {
                  const prog = progressMap[lesson.id];
                  const isCompleted = prog?.status === 'completed';
                  return (
                    <button key={lesson.id} onClick={() => startLesson(lesson)} className="w-full flex items-center gap-3 p-3 rounded-xl card card-hover text-left">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                        isCompleted ? 'bg-success-100 dark:bg-success-900/30 text-success-600' : 'bg-navy-100 dark:bg-navy-800 text-navy-400'
                      }`}>
                        {isCompleted ? <Check className="w-4 h-4" /> : <span className="text-xs">{li + 1}</span>}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{lesson.title}</div>
                        <div className="text-xs text-navy-400">{lesson.estimated_minutes} хв</div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-navy-300" />
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          {modules.length === 0 && <EmptyState icon={BookOpen} title="Розділи готуються" description="Контент буде додано скоро" />}
        </div>
      ) : (
        <EmptyState icon={AlertCircle} title="Курс НМТ не знайдено" description="Зверніться до підтримки" />
      )}
    </AppLayout>
  );
}
