import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { StudySession, ExerciseAttempt, ExamAttempt } from '@/lib/types';
import { LoadingState, EmptyState } from '@/components/ui/States';
import { BarChart3, Clock, BookOpen, Check, TrendingUp, Target, Award, ClipboardCheck, Repeat } from 'lucide-react';
import { formatMinutes, calculateAccuracy } from '@/lib/utils';

export function AnalyticsPage() {
  const { user, profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [exerciseAttempts, setExerciseAttempts] = useState<ExerciseAttempt[]>([]);
  const [examAttempts, setExamAttempts] = useState<ExamAttempt[]>([]);
  const [period, setPeriod] = useState<'week' | 'month' | 'all'>('week');

  const loadData = useCallback(async () => {
    if (!user) return;
    const days = period === 'week' ? 7 : period === 'month' ? 30 : 365;
    const since = new Date(Date.now() - days * 86400000).toISOString().split('T')[0];

    const [ss, ea, xa] = await Promise.all([
      supabase.from('study_sessions').select('*').eq('user_id', user.id).gte('studied_at', since).order('created_at', { ascending: false }),
      supabase.from('exercise_attempts').select('*').eq('user_id', user.id).gte('completed_at', since).order('completed_at', { ascending: false }),
      supabase.from('exam_attempts').select('*').eq('user_id', user.id).eq('status', 'completed').order('completed_at', { ascending: false }),
    ]);

    setSessions(ss.data || []);
    setExerciseAttempts(ea.data || []);
    setExamAttempts(xa.data || []);
    setLoading(false);
  }, [user, period]);

  useEffect(() => { loadData(); }, [loadData]);

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  const totalTime = sessions.reduce((sum, s) => sum + s.duration_seconds, 0);
  const totalItems = sessions.reduce((sum, s) => sum + s.items_studied, 0);
  const totalCorrect = sessions.reduce((sum, s) => sum + s.items_correct, 0);
  const accuracy = calculateAccuracy(totalCorrect, totalItems);

  // Activity chart data
  const days = period === 'week' ? 7 : period === 'month' ? 30 : 30;
  const chartData: { date: string; minutes: number; items: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000).toISOString().split('T')[0];
    const daySessions = sessions.filter(s => s.studied_at === d);
    chartData.push({
      date: d,
      minutes: Math.round(daySessions.reduce((sum, s) => sum + s.duration_seconds, 0) / 60),
      items: daySessions.reduce((sum, s) => sum + s.items_studied, 0),
    });
  }
  const maxMinutes = Math.max(...chartData.map(d => d.minutes), 1);

  // Session type breakdown
  const typeMap: Record<string, { count: number; correct: number; items: number }> = {};
  sessions.forEach(s => {
    if (!typeMap[s.session_type]) typeMap[s.session_type] = { count: 0, correct: 0, items: 0 };
    typeMap[s.session_type].count++;
    typeMap[s.session_type].correct += s.items_correct;
    typeMap[s.session_type].items += s.items_studied;
  });

  const typeLabels: Record<string, string> = {
    vocabulary_review: 'Повторення слів',
    trainer_flashcards: 'Флеш-карти',
    trainer_multiple_choice: 'Вибір відповіді',
    trainer_fill_blank: 'Заповнення пропусків',
    trainer_spelling: 'Орфографія',
    trainer_word_match: 'Зіставлення',
    trainer_translation: 'Переклад речень',
    trainer_grammar: 'Граматика',
    trainer_listening: 'Аудіювання',
    trainer_error: 'Повторення помилок',
    exam: 'Тест НМТ',
    reading: 'Читання',
    listening: 'Аудіювання',
    grammar: 'Граматика',
  };

  const hasData = sessions.length > 0;

  return (
    <AppLayout>
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Аналітика</h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">Ваш навчальний прогрес</p>
        </div>
        <div className="flex gap-1 p-1 rounded-xl bg-navy-100 dark:bg-navy-800">
          {(['week', 'month', 'all'] as const).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                period === p ? 'bg-white dark:bg-navy-700 text-navy-800 dark:text-navy-100 shadow-sm' : 'text-navy-500'
              }`}
            >
              {p === 'week' ? 'Тиждень' : p === 'month' ? 'Місяць' : 'Усе'}
            </button>
          ))}
        </div>
      </div>

      {!hasData ? (
        <EmptyState
          icon={BarChart3}
          title="Поки немає даних"
          description="Почніть навчання — пройдіть вправу або повторіть слова, і тут з'явиться ваша статистика"
        />
      ) : (
        <>
          {/* Summary cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="card p-5">
              <Clock className="w-5 h-5 text-primary-500 mb-2" />
              <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{formatMinutes(Math.round(totalTime / 60))}</div>
              <div className="text-xs text-navy-400">час навчання</div>
            </div>
            <div className="card p-5">
              <BookOpen className="w-5 h-5 text-primary-500 mb-2" />
              <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{totalItems}</div>
              <div className="text-xs text-navy-400">вправ виконано</div>
            </div>
            <div className="card p-5">
              <Target className="w-5 h-5 text-primary-500 mb-2" />
              <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{accuracy}%</div>
              <div className="text-xs text-navy-400">точність</div>
            </div>
            <div className="card p-5">
              <Award className="w-5 h-5 text-accent-500 mb-2" />
              <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{profile?.total_xp || 0}</div>
              <div className="text-xs text-navy-400">XP зароблено</div>
            </div>
          </div>

          {/* Activity chart */}
          <div className="card p-6 mb-6">
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Активність за період</h2>
            <div className="flex items-end justify-between gap-1 h-40">
              {chartData.map((d, i) => {
                const height = d.minutes > 0 ? Math.max(6, (d.minutes / maxMinutes) * 100) : 2;
                const dayLabel = new Date(d.date).toLocaleDateString('uk-UA', { day: 'numeric', month: period === 'week' ? 'short' : undefined });
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div className="absolute -top-8 opacity-0 group-hover:opacity-100 transition-opacity bg-navy-900 text-white text-xs rounded px-2 py-1 whitespace-nowrap z-10">
                      {d.minutes} хв
                    </div>
                    <div className="w-full flex items-end justify-center" style={{ height: '120px' }}>
                      <div
                        className={`w-full max-w-[30px] rounded-t-lg transition-all ${d.minutes > 0 ? 'bg-gradient-to-t from-primary-600 to-primary-400' : 'bg-navy-200 dark:bg-navy-800'}`}
                        style={{ height: `${height}%` }}
                      />
                    </div>
                    {(period === 'week' || i % 5 === 0) && (
                      <span className="text-xs text-navy-400">{dayLabel}</span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Two columns */}
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Exercise attempts */}
            <div className="card p-6">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Вправи курсів</h2>
              {exerciseAttempts.length === 0 ? (
                <p className="text-sm text-navy-400 text-center py-4">Вправ поки не виконано</p>
              ) : (
                <div className="space-y-2">
                  {exerciseAttempts.slice(0, 6).map((a) => {
                    const acc = calculateAccuracy(a.score, a.total_questions);
                    return (
                      <div key={a.id} className="flex items-center justify-between p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${
                            acc >= 70 ? 'bg-success-100 text-success-600' : acc >= 50 ? 'bg-warning-100 text-warning-600' : 'bg-error-100 text-error-500'
                          }`}>{acc}%</div>
                          <div>
                            <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{a.score}/{a.total_questions}</div>
                            <div className="text-xs text-navy-400">{formatMinutes(Math.round(a.time_spent_seconds / 60))}</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Session types */}
            <div className="card p-6">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">За типом активності</h2>
              <div className="space-y-3">
                {Object.entries(typeMap).map(([type, stats]) => {
                  const label = typeLabels[type] || type;
                  const acc = calculateAccuracy(stats.correct, stats.items);
                  return (
                    <div key={type} className="flex items-center gap-3">
                      <div className="flex-1">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-navy-600 dark:text-navy-300">{label}</span>
                          <span className="text-navy-400 text-xs">{stats.count} сесій · {acc}%</span>
                        </div>
                        <div className="h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden">
                          <div className="h-full bg-primary-500 rounded-full" style={{ width: `${Math.min(100, (stats.items / totalItems) * 100)}%` }} />
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Exam results */}
            <div className="card p-6">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Результати тестів НМТ</h2>
              {examAttempts.length === 0 ? (
                <EmptyState icon={ClipboardCheck} title="Тестів ще немає" description="Пройдіть перший тренувальний тест" />
              ) : (
                <div className="space-y-2">
                  {examAttempts.slice(0, 5).map((a) => {
                    const acc = calculateAccuracy(a.score, a.total_questions);
                    return (
                      <div key={a.id} className="flex items-center justify-between p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-sm font-bold ${
                            acc >= 70 ? 'bg-success-100 text-success-600' : acc >= 50 ? 'bg-warning-100 text-warning-600' : 'bg-error-100 text-error-500'
                          }`}>{acc}%</div>
                          <div>
                            <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{a.score}/{a.total_questions}</div>
                            <div className="text-xs text-navy-400">{new Date(a.completed_at || a.started_at).toLocaleDateString('uk-UA')}</div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Recent sessions */}
          <div className="card p-6 mt-6">
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Останні сесії</h2>
            <div className="space-y-2">
              {sessions.slice(0, 10).map((s) => (
                <div key={s.id} className="flex items-center justify-between p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                  <div className="flex items-center gap-3">
                    {s.session_type.startsWith('trainer') ? <BookOpen className="w-5 h-5 text-primary-500" /> :
                     s.session_type === 'exam' ? <ClipboardCheck className="w-5 h-5 text-error-500" /> :
                     <Repeat className="w-5 h-5 text-warning-500" />}
                    <div>
                      <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{typeLabels[s.session_type] || s.session_type}</div>
                      <div className="text-xs text-navy-400">{s.studied_at}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span className="text-navy-400">{formatMinutes(Math.round(s.duration_seconds / 60))}</span>
                    <span className="text-navy-400">{s.items_correct}/{s.items_studied}</span>
                    <span className="font-semibold text-accent-500">+{s.xp_earned} XP</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </AppLayout>
  );
}
