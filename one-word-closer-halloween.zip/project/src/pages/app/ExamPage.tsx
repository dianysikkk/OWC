import { useEffect, useState, useCallback, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { ExamVariant, ExamQuestion, ExamAttempt, ExamAnswer } from '@/lib/types';
import { LoadingState, EmptyState } from '@/components/ui/States';
import {
  ClipboardCheck, Clock, ChevronRight, ChevronLeft, Check, X,
  Flag, Trophy, RotateCcw, AlertCircle, BookOpen
} from 'lucide-react';

type ExamState = 'list' | 'intro' | 'taking' | 'results' | 'review';

export function ExamPage() {
  const { user, profile, refreshProfile } = useAuth();
  const [state, setState] = useState<ExamState>('list');
  const [variants, setVariants] = useState<ExamVariant[]>([]);
  const [selectedVariant, setSelectedVariant] = useState<ExamVariant | null>(null);
  const [questions, setQuestions] = useState<ExamQuestion[]>([]);
  const [attempt, setAttempt] = useState<ExamAttempt | null>(null);
  const [answers, setAnswers] = useState<Record<string, ExamAnswer>>({});
  const [currentQ, setCurrentQ] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [pastAttempts, setPastAttempts] = useState<ExamAttempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [score, setScore] = useState(0);
  const [variantError, setVariantError] = useState(false);
  const [variantQuestionCount, setVariantQuestionCount] = useState(0);
  const finishedRef = useRef(false);

  const loadVariants = useCallback(async () => {
    const { data } = await supabase.from('exam_variants').select('*').eq('is_published', true).order('created_at');
    if (data) setVariants(data as ExamVariant[]);
    if (user) {
      const { data: attempts } = await supabase.from('exam_attempts').select('*').eq('user_id', user.id).order('started_at', { ascending: false }).limit(10);
      if (attempts) setPastAttempts(attempts as ExamAttempt[]);
    }
    if (data && data.length > 0) {
      const { count } = await supabase.from('exam_questions').select('id', { count: 'exact', head: true }).eq('exam_variant_id', data[0].id);
      setVariantQuestionCount(count || 0);
    }
    setLoading(false);
  }, [user]);

  useEffect(() => { loadVariants(); }, [loadVariants]);

  // Timer
  useEffect(() => {
    if (state !== 'taking' || timeLeft <= 0) return;
    const timer = setInterval(() => {
      setTimeLeft((t) => Math.max(0, t - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, [state]);

  useEffect(() => {
    if (state === 'taking' && timeLeft === 0 && !finishedRef.current) {
      finishedRef.current = true;
      finishExam();
    }
  }, [state, timeLeft]);

  const startExam = async (variant: ExamVariant) => {
    if (!user) return;
    finishedRef.current = false;
    const { data: qs } = await supabase.from('exam_questions').select('*').eq('exam_variant_id', variant.id).order('question_number');
    if (!qs || qs.length === 0) {
      setQuestions([]);
      setVariantError(true);
      return;
    }
    setQuestions(qs as ExamQuestion[]);
    setVariantQuestionCount(qs.length);

    const { data: att } = await supabase.from('exam_attempts').insert({
      user_id: user.id, exam_variant_id: variant.id, status: 'in_progress', total_questions: qs.length,
    }).select().single();
    if (att) {
      setAttempt(att as ExamAttempt);
      // Create empty answers
      const ansMap: Record<string, ExamAnswer> = {};
      for (const q of qs) {
        const { data: a } = await supabase.from('exam_answers').insert({
          exam_attempt_id: att.id, question_id: q.id, selected_option: null, is_marked: false,
        }).select().single();
        if (a) ansMap[q.id] = a as ExamAnswer;
      }
      setAnswers(ansMap);
    }
    setTimeLeft(variant.duration_minutes * 60);
    setCurrentQ(0);
    setState('taking');
  };

  const selectAnswer = async (questionId: string, option: string) => {
    const ans = answers[questionId];
    if (!ans) return;
    await supabase.from('exam_answers').update({ selected_option: option, answered_at: new Date().toISOString() }).eq('id', ans.id);
    setAnswers({ ...answers, [questionId]: { ...ans, selected_option: option } });
  };

  const toggleMark = async (questionId: string) => {
    const ans = answers[questionId];
    if (!ans) return;
    await supabase.from('exam_answers').update({ is_marked: !ans.is_marked }).eq('id', ans.id);
    setAnswers({ ...answers, [questionId]: { ...ans, is_marked: !ans.is_marked } });
  };

  const finishExam = async () => {
    if (!user || !attempt || !selectedVariant) return;
    let correct = 0;
    for (const q of questions) {
      const ans = answers[q.id];
      if (ans?.selected_option === q.correct_option) correct++;
    }
    const timeSpent = selectedVariant.duration_minutes * 60 - timeLeft;
    await supabase.from('exam_attempts').update({
      status: 'completed', score: correct, completed_at: new Date().toISOString(), time_spent_seconds: timeSpent,
    }).eq('id', attempt.id);

    await supabase.from('study_sessions').insert({
      user_id: user.id, session_type: 'exam', duration_seconds: timeSpent,
      items_studied: questions.length, items_correct: correct, xp_earned: correct * 10,
    });

    const today = new Date().toISOString().split('T')[0];
    const isToday = profile?.last_study_date === today;
    const newStreak = isToday ? profile?.streak_days || 0 : (profile?.streak_days || 0) + 1;
    await supabase.from('profiles').update({
      total_xp: (profile?.total_xp || 0) + correct * 10,
      streak_days: newStreak, last_study_date: today,
    }).eq('id', user.id);
    refreshProfile();

    setScore(correct);
    setState('results');
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${m}:${sec.toString().padStart(2, '0')}`;
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  // List view
  if (state === 'list') {
    return (
      <AppLayout>
        <div className="mb-6">
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Симулятор НМТ</h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">
            Тренувальні тести з таймером та розбором помилок. Авторські матеріали, не офіційні завдання НМТ.
          </p>
        </div>

        {variants.length === 0 ? (
          <EmptyState icon={ClipboardCheck} title="Тестів поки немає" description="Тренувальні варіанти будуть додані скоро" />
        ) : (
          <div className="space-y-4 mb-8">
            {variants.map((v) => (
              <div key={v.id} className="card p-6">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">{v.title}</h3>
                    <p className="text-sm text-navy-500 dark:text-navy-400 mt-1">{v.description}</p>
                  </div>
                  <span className="badge-warning"><Clock className="w-3 h-3" /> {v.duration_minutes} хв</span>
                </div>
                <button onClick={() => { setSelectedVariant(v); setVariantError(false); setState('intro'); }} className="btn-primary">
                  Почати тест <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}

        {pastAttempts.length > 0 && (
          <div>
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-3">Історія спроб</h2>
            <div className="space-y-2">
              {pastAttempts.map((a) => (
                <div key={a.id} className="card p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      a.status === 'completed' ? 'bg-success-100 dark:bg-success-900/30 text-success-600' : 'bg-warning-100 dark:bg-warning-900/30 text-warning-600'
                    }`}>
                      {a.status === 'completed' ? <Check className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                    </div>
                    <div>
                      <div className="text-sm font-medium text-navy-700 dark:text-navy-200">
                        {a.status === 'completed' ? `${a.score}/${a.total_questions}` : 'В процесі'}
                      </div>
                      <div className="text-xs text-navy-400">{new Date(a.started_at).toLocaleDateString('uk-UA')}</div>
                    </div>
                  </div>
                  {a.status === 'completed' && (
                    <span className="text-sm font-semibold text-primary-600">{Math.round((a.score / a.total_questions) * 100)}%</span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </AppLayout>
    );
  }

  // Intro
  if (state === 'intro' && selectedVariant) {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <button onClick={() => setState('list')} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> Назад
          </button>
          <div className="card p-8">
            <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-3">{selectedVariant.title}</h1>
            <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">{selectedVariant.description}</p>
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="p-4 rounded-xl bg-navy-50 dark:bg-navy-800/40 text-center">
                <Clock className="w-6 h-6 text-primary-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-navy-800 dark:text-navy-100">{selectedVariant.duration_minutes}</div>
                <div className="text-xs text-navy-400">хвилин</div>
              </div>
              <div className="p-4 rounded-xl bg-navy-50 dark:bg-navy-800/40 text-center">
                <ClipboardCheck className="w-6 h-6 text-primary-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-navy-800 dark:text-navy-100">{variantQuestionCount || '—'}</div>
                <div className="text-xs text-navy-400">завдань</div>
              </div>
              <div className="p-4 rounded-xl bg-navy-50 dark:bg-navy-800/40 text-center">
                <BookOpen className="w-6 h-6 text-primary-500 mx-auto mb-1" />
                <div className="text-lg font-bold text-navy-800 dark:text-navy-100">A-D</div>
                <div className="text-xs text-navy-400">варіанти</div>
              </div>
            </div>
            <div className="card p-4 bg-warning-50 dark:bg-warning-950/20 border-warning-200 dark:border-warning-900/30 mb-6">
              <h3 className="text-sm font-semibold text-navy-700 dark:text-navy-200 mb-2">Правила:</h3>
              <ul className="space-y-1 text-sm text-navy-500">
                <li>· Таймер зупинить тест автоматично</li>
                <li>· Можна позначати завдання для повернення</li>
                <li>· Відповіді зберігаються автоматично</li>
                <li>· Результати з поясненнями після завершення</li>
              </ul>
            </div>
            {variantError && (
              <div className="card p-4 bg-error-50 dark:bg-error-950/20 border-error-200 dark:border-error-900/30 mb-6">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-error-500 flex-shrink-0" />
                  <p className="text-sm text-error-700 dark:text-error-300">У цього варіанту ще немає завдань. Спробуйте інший варіант.</p>
                </div>
              </div>
            )}
            <button onClick={() => startExam(selectedVariant)} className="btn-primary w-full text-base py-3">
              Почати тест <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Taking exam
  if (state === 'taking' && questions.length > 0) {
    const q = questions[currentQ];
    const ans = answers[q.id];
    const answeredCount = Object.values(answers).filter(a => a.selected_option).length;
    const markedCount = Object.values(answers).filter(a => a.is_marked).length;

    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          {/* Top bar */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary-50 dark:bg-primary-950/30 text-primary-700 dark:text-primary-300">
              <Clock className="w-5 h-5" />
              <span className="font-mono font-bold text-lg">{formatTime(timeLeft)}</span>
            </div>
            <div className="text-sm text-navy-500">
              {answeredCount}/{questions.length} відповідей · {markedCount} позначено
            </div>
          </div>

          {/* Question navigation grid */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {questions.map((qq, i) => {
              const a = answers[qq.id];
              return (
                <button
                  key={qq.id}
                  onClick={() => setCurrentQ(i)}
                  className={`w-9 h-9 rounded-lg text-xs font-medium transition-all ${
                    i === currentQ ? 'ring-2 ring-primary-500' : ''
                  } ${
                    a?.is_marked ? 'bg-warning-100 dark:bg-warning-900/30 text-warning-600' :
                    a?.selected_option ? 'bg-success-100 dark:bg-success-900/30 text-success-600' :
                    'bg-navy-100 dark:bg-navy-800 text-navy-400'
                  }`}
                >
                  {i + 1}
                </button>
              );
            })}
          </div>

          {/* Question */}
          <div className="card p-6 mb-4">
            <div className="flex items-start justify-between mb-4">
              <span className="text-sm text-navy-400">Завдання {currentQ + 1} з {questions.length}</span>
              <button onClick={() => toggleMark(q.id)} className={`btn-ghost text-xs ${ans?.is_marked ? 'text-warning-600' : ''}`}>
                <Flag className={`w-4 h-4 ${ans?.is_marked ? 'fill-current' : ''}`} />
                {ans?.is_marked ? 'Позначено' : 'Позначити'}
              </button>
            </div>
            <p className="text-lg text-navy-800 dark:text-navy-100 mb-6">{q.question_text}</p>
            <div className="space-y-2">
              {(['A', 'B', 'C', 'D'] as const).map((opt) => {
                const text = opt === 'A' ? q.option_a : opt === 'B' ? q.option_b : opt === 'C' ? q.option_c : q.option_d;
                const isSelected = ans?.selected_option === opt;
                return (
                  <button
                    key={opt}
                    onClick={() => selectAnswer(q.id, opt)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                      isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' : 'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <span className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${
                      isSelected ? 'bg-primary-500 text-white' : 'bg-navy-100 dark:bg-navy-800 text-navy-500'
                    }`}>{opt}</span>
                    <span className="text-sm text-navy-700 dark:text-navy-200">{text}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between">
            <button onClick={() => setCurrentQ(Math.max(0, currentQ - 1))} disabled={currentQ === 0} className="btn-secondary">
              <ChevronLeft className="w-4 h-4" /> Назад
            </button>
            {currentQ < questions.length - 1 ? (
              <button onClick={() => setCurrentQ(currentQ + 1)} className="btn-primary">
                Далі <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button onClick={finishExam} className="btn bg-success-500 text-white hover:bg-success-600">
                <Check className="w-4 h-4" /> Завершити тест
              </button>
            )}
          </div>
        </div>
      </AppLayout>
    );
  }

  // Results
  if (state === 'results') {
    const accuracy = questions.length > 0 ? Math.round((score / questions.length) * 100) : 0;
    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          <div className="card p-8 text-center mb-6">
            <div className={`w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 ${
              accuracy >= 70 ? 'bg-gradient-to-br from-success-500 to-success-700' :
              accuracy >= 50 ? 'bg-gradient-to-br from-warning-500 to-warning-700' :
              'bg-gradient-to-br from-error-500 to-error-700'
            }`}>
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">Тест завершено!</h2>
            <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">
              Це тренувальний бал, не офіційна шкала оцінювання НМТ.
            </p>
            <div className="grid grid-cols-4 gap-3 mb-6">
              <div className="p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                <div className="text-xl font-bold text-navy-800 dark:text-navy-100">{score}/{questions.length}</div>
                <div className="text-xs text-navy-400">Бал</div>
              </div>
              <div className="p-3 rounded-xl bg-success-50 dark:bg-success-950/20">
                <div className="text-xl font-bold text-success-600">{score}</div>
                <div className="text-xs text-navy-400">Правильно</div>
              </div>
              <div className="p-3 rounded-xl bg-error-50 dark:bg-error-950/20">
                <div className="text-xl font-bold text-error-500">{questions.length - score}</div>
                <div className="text-xs text-navy-400">Помилки</div>
              </div>
              <div className="p-3 rounded-xl bg-primary-50 dark:bg-primary-950/20">
                <div className="text-xl font-bold text-primary-600">{accuracy}%</div>
                <div className="text-xs text-navy-400">Точність</div>
              </div>
            </div>
            <div className="flex gap-3 justify-center">
              <button onClick={() => { setState('list'); loadVariants(); }} className="btn-secondary">
                <RotateCcw className="w-4 h-4" /> Новий тест
              </button>
              <button onClick={() => setState('review')} className="btn-primary">
                Розбір помилок <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Topic breakdown */}
          <div className="card p-6">
            <h3 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-100 mb-4">Результати за темами</h3>
            {Array.from(new Set(questions.map(q => q.topic))).map((topic) => {
              const topicQs = questions.filter(q => q.topic === topic);
              const topicCorrect = topicQs.filter(q => answers[q.id]?.selected_option === q.correct_option).length;
              const topicAcc = Math.round((topicCorrect / topicQs.length) * 100);
              return (
                <div key={topic} className="mb-3">
                  <div className="flex items-center justify-between text-sm mb-1">
                    <span className="text-navy-600 dark:text-navy-300">{topic}</span>
                    <span className="text-navy-400">{topicCorrect}/{topicQs.length} ({topicAcc}%)</span>
                  </div>
                  <div className="h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden">
                    <div className={`h-full rounded-full ${topicAcc >= 70 ? 'bg-success-500' : topicAcc >= 50 ? 'bg-warning-500' : 'bg-error-500'}`} style={{ width: `${topicAcc}%` }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </AppLayout>
    );
  }

  // Review answers
  if (state === 'review') {
    return (
      <AppLayout>
        <div className="max-w-3xl mx-auto">
          <button onClick={() => { setState('list'); loadVariants(); }} className="btn-ghost mb-4">
            <ChevronLeft className="w-4 h-4" /> До списку тестів
          </button>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-4">Розбір відповідей</h1>
          <div className="space-y-4">
            {questions.map((q, i) => {
              const ans = answers[q.id];
              const isCorrect = ans?.selected_option === q.correct_option;
              return (
                <div key={q.id} className={`card p-5 ${isCorrect ? 'border-success-300 dark:border-success-800' : 'border-error-300 dark:border-error-800'}`}>
                  <div className="flex items-start gap-3 mb-3">
                    {isCorrect ? <Check className="w-5 h-5 text-success-600 flex-shrink-0 mt-0.5" /> : <X className="w-5 h-5 text-error-500 flex-shrink-0 mt-0.5" />}
                    <div className="flex-1">
                      <span className="text-xs text-navy-400">Завдання {i + 1}</span>
                      <p className="text-sm font-medium text-navy-800 dark:text-navy-100 mt-1">{q.question_text}</p>
                    </div>
                  </div>
                  <div className="space-y-1.5 ml-8">
                    {(['A', 'B', 'C', 'D'] as const).map((opt) => {
                      const text = opt === 'A' ? q.option_a : opt === 'B' ? q.option_b : opt === 'C' ? q.option_c : q.option_d;
                      const isUserAns = ans?.selected_option === opt;
                      const isRightAns = q.correct_option === opt;
                      return (
                        <div key={opt} className={`text-sm flex items-center gap-2 ${
                          isRightAns ? 'text-success-600 font-medium' :
                          isUserAns ? 'text-error-500' : 'text-navy-400'
                        }`}>
                          <span className={`w-6 h-6 rounded flex items-center justify-center text-xs ${
                            isRightAns ? 'bg-success-100 dark:bg-success-900/30' :
                            isUserAns ? 'bg-error-100 dark:bg-error-900/30' : 'bg-navy-100 dark:bg-navy-800'
                          }`}>{opt}</span>
                          {text}
                          {isRightAns && <Check className="w-3 h-3" />}
                          {isUserAns && !isRightAns && <X className="w-3 h-3" />}
                        </div>
                      );
                    })}
                  </div>
                  {q.explanation && (
                    <div className="ml-8 mt-3 p-3 rounded-lg bg-navy-50 dark:bg-navy-800/40">
                      <p className="text-xs text-navy-500"><strong>Пояснення:</strong> {q.explanation}</p>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </AppLayout>
    );
  }

  return <AppLayout><EmptyState icon={AlertCircle} title="Сталася помилка" /></AppLayout>;
}
