import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { Vocabulary, UserVocabulary } from '@/lib/types';
import { EmptyState, LoadingState } from '@/components/ui/States';
import {
  Layers, Brain, BookOpen, Type, Volume2, Check, X,
  ChevronRight, Trophy, Shuffle, ArrowRight, Languages,
  SpellCheck, Headphones, AlertCircle, RotateCcw
} from 'lucide-react';
import { speak, calculateAccuracy } from '@/lib/utils';

type TrainerType = 'menu' | 'flashcards' | 'multiple_choice' | 'fill_blank' | 'spelling' | 'word_match'
  | 'translation' | 'grammar' | 'listening' | 'error_trainer' | 'finished';

interface TrainerCard {
  type: TrainerType;
  title: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}

const trainers: TrainerCard[] = [
  { type: 'flashcards', title: 'Флеш-карти', desc: 'Переглядай слова та переклади', icon: BookOpen, color: 'primary' },
  { type: 'multiple_choice', title: 'Вибір відповіді', desc: 'Обери правильний переклад', icon: Check, color: 'success' },
  { type: 'fill_blank', title: 'Заповнення пропусків', desc: 'Встав пропущене слово', icon: Type, color: 'warning' },
  { type: 'spelling', title: 'Орфографія', desc: 'Напиши слово за перекладом', icon: Brain, color: 'accent' },
  { type: 'word_match', title: 'Зіставлення', desc: 'Зістав англійські слова з перекладами', icon: Shuffle, color: 'primary' },
  { type: 'translation', title: 'Переклад речень', desc: 'Переклади речення з української', icon: Languages, color: 'success' },
  { type: 'grammar', title: 'Граматика', desc: 'Обери правильну граматичну форму', icon: SpellCheck, color: 'warning' },
  { type: 'listening', title: 'Аудіювання', desc: 'Прослухай і обери слово', icon: Headphones, color: 'accent' },
  { type: 'error_trainer', title: 'Повторення помилок', desc: 'Працюй над словами, де помилявся', icon: AlertCircle, color: 'error' },
];

interface GrammarQuestion {
  question: string;
  options: string[];
  correct: string;
  explanation: string;
}

const grammarQuestions: GrammarQuestion[] = [
  { question: 'She ___ to school every day.', options: ['go', 'goes', 'going', 'gone'], correct: 'goes', explanation: 'У Present Simple для він/вона/воно додаємо -s: she goes.' },
  { question: 'I ___ my homework yesterday.', options: ['do', 'did', 'done', 'doing'], correct: 'did', explanation: 'Минулий час — використовуємо did: I did.' },
  { question: 'They ___ playing football now.', options: ['is', 'am', 'are', 'be'], correct: 'are', explanation: 'Для they у Present Continuous використовуємо are.' },
  { question: 'He has ___ this book already.', options: ['read', 'reads', 'reading', 'to read'], correct: 'read', explanation: 'Після has/have використовуємо третю форму дієслова (Past Participle): read.' },
  { question: 'There ___ many books on the table.', options: ['is', 'are', 'be', 'was'], correct: 'are', explanation: 'З множиною використовуємо are: There are many books.' },
  { question: 'I ___ never been to London.', options: ['has', 'have', 'had', 'having'], correct: 'have', explanation: 'Для I у Present Perfect використовуємо have: I have never been.' },
  { question: 'The movie ___ at 8 PM tomorrow.', options: ['starts', 'will start', 'starting', 'started'], correct: 'will start', explanation: 'Розклад у майбутньому — will start або starts. Для конкретного часу в майбутньому: will start.' },
  { question: 'If it ___ tomorrow, we will stay home.', options: ['rain', 'rains', 'will rain', 'rained'], correct: 'rains', explanation: 'У першому типі умовних речень (First Conditional) використовуємо Present Simple: if it rains.' },
  { question: 'She is ___ than her sister.', options: ['tall', 'taller', 'tallest', 'more tall'], correct: 'taller', explanation: 'Короткі прикметники утворюють порівняльний ступінь через -er: taller.' },
  { question: 'This is the ___ book I have ever read.', options: ['good', 'better', 'best', 'most good'], correct: 'best', explanation: 'Превосхідний ступінь від good — best: the best book.' },
];

interface ListeningOption {
  word: string;
  translation: string;
}

export function TrainersPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { navigate } = useRouter();
  const [view, setView] = useState<TrainerType>('menu');
  const [words, setWords] = useState<Vocabulary[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [userInput, setUserInput] = useState('');
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [options, setOptions] = useState<string[]>([]);
  const [results, setResults] = useState<{ word: Vocabulary; correct: boolean }[]>([]);
  const [matchPairs, setMatchPairs] = useState<{ en: string; uk: string; matched: boolean }[]>([]);
  const [matchSelected, setMatchSelected] = useState<{ side: 'en' | 'uk'; value: string } | null>(null);
  const [matchScore, setMatchScore] = useState(0);
  const [sessionStartTime, setSessionStartTime] = useState(0);
  const [grammarIdx, setGrammarIdx] = useState(0);
  const [grammarResults, setGrammarResults] = useState<{ question: GrammarQuestion; correct: boolean }[]>([]);
  const [listeningOptions, setListeningOptions] = useState<ListeningOption[]>([]);
  const [listeningSelected, setListeningSelected] = useState<string | null>(null);
  const [errorWords, setErrorWords] = useState<Vocabulary[]>([]);

  const loadWords = useCallback(async () => {
    if (!user) return;
    const { data: uv } = await supabase
      .from('user_vocabulary')
      .select('*, vocabulary:vocabulary(*)')
      .eq('user_id', user.id)
      .limit(100);

    let wordList: Vocabulary[] = [];
    if (uv && uv.length >= 4) {
      wordList = uv.map((u: UserVocabulary & { vocabulary?: Vocabulary }) => u.vocabulary!).filter(Boolean);
    } else {
      const { data: vocab } = await supabase
        .from('vocabulary')
        .select('*')
        .order('cefr_level')
        .limit(20);
      wordList = vocab || [];
    }

    wordList = [...wordList].sort(() => Math.random() - 0.5).slice(0, 10);
    setWords(wordList);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadWords(); }, [loadWords]);

  const startTrainer = (type: TrainerType) => {
    setView(type);
    setCurrentIdx(0);
    setShowAnswer(false);
    setUserInput('');
    setSelectedOption(null);
    setResults([]);
    setSessionStartTime(Date.now());
    setGrammarIdx(0);
    setGrammarResults([]);
    setListeningSelected(null);

    if (type === 'multiple_choice' && words.length > 0) {
      generateOptions(words[0]);
    }
    if (type === 'word_match') {
      generateMatchPairs();
    }
    if (type === 'listening' && words.length > 0) {
      generateListeningOptions(words[0]);
    }
    if (type === 'error_trainer') {
      loadErrorWords();
    }
  };

  const generateOptions = (word: Vocabulary) => {
    const distractors = words.filter(w => w.id !== word.id).sort(() => Math.random() - 0.5).slice(0, 3).map(w => w.translation_uk);
    const opts = [...distractors, word.translation_uk].sort(() => Math.random() - 0.5);
    setOptions(opts);
    setSelectedOption(null);
  };

  const generateMatchPairs = () => {
    const pairs = words.slice(0, 6).map(w => ({ en: w.word, uk: w.translation_uk, matched: false }));
    setMatchPairs(pairs);
    setMatchSelected(null);
    setMatchScore(0);
  };

  const generateListeningOptions = (word: Vocabulary) => {
    const distractors = words.filter(w => w.id !== word.id).sort(() => Math.random() - 0.5).slice(0, 3);
    const opts = [...distractors.map(w => ({ word: w.word, translation: w.translation_uk })), { word: word.word, translation: word.translation_uk }]
      .sort(() => Math.random() - 0.5);
    setListeningOptions(opts);
    setListeningSelected(null);
    setTimeout(() => speak(word.word), 300);
  };

  const loadErrorWords = async () => {
    if (!user) return;
    const { data: uv } = await supabase
      .from('user_vocabulary')
      .select('*, vocabulary:vocabulary(*)')
      .eq('user_id', user.id)
      .eq('is_difficult', true)
      .limit(10);

    let difficult: Vocabulary[] = [];
    if (uv && uv.length >= 2) {
      difficult = uv.map((u: UserVocabulary & { vocabulary?: Vocabulary }) => u.vocabulary!).filter(Boolean);
    }
    if (difficult.length < 4) {
      const { data: uv2 } = await supabase
        .from('user_vocabulary')
        .select('*, vocabulary:vocabulary(*)')
        .eq('user_id', user.id)
        .order('times_correct')
        .limit(10);
      if (uv2) {
        const fallback = uv2
          .filter((u: UserVocabulary & { vocabulary?: Vocabulary }) => (u.times_practiced - u.times_correct) > 0)
          .map((u: UserVocabulary & { vocabulary?: Vocabulary }) => u.vocabulary!)
          .filter(Boolean);
        difficult = [...difficult, ...fallback].slice(0, 10);
      }
    }
    if (difficult.length < 4) {
      difficult = [...words].sort(() => Math.random() - 0.5).slice(0, 10);
    }
    difficult = [...difficult].sort(() => Math.random() - 0.5).slice(0, 10);
    setErrorWords(difficult);
    setCurrentIdx(0);
    setShowAnswer(false);
    setResults([]);
  };

  const finishSession = async (correctCount: number, totalItems: number, sessionType: string) => {
    if (!user) return;
    const duration = Math.round((Date.now() - sessionStartTime) / 1000);

    await supabase.from('study_sessions').insert({
      user_id: user.id,
      session_type: sessionType,
      duration_seconds: duration,
      items_studied: totalItems,
      items_correct: correctCount,
      xp_earned: correctCount * 8,
    });

    const today = new Date().toISOString().split('T')[0];
    const isToday = profile?.last_study_date === today;
    const newStreak = isToday ? profile?.streak_days || 0 : (profile?.streak_days || 0) + 1;
    await supabase.from('profiles').update({
      total_xp: (profile?.total_xp || 0) + correctCount * 8,
      streak_days: newStreak,
      last_study_date: today,
    }).eq('id', user.id);
    refreshProfile();
  };

  const nextWord = (word: Vocabulary, correct: boolean) => {
    const newResults = [...results, { word, correct }];
    setResults(newResults);
    if (currentIdx + 1 >= words.length) {
      finishSession(newResults.filter(r => r.correct).length, newResults.length, `trainer_${view}`);
      setView('finished');
    } else {
      setCurrentIdx(currentIdx + 1);
      setShowAnswer(false);
      setUserInput('');
      if (view === 'multiple_choice') generateOptions(words[currentIdx + 1]);
    }
  };

  const nextErrorWord = (word: Vocabulary, correct: boolean) => {
    const newResults = [...results, { word, correct }];
    setResults(newResults);
    if (currentIdx + 1 >= errorWords.length) {
      finishSession(newResults.filter(r => r.correct).length, newResults.length, 'trainer_error');
      setView('finished');
    } else {
      setCurrentIdx(currentIdx + 1);
      setShowAnswer(false);
      setUserInput('');
    }
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  if (view === 'menu') {
    return (
      <AppLayout>
        <div className="mb-6">
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Тренажери</h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">Оберіть тип вправи для тренування</p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {trainers.map((t) => {
            const Icon = t.icon;
            return (
              <button key={t.type} onClick={() => startTrainer(t.type)} className="card card-hover p-6 text-left">
                <div className={`w-12 h-12 rounded-xl bg-${t.color}-50 dark:bg-${t.color}-950/40 flex items-center justify-center mb-4`}>
                  <Icon className={`w-6 h-6 text-${t.color}-600 dark:text-${t.color}-400`} />
                </div>
                <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-1">{t.title}</h3>
                <p className="text-sm text-navy-500 dark:text-navy-400">{t.desc}</p>
              </button>
            );
          })}
        </div>
        {words.length < 4 && (
          <div className="card p-4 mt-6 text-center">
            <p className="text-sm text-navy-500">
              Додайте більше слів у свій словник для повноцінних тренувань.{' '}
              <button onClick={() => navigate('/vocabulary')} className="text-primary-600 font-medium">Перейти до словника</button>
            </p>
          </div>
        )}
      </AppLayout>
    );
  }

  if (view === 'finished') {
    const correctCount = results.filter(r => r.correct).length;
    const accuracy = calculateAccuracy(correctCount, results.length);
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <div className="card p-8 text-center">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">Вправу завершено!</h2>
            <div className="grid grid-cols-3 gap-4 my-6">
              <div className="p-4 rounded-xl bg-success-50 dark:bg-success-950/20">
                <div className="text-2xl font-bold text-success-600">{correctCount}</div>
                <div className="text-xs text-navy-400">Правильно</div>
              </div>
              <div className="p-4 rounded-xl bg-error-50 dark:bg-error-950/20">
                <div className="text-2xl font-bold text-error-500">{results.length - correctCount}</div>
                <div className="text-xs text-navy-400">Помилки</div>
              </div>
              <div className="p-4 rounded-xl bg-primary-50 dark:bg-primary-950/20">
                <div className="text-2xl font-bold text-primary-600">{accuracy}%</div>
                <div className="text-xs text-navy-400">Точність</div>
              </div>
            </div>
            <div className="flex gap-3 justify-center">
              <button onClick={() => setView('menu')} className="btn-secondary">
                <Layers className="w-4 h-4" /> Інші тренажери
              </button>
              <button onClick={() => navigate('/dashboard')} className="btn-primary">
                На панель <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  const current = words[currentIdx];
  if (!current && view !== 'grammar') return <AppLayout><EmptyState icon={Layers} title="Немає слів" description="Додайте слова для тренування" /></AppLayout>;

  if (view === 'flashcards') {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Флеш-карти" />
          <div className="card p-8 mb-6 min-h-[300px] flex flex-col items-center justify-center cursor-pointer" onClick={() => setShowAnswer(!showAnswer)}>
            {!showAnswer ? (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <h2 className="font-heading text-3xl font-bold text-navy-900 dark:text-white">{current.word}</h2>
                  <button onClick={(e) => { e.stopPropagation(); speak(current.word); }} className="text-primary-500">
                    <Volume2 className="w-6 h-6" />
                  </button>
                </div>
                {current.transcription && <p className="text-sm text-navy-400 font-mono mb-4">{current.transcription}</p>}
                <p className="text-xs text-navy-400">Натисніть для перекладу</p>
              </>
            ) : (
              <div className="animate-scale-in text-center">
                <p className="text-2xl font-semibold text-navy-800 dark:text-navy-100 mb-3">{current.translation_uk}</p>
                {current.example_en && <p className="text-sm text-navy-500 italic">"{current.example_en}"</p>}
                {current.example_uk && <p className="text-xs text-navy-400 mt-1">{current.example_uk}</p>}
              </div>
            )}
          </div>
          <div className="flex gap-3">
            <button onClick={() => nextWord(current, false)} className="btn bg-error-50 text-error-600 hover:bg-error-100 flex-1">
              <X className="w-4 h-4" /> Складно
            </button>
            <button onClick={() => nextWord(current, true)} className="btn bg-success-50 text-success-600 hover:bg-success-100 flex-1">
              <Check className="w-4 h-4" /> Знаю
            </button>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (view === 'multiple_choice') {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Вибір відповіді" />
          <div className="card p-8 mb-6">
            <div className="flex items-center justify-center gap-2 mb-6">
              <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white text-center">{current.word}</h2>
              <button onClick={() => speak(current.word)} className="text-primary-500"><Volume2 className="w-5 h-5" /></button>
            </div>
            <p className="text-sm text-navy-400 text-center mb-4">Оберіть правильний переклад</p>
            <div className="space-y-2">
              {options.map((opt, i) => {
                const isSelected = selectedOption === opt;
                const isCorrect = opt === current.translation_uk;
                const showResult = selectedOption !== null;
                return (
                  <button
                    key={i}
                    onClick={() => { if (selectedOption === null) setSelectedOption(opt); }}
                    disabled={showResult}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      showResult && isCorrect ? 'border-success-500 bg-success-50 dark:bg-success-950/20' :
                      showResult && isSelected && !isCorrect ? 'border-error-500 bg-error-50 dark:bg-error-950/20' :
                      isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                      'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <span className="text-sm font-medium text-navy-700 dark:text-navy-200">{opt}</span>
                  </button>
                );
              })}
            </div>
          </div>
          {selectedOption !== null && (
            <button onClick={() => nextWord(current, selectedOption === current.translation_uk)} className="btn-primary w-full">
              {currentIdx + 1 >= words.length ? 'Завершити' : 'Наступне'}
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </AppLayout>
    );
  }

  if (view === 'fill_blank') {
    const example = current.example_en || '';
    const blanked = example.replace(new RegExp(current.word, 'gi'), '_____');
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Заповнення пропусків" />
          <div className="card p-8 mb-6">
            <p className="text-sm text-navy-400 mb-2">Переклад: {current.translation_uk}</p>
            <p className="text-lg text-navy-800 dark:text-navy-100 mb-6">{blanked || 'Немає прикладу для цього слова'}</p>
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && userInput.trim()) nextWord(current, userInput.trim().toLowerCase() === current.word.toLowerCase()); }}
              className="input text-center text-lg"
              placeholder="Введіть слово..."
              autoFocus
            />
          </div>
          <button onClick={() => nextWord(current, userInput.trim().toLowerCase() === current.word.toLowerCase())} disabled={!userInput.trim()} className="btn-primary w-full">
            {currentIdx + 1 >= words.length ? 'Завершити' : 'Наступне'}
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </AppLayout>
    );
  }

  if (view === 'spelling') {
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Орфографія" />
          <div className="card p-8 mb-6 text-center">
            <p className="text-sm text-navy-400 mb-2">Переклад:</p>
            <p className="text-2xl font-semibold text-navy-800 dark:text-navy-100 mb-2">{current.translation_uk}</p>
            <button onClick={() => speak(current.word)} className="btn-ghost mb-4">
              <Volume2 className="w-5 h-5" /> Прослухати
            </button>
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && userInput.trim()) nextWord(current, userInput.trim().toLowerCase() === current.word.toLowerCase()); }}
              className="input text-center text-lg"
              placeholder="Напишіть слово англійською..."
              autoFocus
            />
          </div>
          <button onClick={() => nextWord(current, userInput.trim().toLowerCase() === current.word.toLowerCase())} disabled={!userInput.trim()} className="btn-primary w-full">
            Перевірити <Check className="w-4 h-4" />
          </button>
        </div>
      </AppLayout>
    );
  }

  if (view === 'word_match') {
    const enWords = [...matchPairs].sort(() => Math.random() - 0.5);
    const ukWords = [...matchPairs].sort(() => Math.random() - 0.5);
    const allMatched = matchPairs.length > 0 && matchPairs.every(p => p.matched);

    const handleMatchClick = (side: 'en' | 'uk', value: string) => {
      if (matchPairs.find(p => (side === 'en' ? p.en : p.uk) === value)?.matched) return;
      if (!matchSelected) {
        setMatchSelected({ side, value });
      } else {
        const enVal = matchSelected.side === 'en' ? matchSelected.value : value;
        const ukVal = matchSelected.side === 'uk' ? matchSelected.value : value;
        const pair = matchPairs.find(p => p.en === enVal && p.uk === ukVal);
        if (pair) {
          setMatchPairs(matchPairs.map(p => p.en === enVal ? { ...p, matched: true } : p));
          setMatchScore(matchScore + 1);
        }
        setMatchSelected(null);
      }
    };

    if (allMatched) {
      finishSession(matchScore, matchPairs.length, 'trainer_word_match');
      return (
        <AppLayout>
          <div className="max-w-2xl mx-auto">
            <div className="card p-8 text-center">
              <Trophy className="w-16 h-16 text-accent-500 mx-auto mb-4" />
              <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">Усі пари зіставлено!</h2>
              <div className="flex gap-3 justify-center mt-6">
                <button onClick={() => setView('menu')} className="btn-secondary">
                  <Layers className="w-4 h-4" /> Меню
                </button>
                <button onClick={() => navigate('/dashboard')} className="btn-primary">
                  На панель <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </AppLayout>
      );
    }

    return (
      <AppLayout>
        <div className="mb-6">
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Зіставлення слів</h1>
          <p className="text-sm text-navy-500">Зіставлено: {matchScore} / {matchPairs.length}</p>
        </div>
        <div className="grid grid-cols-2 gap-4 max-w-2xl mx-auto">
          <div className="space-y-2">
            {enWords.map((pair, i) => {
              const isSelected = matchSelected?.side === 'en' && matchSelected.value === pair.en;
              return (
                <button key={i} onClick={() => handleMatchClick('en', pair.en)} disabled={pair.matched}
                  className={`w-full p-4 rounded-xl border-2 transition-all text-sm font-medium ${
                    pair.matched ? 'border-success-300 bg-success-50 text-success-600 opacity-50' :
                    isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                    'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                  }`}>
                  {pair.en}
                </button>
              );
            })}
          </div>
          <div className="space-y-2">
            {ukWords.map((pair, i) => {
              const isSelected = matchSelected?.side === 'uk' && matchSelected.value === pair.uk;
              return (
                <button key={i} onClick={() => handleMatchClick('uk', pair.uk)} disabled={pair.matched}
                  className={`w-full p-4 rounded-xl border-2 transition-all text-sm font-medium ${
                    pair.matched ? 'border-success-300 bg-success-50 text-success-600 opacity-50' :
                    isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                    'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                  }`}>
                  {pair.uk}
                </button>
              );
            })}
          </div>
        </div>
      </AppLayout>
    );
  }

  if (view === 'translation') {
    const exampleEn = current.example_en || '';
    const exampleUk = current.example_uk || current.translation_uk;
    const showResult = showAnswer;
    const isCorrect = userInput.trim().toLowerCase() === exampleUk.toLowerCase();

    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Переклад речень" />
          <div className="card p-8 mb-6">
            <p className="text-sm text-navy-400 mb-2">Перекладіть українською:</p>
            <div className="flex items-start gap-2 mb-6">
              <p className="text-lg text-navy-800 dark:text-navy-100 flex-1">{exampleEn || `Слово: ${current.word}`}</p>
              <button onClick={() => speak(exampleEn || current.word)} className="text-primary-500 flex-shrink-0 mt-1">
                <Volume2 className="w-5 h-5" />
              </button>
            </div>
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && userInput.trim()) setShowAnswer(true); }}
              className="input text-lg"
              placeholder="Введіть переклад..."
              autoFocus
              disabled={showResult}
            />
            {showResult && (
              <div className={`mt-4 p-4 rounded-xl ${isCorrect ? 'bg-success-50 dark:bg-success-950/20' : 'bg-error-50 dark:bg-error-950/20'}`}>
                <div className="flex items-center gap-2 mb-2">
                  {isCorrect ? <Check className="w-5 h-5 text-success-600" /> : <X className="w-5 h-5 text-error-500" />}
                  <span className={`font-medium ${isCorrect ? 'text-success-600' : 'text-error-500'}`}>
                    {isCorrect ? 'Правильно!' : 'Невірно'}
                  </span>
                </div>
                {!isCorrect && <p className="text-sm text-navy-600 dark:text-navy-300">Правильний переклад: {exampleUk}</p>}
              </div>
            )}
          </div>
          {!showResult ? (
            <button onClick={() => setShowAnswer(true)} disabled={!userInput.trim()} className="btn-primary w-full">
              Перевірити <Check className="w-4 h-4" />
            </button>
          ) : (
            <button onClick={() => nextWord(current, isCorrect)} className="btn-primary w-full">
              {currentIdx + 1 >= words.length ? 'Завершити' : 'Наступне'}
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </AppLayout>
    );
  }

  if (view === 'grammar') {
    const gq = grammarQuestions[grammarIdx];
    if (!gq) return <AppLayout><EmptyState icon={SpellCheck} title="Немає завдань" description="Граматичні завдання скоро з\'являться" /></AppLayout>;
    const showResult = selectedOption !== null;
    const isCorrect = selectedOption === gq.correct;

    const handleGrammarNext = () => {
      const newResults = [...grammarResults, { question: gq, correct: isCorrect }];
      setGrammarResults(newResults);
      if (grammarIdx + 1 >= grammarQuestions.length) {
        finishSession(newResults.filter(r => r.correct).length, newResults.length, 'trainer_grammar');
        setResults(newResults.map(r => ({ word: {} as Vocabulary, correct: r.correct })));
        setView('finished');
      } else {
        setGrammarIdx(grammarIdx + 1);
        setSelectedOption(null);
      }
    };

    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={grammarIdx} total={grammarQuestions.length} title="Граматика" />
          <div className="card p-8 mb-6">
            <p className="text-sm text-navy-400 mb-4">Оберіть правильну форму:</p>
            <p className="text-lg text-navy-800 dark:text-navy-100 mb-6">{gq.question}</p>
            <div className="space-y-2">
              {gq.options.map((opt, i) => {
                const isSelected = selectedOption === opt;
                const isCorrectOpt = opt === gq.correct;
                return (
                  <button
                    key={i}
                    onClick={() => { if (selectedOption === null) setSelectedOption(opt); }}
                    disabled={showResult}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                      showResult && isCorrectOpt ? 'border-success-500 bg-success-50 dark:bg-success-950/20' :
                      showResult && isSelected && !isCorrectOpt ? 'border-error-500 bg-error-50 dark:bg-error-950/20' :
                      isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                      'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <span className="text-sm font-medium text-navy-700 dark:text-navy-200">{opt}</span>
                  </button>
                );
              })}
            </div>
            {showResult && (
              <div className="mt-4 p-3 rounded-xl bg-primary-50 dark:bg-primary-950/20">
                <p className="text-sm text-navy-600 dark:text-navy-300">{gq.explanation}</p>
              </div>
            )}
          </div>
          {showResult && (
            <button onClick={handleGrammarNext} className="btn-primary w-full">
              {grammarIdx + 1 >= grammarQuestions.length ? 'Завершити' : 'Наступне'}
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </AppLayout>
    );
  }

  if (view === 'listening') {
    if (!current) return <AppLayout><EmptyState icon={Headphones} title="Немає слів" description="Додайте слова для аудіювання" /></AppLayout>;
    const showResult = listeningSelected !== null;
    const correctWord = current.word;
    const isCorrect = listeningSelected === correctWord;

    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={words.length} title="Аудіювання" />
          <div className="card p-8 mb-6 text-center">
            <p className="text-sm text-navy-400 mb-4">Прослухайте слово та оберіть його:</p>
            <button
              onClick={() => speak(current.word)}
              className="w-20 h-20 rounded-2xl bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center mx-auto mb-6 shadow-lg hover:scale-105 transition-transform"
            >
              <Volume2 className="w-10 h-10 text-white" />
            </button>
            <div className="grid grid-cols-2 gap-3">
              {listeningOptions.map((opt, i) => {
                const isSelected = listeningSelected === opt.word;
                const isCorrectOpt = opt.word === correctWord;
                return (
                  <button
                    key={i}
                    onClick={() => { if (listeningSelected === null) setListeningSelected(opt.word); }}
                    disabled={showResult}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      showResult && isCorrectOpt ? 'border-success-500 bg-success-50 dark:bg-success-950/20' :
                      showResult && isSelected && !isCorrectOpt ? 'border-error-500 bg-error-50 dark:bg-error-950/20' :
                      isSelected ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/20' :
                      'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{opt.word}</div>
                    <div className="text-xs text-navy-400 mt-1">{opt.translation}</div>
                  </button>
                );
              })}
            </div>
            {showResult && !isCorrect && (
              <div className="mt-4 p-3 rounded-xl bg-error-50 dark:bg-error-950/20">
                <p className="text-sm text-error-600">Правильна відповідь: {correctWord}</p>
              </div>
            )}
          </div>
          {showResult && (
            <button onClick={() => {
              const nextIdx = currentIdx + 1;
              nextWord(current, isCorrect);
              if (nextIdx < words.length) {
                setListeningSelected(null);
                setTimeout(() => generateListeningOptions(words[nextIdx]), 100);
              }
            }} className="btn-primary w-full">
              {currentIdx + 1 >= words.length ? 'Завершити' : 'Наступне'}
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </AppLayout>
    );
  }

  if (view === 'error_trainer') {
    const errorCurrent = errorWords[currentIdx];
    if (!errorCurrent) return <AppLayout><EmptyState icon={AlertCircle} title="Немає помилок" description="Ви ще не помилялися у словах. Спробуйте інші тренажери." /></AppLayout>;

    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <ProgressHeader idx={currentIdx} total={errorWords.length} title="Повторення помилок" />
          <div className="card p-4 mb-4 flex items-center gap-2 bg-error-50 dark:bg-error-950/20 border border-error-200 dark:border-error-900/30">
            <AlertCircle className="w-5 h-5 text-error-500 flex-shrink-0" />
            <p className="text-sm text-error-700 dark:text-error-300">Ці слова викликали у вас труднощі. Зосередьтеся на них.</p>
          </div>
          <div className="card p-8 mb-6 min-h-[250px] flex flex-col items-center justify-center cursor-pointer" onClick={() => setShowAnswer(!showAnswer)}>
            {!showAnswer ? (
              <>
                <div className="flex items-center gap-2 mb-4">
                  <h2 className="font-heading text-3xl font-bold text-navy-900 dark:text-white">{errorCurrent.word}</h2>
                  <button onClick={(e) => { e.stopPropagation(); speak(errorCurrent.word); }} className="text-primary-500">
                    <Volume2 className="w-6 h-6" />
                  </button>
                </div>
                {errorCurrent.transcription && <p className="text-sm text-navy-400 font-mono mb-4">{errorCurrent.transcription}</p>}
                <p className="text-xs text-navy-400">Натисніть для перекладу</p>
              </>
            ) : (
              <div className="animate-scale-in text-center">
                <p className="text-2xl font-semibold text-navy-800 dark:text-navy-100 mb-3">{errorCurrent.translation_uk}</p>
                {errorCurrent.example_en && <p className="text-sm text-navy-500 italic">"{errorCurrent.example_en}"</p>}
                {errorCurrent.example_uk && <p className="text-xs text-navy-400 mt-1">{errorCurrent.example_uk}</p>}
              </div>
            )}
          </div>
          <div className="flex gap-3">
            <button onClick={() => nextErrorWord(errorCurrent, false)} className="btn bg-error-50 text-error-600 hover:bg-error-100 flex-1">
              <RotateCcw className="w-4 h-4" /> Ще треба
            </button>
            <button onClick={() => nextErrorWord(errorCurrent, true)} className="btn bg-success-50 text-success-600 hover:bg-success-100 flex-1">
              <Check className="w-4 h-4" /> Запам'ятав
            </button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return <AppLayout><EmptyState icon={Layers} title="Тренажер не знайдено" /></AppLayout>;
}

function ProgressHeader({ idx, total, title }: { idx: number; total: number; title: string }) {
  return (
    <div className="mb-6">
      <div className="flex items-center justify-between mb-2">
        <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">{title}</h2>
        <span className="text-sm text-navy-500">{idx + 1} / {total}</span>
      </div>
      <div className="h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden">
        <div className="h-full bg-primary-500 rounded-full transition-all duration-300" style={{ width: `${(idx / total) * 100}%` }} />
      </div>
    </div>
  );
}
