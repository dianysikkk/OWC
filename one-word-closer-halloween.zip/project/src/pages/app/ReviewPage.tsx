import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { UserVocabulary, Vocabulary } from '@/lib/types';
import { sm2 } from '@/lib/sm2';
import { EmptyState, LoadingState } from '@/components/ui/States';
import {
  Repeat, Volume2, Check, X, ChevronRight, Trophy,
  ThumbsUp, ThumbsDown, Minus, RotateCcw
} from 'lucide-react';
import { speak } from '@/lib/utils';

type ReviewState = 'idle' | 'reviewing' | 'finished';

interface ReviewResult {
  word: Vocabulary;
  quality: number;
  correct: boolean;
}

export function ReviewPage() {
  const { user, profile, refreshProfile } = useAuth();
  const { navigate } = useRouter();
  const [state, setState] = useState<ReviewState>('idle');
  const [queue, setQueue] = useState<(UserVocabulary & { vocabulary?: Vocabulary })[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [results, setResults] = useState<ReviewResult[]>([]);
  const [loading, setLoading] = useState(true);

  const loadDueReviews = useCallback(async () => {
    if (!user) return;
    const today = new Date().toISOString().split('T')[0];
    const { data } = await supabase
      .from('user_vocabulary')
      .select('*, vocabulary:vocabulary(*)')
      .eq('user_id', user.id)
      .lte('sm2_next_review', today)
      .limit(50);
    if (data) setQueue(data as (UserVocabulary & { vocabulary?: Vocabulary })[]);
    setLoading(false);
  }, [user]);

  useEffect(() => { loadDueReviews(); }, [loadDueReviews]);

  const startReview = () => {
    if (queue.length === 0) return;
    setState('reviewing');
    setCurrentIdx(0);
    setShowAnswer(false);
    setResults([]);
  };

  const recordReview = async (quality: number, correct: boolean) => {
    if (!user || !queue[currentIdx]) return;
    const item = queue[currentIdx];
    const vocab = item.vocabulary;
    if (!vocab) return;

    const newState = sm2(
      { interval: item.sm2_interval, repetitions: item.sm2_repetitions, easiness: Number(item.sm2_easiness) },
      quality
    );

    await supabase.from('user_vocabulary').update({
      sm2_interval: newState.interval,
      sm2_repetitions: newState.repetitions,
      sm2_easiness: newState.easiness,
      sm2_next_review: newState.nextReview,
      times_practiced: item.times_practiced + 1,
      times_correct: item.times_correct + (correct ? 1 : 0),
      last_studied_at: new Date().toISOString(),
      is_learned: correct && item.times_correct + 1 >= 3 && newState.interval >= 7,
      is_difficult: quality < 3,
    }).eq('id', item.id);

    await supabase.from('vocabulary_reviews').insert({
      user_id: user.id,
      vocabulary_id: vocab.id,
      quality,
      was_correct: correct,
    });

    const newResult = { word: vocab, quality, correct };
    const newResults = [...results, newResult];
    setResults(newResults);

    if (currentIdx + 1 >= queue.length) {
      const correctCount = newResults.filter(r => r.correct).length;
      await supabase.from('study_sessions').insert({
        user_id: user.id,
        session_type: 'vocabulary_review',
        duration_seconds: newResults.length * 15,
        items_studied: newResults.length,
        items_correct: correctCount,
        xp_earned: correctCount * 5,
      });

      const today = new Date().toISOString().split('T')[0];
      const isToday = profile?.last_study_date === today;
      const newStreak = isToday ? profile?.streak_days || 0 : (profile?.streak_days || 0) + 1;
      await supabase.from('profiles').update({
        total_xp: (profile?.total_xp || 0) + correctCount * 5,
        streak_days: newStreak,
        last_study_date: today,
      }).eq('id', user.id);
      refreshProfile();

      setState('finished');
    } else {
      setCurrentIdx(currentIdx + 1);
      setShowAnswer(false);
    }
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  if (state === 'idle') {
    return (
      <AppLayout>
        <div className="mb-6">
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Повторення слів</h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">Інтервальне повторення за алгоритмом SM-2</p>
        </div>

        <div className="max-w-2xl mx-auto">
          {queue.length === 0 ? (
            <div className="card p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-success-100 dark:bg-success-900/30 flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-success-600" />
              </div>
              <h2 className="font-heading text-xl font-semibold text-navy-800 dark:text-navy-100 mb-2">
                Усі слова повторено!
              </h2>
              <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">
                Немає слів для повторення на сьогодні. Поверніться завтра або вивчіть нові слова.
              </p>
              <button onClick={() => navigate('/vocabulary')} className="btn-primary">
                Вивчити нові слова
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div className="card p-8 text-center">
              <div className="w-16 h-16 rounded-2xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center mx-auto mb-4">
                <Repeat className="w-8 h-8 text-primary-600" />
              </div>
              <h2 className="font-heading text-xl font-semibold text-navy-800 dark:text-navy-100 mb-2">
                Готові до повторення
              </h2>
              <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">
                {queue.length} {queue.length === 1 ? 'слово' : 'слів'} чекають на повторення.
              </p>
              <button onClick={startReview} className="btn-primary text-base px-6 py-3">
                Почати повторення
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        <div className="max-w-2xl mx-auto mt-8 card p-6">
          <h3 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-100 mb-3">Як це працює?</h3>
          <div className="space-y-2 text-sm text-navy-500 dark:text-navy-400">
            <p>1. Прочитайте слово і спробуйте згадати переклад</p>
            <p>2. Натисніть «Показати відповідь»</p>
            <p>3. Оцініть, наскільки легко вам було згадати</p>
            <p>4. Алгоритм побудує графік наступного повторення</p>
          </div>
        </div>
      </AppLayout>
    );
  }

  if (state === 'finished') {
    const correctCount = results.filter(r => r.correct).length;
    const accuracy = results.length > 0 ? Math.round((correctCount / results.length) * 100) : 0;
    return (
      <AppLayout>
        <div className="max-w-2xl mx-auto">
          <div className="card p-8 text-center">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-white" />
            </div>
            <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">
              Сесію завершено!
            </h2>
            <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">
              Ви повторили {results.length} слів
            </p>

            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="p-4 rounded-xl bg-success-50 dark:bg-success-950/20">
                <div className="text-2xl font-bold text-success-600">{correctCount}</div>
                <div className="text-xs text-navy-400">Правильно</div>
              </div>
              <div className="p-4 rounded-xl bg-error-50 dark:bg-error-950/20">
                <div className="text-2xl font-bold text-error-500">{results.length - correctCount}</div>
                <div className="text-xs text-navy-400">Помилки</div>
              </div>
              <div className="p-4 rounded-xl bg-primary-50 dark:bg-primary-950/20">
                <div className="text-2xl font-bold text-primary-600">{accuracy}%</div>
                <div className="text-xs text-navy-400">Точність</div>
              </div>
            </div>

            {accuracy < 60 && results.filter(r => !r.correct).length > 0 && (
              <div className="card p-4 mb-6 text-left">
                <h3 className="text-sm font-semibold text-navy-800 dark:text-navy-100 mb-2">Слова для повторення:</h3>
                <div className="space-y-1">
                  {results.filter(r => !r.correct).map((r, i) => (
                    <div key={i} className="text-sm text-navy-600 dark:text-navy-300">
                      <span className="font-medium">{r.word.word}</span> — {r.word.translation_uk}
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex gap-3 justify-center">
              <button onClick={() => { setState('idle'); loadDueReviews(); }} className="btn-secondary">
                <RotateCcw className="w-4 h-4" />
                Ще раз
              </button>
              <button onClick={() => navigate('/dashboard')} className="btn-primary">
                На панель
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  const current = queue[currentIdx];
  const vocab = current?.vocabulary;
  if (!vocab) return <AppLayout><EmptyState icon={Repeat} title="Помилка" description="Слово не знайдено" /></AppLayout>;

  return (
    <AppLayout>
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-4">
          <span className="text-sm text-navy-500">{currentIdx + 1} / {queue.length}</span>
          <div className="flex-1 mx-4 h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden">
            <div className="h-full bg-primary-500 rounded-full transition-all duration-300" style={{ width: `${((currentIdx) / queue.length) * 100}%` }} />
          </div>
        </div>

        <div className="card p-8 mb-6 min-h-[300px] flex flex-col items-center justify-center">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <h2 className="font-heading text-3xl font-bold text-navy-900 dark:text-white">{vocab.word}</h2>
              <button onClick={() => speak(vocab.word)} className="text-primary-500 hover:text-primary-600">
                <Volume2 className="w-6 h-6" />
              </button>
            </div>
            {vocab.transcription && <p className="text-sm text-navy-400 font-mono mb-4">{vocab.transcription}</p>}
            {vocab.part_of_speech && <span className="badge-neutral mb-4">{vocab.part_of_speech}</span>}

            {showAnswer ? (
              <div className="animate-scale-in">
                <div className="border-t border-navy-200 dark:border-navy-800 pt-4 mt-4">
                  <p className="text-xl font-medium text-navy-700 dark:text-navy-200 mb-3">{vocab.translation_uk}</p>
                  {vocab.example_en && <p className="text-sm text-navy-500 italic">"{vocab.example_en}"</p>}
                  {vocab.example_uk && <p className="text-xs text-navy-400 mt-1">{vocab.example_uk}</p>}
                </div>
              </div>
            ) : (
              <p className="text-sm text-navy-400 mt-4">Як перекладається це слово?</p>
            )}
          </div>
        </div>

        {!showAnswer ? (
          <button onClick={() => setShowAnswer(true)} className="btn-primary w-full text-base py-3">
            Показати відповідь
            <ChevronRight className="w-5 h-5" />
          </button>
        ) : (
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => recordReview(1, false)}
              className="btn bg-error-50 dark:bg-error-950/30 text-error-600 hover:bg-error-100 flex-col py-4"
            >
              <ThumbsDown className="w-5 h-5" />
              <span className="text-xs mt-1">Не згадав</span>
            </button>
            <button
              onClick={() => recordReview(3, true)}
              className="btn bg-warning-50 dark:bg-warning-950/30 text-warning-600 hover:bg-warning-100 flex-col py-4"
            >
              <Minus className="w-5 h-5" />
              <span className="text-xs mt-1">З труднощами</span>
            </button>
            <button
              onClick={() => recordReview(5, true)}
              className="btn bg-success-50 dark:bg-success-950/30 text-success-600 hover:bg-success-100 flex-col py-4"
            >
              <ThumbsUp className="w-5 h-5" />
              <span className="text-xs mt-1">Легко</span>
            </button>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
