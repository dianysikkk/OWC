import { useEffect, useState, useCallback, useRef } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { Vocabulary, VocabularyCategory, UserVocabulary } from '@/lib/types';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { Modal } from '@/components/ui/Modal';
import {
  Search, BookOpen, Star, Volume2, ChevronLeft, ChevronRight,
  Plus, Filter, Heart, AlertCircle, Check, X, Trash2, Sparkles
} from 'lucide-react';
import { speak } from '@/lib/utils';

const LEVELS = ['A1', 'A2', 'B1', 'B2', 'C1', 'C2'];

export function VocabularyPage() {
  const { user } = useAuth();
  const [words, setWords] = useState<Vocabulary[]>([]);
  const [categories, setCategories] = useState<VocabularyCategory[]>([]);
  const [userVocab, setUserVocab] = useState<Record<string, UserVocabulary>>({});
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [levelFilter, setLevelFilter] = useState('all');
  const [nmtOnly, setNmtOnly] = useState(false);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [selectedWord, setSelectedWord] = useState<Vocabulary | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [decks, setDecks] = useState<{ id: string; name: string }[]>([]);
  const [newDeckName, setNewDeckName] = useState('');
  const [customWord, setCustomWord] = useState({ word: '', translation_uk: '', example_en: '', example_uk: '', cefr_level: 'A1' });
  const [customError, setCustomError] = useState('');
  const [customSaving, setCustomSaving] = useState(false);
  const pageSize = 24;

  const loadCategories = useCallback(async () => {
    const { data } = await supabase.from('vocabulary_categories').select('*').order('sort_order');
    if (data) setCategories(data);
  }, []);

  const loadDecks = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('vocabulary_decks').select('id, name').eq('user_id', user.id).order('created_at');
    if (data) setDecks(data);
  }, [user]);

  const loadUserVocab = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('user_vocabulary').select('*').eq('user_id', user.id);
    if (data) {
      const map: Record<string, UserVocabulary> = {};
      data.forEach((uv: UserVocabulary) => { map[uv.vocabulary_id] = uv; });
      setUserVocab(map);
    }
  }, [user]);

  const loadWords = useCallback(async () => {
    setLoading(true);
    let query = supabase.from('vocabulary').select('*', { count: 'exact' });

    if (debouncedSearch) {
      const s = debouncedSearch.trim();
      query = query.or(`word.ilike.%${s}%,translation_uk.ilike.%${s}%,synonyms.ilike.%${s}%,antonyms.ilike.%${s}%,collocations.ilike.%${s}%`);
    }
    if (categoryFilter !== 'all') query = query.eq('category_id', categoryFilter);
    if (levelFilter !== 'all') query = query.eq('cefr_level', levelFilter);
    if (nmtOnly) query = query.eq('is_for_nmt', true);

    query = query.order('word').range(page * pageSize, (page + 1) * pageSize - 1);
    const { data, count } = await query;
    if (data) setWords(data);
    if (count !== null) setTotal(count);
    setLoading(false);
  }, [debouncedSearch, categoryFilter, levelFilter, nmtOnly, page]);

  useEffect(() => { loadCategories(); loadUserVocab(); loadDecks(); }, [loadCategories, loadUserVocab, loadDecks]);
  const searchTimer = useRef<ReturnType<typeof setTimeout>>();
  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => {
      setDebouncedSearch(search);
    }, 300);
    return () => { if (searchTimer.current) clearTimeout(searchTimer.current); };
  }, [search]);

  useEffect(() => { loadWords(); }, [loadWords]);
  useEffect(() => { setPage(0); }, [debouncedSearch, categoryFilter, levelFilter, nmtOnly]);

  const toggleFavorite = async (vocabId: string) => {
    if (!user) return;
    const existing = userVocab[vocabId];
    if (existing) {
      await supabase.from('user_vocabulary').update({ is_favorite: !existing.is_favorite }).eq('id', existing.id);
    } else {
      await supabase.from('user_vocabulary').insert({ user_id: user.id, vocabulary_id: vocabId, is_favorite: true });
    }
    loadUserVocab();
  };

  const addToVocab = async (vocabId: string) => {
    if (!user) return;
    if (userVocab[vocabId]) return;
    await supabase.from('user_vocabulary').insert({ user_id: user.id, vocabulary_id: vocabId });
    loadUserVocab();
  };

  const createDeck = async () => {
    if (!user || !newDeckName.trim()) return;
    const { data } = await supabase.from('vocabulary_decks').insert({ user_id: user.id, name: newDeckName.trim() }).select().single();
    if (data) {
      setDecks([...decks, { id: data.id, name: data.name }]);
      setNewDeckName('');
    }
  };

  const addToDeck = async (deckId: string, vocabId: string) => {
    await supabase.from('vocabulary_deck_items').insert({ deck_id: deckId, vocabulary_id: vocabId });
    setShowAddModal(false);
  };

  const addCustomWord = async () => {
    if (!user) return;
    if (!customWord.word.trim() || !customWord.translation_uk.trim()) {
      setCustomError('Слово та переклад обов\u2019язкові');
      return;
    }
    setCustomSaving(true);
    setCustomError('');
    const { data, error } = await supabase.from('vocabulary').insert({
      word: customWord.word.trim(),
      translation_uk: customWord.translation_uk.trim(),
      example_en: customWord.example_en.trim(),
      example_uk: customWord.example_uk.trim(),
      cefr_level: customWord.cefr_level,
      created_by: user.id,
    }).select().single();
    setCustomSaving(false);
    if (error) {
      setCustomError('Помилка збереження. Спробуйте ще раз.');
      return;
    }
    if (data) {
      await supabase.from('user_vocabulary').insert({ user_id: user.id, vocabulary_id: data.id });
      await loadUserVocab();
      setCustomWord({ word: '', translation_uk: '', example_en: '', example_uk: '', cefr_level: 'A1' });
      setShowCustomModal(false);
      loadWords();
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Словник</h1>
        <p className="text-sm text-navy-500 dark:text-navy-400">{total} слів у базі · {Object.keys(userVocab).length} у вашому словнику</p>
      </div>

      {/* Search & filters */}
      <div className="card p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="input pl-11"
              placeholder="Пошук слова або перекладу..."
            />
          </div>
          <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="input sm:w-48">
            <option value="all">Усі категорії</option>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name_uk}</option>)}
          </select>
          <select value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)} className="input sm:w-28">
            <option value="all">Усі рівні</option>
            {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
          </select>
          <button
            onClick={() => setNmtOnly(!nmtOnly)}
            className={`btn ${nmtOnly ? 'btn-primary' : 'btn-secondary'} whitespace-nowrap`}
          >
            <Filter className="w-4 h-4" />
            НМТ
          </button>
          <button
            onClick={() => setShowCustomModal(true)}
            className="btn-primary whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Додати слово
          </button>
        </div>
      </div>

      {/* Word grid */}
      {loading ? (
        <LoadingState />
      ) : words.length === 0 ? (
        <div className="space-y-4">
          <EmptyState icon={BookOpen} title="Слів не знайдено" description="Спробуйте змінити фільтри або пошук" />
          {debouncedSearch.trim() && (
            <div className="card p-6 text-center max-w-md mx-auto">
              <Sparkles className="w-10 h-10 text-primary-400 mx-auto mb-3" />
              <h3 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-2">
                Не знайшли «{debouncedSearch.trim()}»?
              </h3>
              <p className="text-sm text-navy-500 dark:text-navy-400 mb-4">
                Ви можете додати це слово власноруч — воно з’явиться у вашому словнику.
              </p>
              <button
                onClick={() => {
                  setCustomWord({
                    word: debouncedSearch.trim(),
                    translation_uk: '',
                    example_en: '',
                    example_uk: '',
                    cefr_level: 'B1',
                  });
                  setShowCustomModal(true);
                }}
                className="btn-primary"
              >
                <Plus className="w-4 h-4" />
                Додати «{debouncedSearch.trim()}»
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
          {words.map((word) => {
            const uv = userVocab[word.id];
            return (
              <div
                key={word.id}
                className="card card-hover p-4 cursor-pointer"
                onClick={() => setSelectedWord(word)}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-heading font-semibold text-navy-800 dark:text-navy-100 truncate">{word.word}</h3>
                      <button
                        onClick={(e) => { e.stopPropagation(); speak(word.word); }}
                        className="text-primary-500 hover:text-primary-600 flex-shrink-0"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                    <p className="text-sm text-navy-500 dark:text-navy-400 truncate">{word.translation_uk}</p>
                  </div>
                  <button
                    onClick={(e) => { e.stopPropagation(); toggleFavorite(word.id); }}
                    className={`flex-shrink-0 ${uv?.is_favorite ? 'text-accent-500' : 'text-navy-300 hover:text-navy-400'}`}
                  >
                    <Star className={`w-5 h-5 ${uv?.is_favorite ? 'fill-current' : ''}`} />
                  </button>
                </div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="badge-primary text-xs">{word.cefr_level}</span>
                  {word.is_for_nmt && <span className="badge-warning text-xs">НМТ</span>}
                  {uv?.is_learned && <span className="badge-success text-xs"><Check className="w-3 h-3" /> Вивчено</span>}
                  {uv?.is_difficult && <span className="badge-error text-xs"><AlertCircle className="w-3 h-3" /> Складне</span>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button onClick={() => setPage(Math.max(0, page - 1))} disabled={page === 0} className="btn-secondary">
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-sm text-navy-500 px-3">{page + 1} / {totalPages}</span>
          <button onClick={() => setPage(Math.min(totalPages - 1, page + 1))} disabled={page >= totalPages - 1} className="btn-secondary">
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Word detail modal */}
      <Modal open={!!selectedWord} onClose={() => setSelectedWord(null)} title="Слово" size="md">
        {selectedWord && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h2 className="font-heading text-2xl font-bold text-navy-900 dark:text-white">{selectedWord.word}</h2>
                <button onClick={() => speak(selectedWord.word)} className="text-primary-500 hover:text-primary-600">
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>
              <p className="text-lg text-navy-600 dark:text-navy-300">{selectedWord.translation_uk}</p>
              {selectedWord.transcription && <p className="text-sm text-navy-400 font-mono mt-1">{selectedWord.transcription}</p>}
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="badge-primary">{selectedWord.cefr_level}</span>
              {selectedWord.part_of_speech && <span className="badge-neutral">{selectedWord.part_of_speech}</span>}
              {selectedWord.is_for_nmt && <span className="badge-warning">Для НМТ</span>}
            </div>
            {selectedWord.example_en && (
              <div className="p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                <p className="text-sm text-navy-700 dark:text-navy-200 italic">"{selectedWord.example_en}"</p>
                <p className="text-xs text-navy-400 mt-1">{selectedWord.example_uk}</p>
              </div>
            )}
            {selectedWord.synonyms && (
              <div>
                <span className="text-xs font-medium text-navy-500">Синоніми:</span>
                <p className="text-sm text-navy-700 dark:text-navy-200">{selectedWord.synonyms}</p>
              </div>
            )}
            {selectedWord.common_mistakes && (
              <div className="p-3 rounded-xl bg-error-50 dark:bg-error-950/20">
                <span className="text-xs font-medium text-error-600">Типові помилки:</span>
                <p className="text-sm text-navy-700 dark:text-navy-200">{selectedWord.common_mistakes}</p>
              </div>
            )}
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => addToVocab(selectedWord.id)}
                disabled={!!userVocab[selectedWord.id]}
                className="btn-primary flex-1"
              >
                {userVocab[selectedWord.id] ? <><Check className="w-4 h-4" /> У словнику</> : <><Plus className="w-4 h-4" /> Додати</>}
              </button>
              <button onClick={() => setShowAddModal(true)} className="btn-secondary">
                <Plus className="w-4 h-4" /> У набір
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Add custom word modal */}
      <Modal open={showCustomModal} onClose={() => setShowCustomModal(false)} title="Додати своє слово" size="md">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">Слово (англ.) *</label>
              <input
                type="text"
                value={customWord.word}
                onChange={(e) => setCustomWord({ ...customWord, word: e.target.value })}
                className="input"
                placeholder="e.g. accomplish"
              />
            </div>
            <div>
              <label className="label">Переклад (укр.) *</label>
              <input
                type="text"
                value={customWord.translation_uk}
                onChange={(e) => setCustomWord({ ...customWord, translation_uk: e.target.value })}
                className="input"
                placeholder="напр. досягати"
              />
            </div>
          </div>
          <div>
            <label className="label">Рівень CEFR</label>
            <select
              value={customWord.cefr_level}
              onChange={(e) => setCustomWord({ ...customWord, cefr_level: e.target.value })}
              className="input"
            >
              {LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          <div>
            <label className="label">Приклад (англ.)</label>
            <input
              type="text"
              value={customWord.example_en}
              onChange={(e) => setCustomWord({ ...customWord, example_en: e.target.value })}
              className="input"
              placeholder="She accomplished her goal."
            />
          </div>
          <div>
            <label className="label">Переклад прикладу (укр.)</label>
            <input
              type="text"
              value={customWord.example_uk}
              onChange={(e) => setCustomWord({ ...customWord, example_uk: e.target.value })}
              className="input"
              placeholder="Вона досягла своєї мети."
            />
          </div>
          {customError && <p className="text-sm text-error-500 flex items-center gap-1"><AlertCircle className="w-4 h-4" /> {customError}</p>}
          <div className="flex gap-2">
            <button onClick={() => setShowCustomModal(false)} className="btn-secondary flex-1">Скасувати</button>
            <button onClick={addCustomWord} disabled={customSaving} className="btn-primary flex-1">
              {customSaving ? 'Збереження...' : 'Додати'}
            </button>
          </div>
        </div>
      </Modal>

      {/* Add to deck modal */}
      <Modal open={showAddModal} onClose={() => setShowAddModal(false)} title="Додати в набір" size="sm">
        <div className="space-y-3">
          {decks.length === 0 ? (
            <p className="text-sm text-navy-500 text-center py-4">У вас ще немає наборів. Створіть перший:</p>
          ) : (
            decks.map((deck) => (
              <button
                key={deck.id}
                onClick={() => selectedWord && addToDeck(deck.id, selectedWord.id)}
                className="w-full text-left p-3 rounded-xl bg-navy-50 dark:bg-navy-800/40 hover:bg-navy-100 dark:hover:bg-navy-800/60 text-sm font-medium text-navy-700 dark:text-navy-200"
              >
                {deck.name}
              </button>
            ))
          )}
          <div className="flex gap-2 pt-2 border-t border-navy-200 dark:border-navy-800">
            <input
              type="text"
              value={newDeckName}
              onChange={(e) => setNewDeckName(e.target.value)}
              className="input"
              placeholder="Назва нового набору"
            />
            <button onClick={createDeck} className="btn-primary">
              <Plus className="w-4 h-4" />
            </button>
          </div>
        </div>
      </Modal>
    </AppLayout>
  );
}
