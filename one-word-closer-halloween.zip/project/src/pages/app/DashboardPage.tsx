import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { ProgressRing, ProgressBar } from '@/components/ui/Progress';
import { EmptyState, LoadingState } from '@/components/ui/States';
import { supabase } from '@/lib/supabase';
import type { StudySession, StudyPlan, LessonProgress, Lesson, Module, Course, UserVocabulary, Vocabulary } from '@/lib/types';
import {
  Flame, BookOpen, Repeat, Clock, Target, TrendingUp,
  ChevronRight, ClipboardCheck, Zap, Check, Calendar, Award, Brain
} from 'lucide-react';
import { formatMinutes } from '@/lib/utils';

interface DashboardData {
  sessions: StudySession[];
  todayPlans: StudyPlan[];
  recentProgress: (LessonProgress & { lesson?: Lesson & { module?: Module & { course?: Course } } })[];
  dueReviews: (UserVocabulary & { vocabulary?: Vocabulary })[];
  wordsLearned: number;
  wordsTotal: number;
  lessonsCompleted: number;
  exercisesDone: number;
  studyTimeToday: number;
  studyTimeWeek: number;
  weekData: { date: string; minutes: number }[];
}

export function DashboardPage() {
  const { profile, user } = useAuth();
  const { navigate } = useRouter();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!user) return;

    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 6 * 86400000).toISOString().split('T')[0];

    const [sessions, todayPlans, progress, dueReviews, uvCount, lpCompleted, eaCount] = await Promise.all([
      supabase.from('study_sessions').select('*').eq('user_id', user.id).order('created_at', { ascending: false }).limit(50),
      supabase.from('study_plans').select('*').eq('user_id', user.id).eq('plan_date', today).order('created_at'),
      supabase.from('lesson_progress').select('*, lesson:lessons(*, module:modules(*, course:courses(*)))').eq('user_id', user.id).order('updated_at', { ascending: false }).limit(5),
      supabase.from('user_vocabulary').select('*, vocabulary:vocabulary(*)').eq('user_id', user.id).lte('sm2_next_review', today).limit(20),
      supabase.from('user_vocabulary').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('is_learned', true),
      supabase.from('lesson_progress').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('status', 'completed'),
      supabase.from('exercise_attempts').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
    ]);

    const allSessions = sessions.data || [];
    const todaySessions = allSessions.filter((s: StudySession) => s.studied_at === today);
    const studyTimeToday = todaySessions.reduce((sum: number, s: StudySession) => sum + s.duration_seconds, 0);
    const studyTimeWeek = allSessions
      .filter((s: StudySession) => s.studied_at >= weekAgo)
      .reduce((sum: number, s: StudySession) => sum + s.duration_seconds, 0);

    const weekData: { date: string; minutes: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 86400000).toISOString().split('T')[0];
      const minutes = Math.round(
        allSessions.filter((s: StudySession) => s.studied_at === d).reduce((sum: number, s: StudySession) => sum + s.duration_seconds, 0) / 60
      );
      weekData.push({ date: d, minutes });
    }

    setData({
      sessions: allSessions,
      todayPlans: todayPlans.data || [],
      recentProgress: (progress.data || []) as DashboardData['recentProgress'],
      dueReviews: (dueReviews.data || []) as DashboardData['dueReviews'],
      wordsLearned: uvCount.count || 0,
      wordsTotal: allSessions.reduce((sum: number, s: StudySession) => sum + s.items_studied, 0),
      lessonsCompleted: lpCompleted.count || 0,
      exercisesDone: eaCount.count || 0,
      studyTimeToday,
      studyTimeWeek,
      weekData,
    });
    setLoading(false);
  }, [user]);

  useEffect(() => { loadData(); }, [loadData]);

  const togglePlan = async (planId: string, completed: boolean) => {
    await supabase.from('study_plans').update({
      is_completed: !completed,
      completed_at: !completed ? new Date().toISOString() : null,
    }).eq('id', planId);
    loadData();
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;
  if (!data) return <AppLayout><EmptyState icon={BookOpen} title="Немає даних" description="Почніть навчання, щоб побачити прогрес" /></AppLayout>;

  const todayMinutes = Math.round(data.studyTimeToday / 60);
  const goalPercent = profile?.daily_goal_minutes ? Math.min(100, (todayMinutes / profile.daily_goal_minutes) * 100) : 0;
  const completedPlans = data.todayPlans.filter(p => p.is_completed).length;
  const maxWeekMinutes = Math.max(...data.weekData.map(d => d.minutes), 1);

  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Доброго ранку' : hour < 18 ? 'Доброго дня' : 'Доброго вечора';

  return (
    <AppLayout>
      {/* Header */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white">
            {greeting}, {profile?.display_name}!
          </h1>
          <p className="text-sm text-navy-500 dark:text-navy-400 mt-1">
            Рівень: {profile?.current_level} → Ціль: {profile?.target_level}
          </p>
        </div>
        <div className="flex items-center gap-3">
          {profile?.streak_days ? (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-accent-50 dark:bg-accent-950/30 text-accent-600 dark:text-accent-400">
              <Flame className="w-5 h-5" />
              <span className="font-semibold">{profile.streak_days}</span>
              <span className="text-xs">днів</span>
            </div>
          ) : null}
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-primary-50 dark:bg-primary-950/30 text-primary-600 dark:text-primary-400">
            <Zap className="w-5 h-5" />
            <span className="font-semibold">{profile?.total_xp || 0}</span>
            <span className="text-xs">XP</span>
          </div>
        </div>
      </div>

      {/* Top cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Daily goal */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <Target className="w-5 h-5 text-primary-500" />
            <span className="text-xs text-navy-400">Сьогодні</span>
          </div>
          <div className="flex items-center gap-3">
            <ProgressRing value={goalPercent} size={56} strokeWidth={5}>
              <span className="text-xs font-bold text-navy-700 dark:text-navy-200">{Math.round(goalPercent)}%</span>
            </ProgressRing>
            <div>
              <div className="text-lg font-bold text-navy-800 dark:text-navy-100">{todayMinutes}хв</div>
              <div className="text-xs text-navy-400">з {profile?.daily_goal_minutes}хв</div>
            </div>
          </div>
        </div>

        {/* Words learned */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <BookOpen className="w-5 h-5 text-primary-500" />
            <span className="text-xs text-navy-400">Слів вивчено</span>
          </div>
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{data.wordsLearned}</div>
          <ProgressBar value={data.wordsLearned} max={100} className="mt-2" />
        </div>

        {/* Due reviews */}
        <div className="card p-5 cursor-pointer card-hover" onClick={() => navigate('/review')}>
          <div className="flex items-center justify-between mb-3">
            <Repeat className="w-5 h-5 text-warning-500" />
            <span className="text-xs text-navy-400">Повторити</span>
          </div>
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{data.dueReviews.length}</div>
          <p className="text-xs text-navy-400 mt-1">слів до повторення</p>
        </div>

        {/* Lessons completed */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-3">
            <Check className="w-5 h-5 text-success-500" />
            <span className="text-xs text-navy-400">Уроків</span>
          </div>
          <div className="text-2xl font-bold text-navy-800 dark:text-navy-100">{data.lessonsCompleted}</div>
          <p className="text-xs text-navy-400 mt-1">завершено</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Continue learning */}
        <div className="lg:col-span-2 space-y-6">
          {data.recentProgress.length > 0 && data.recentProgress.some(p => p.status !== 'completed') && (
            <div className="card p-6">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Продовжити навчання</h2>
              {data.recentProgress
                .filter(p => p.status !== 'completed' && p.lesson)
                .slice(0, 2)
                .map((p) => (
                  <div key={p.id} className="flex items-center gap-4 p-4 rounded-xl bg-navy-50 dark:bg-navy-800/40">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center flex-shrink-0">
                      <BookOpen className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-navy-800 dark:text-navy-100 truncate">
                        {p.lesson?.title}
                      </div>
                      <div className="text-xs text-navy-400 mb-2">
                        {p.lesson?.module?.course?.title}
                      </div>
                      <ProgressBar value={p.progress_percent} />
                    </div>
                    <button
                      onClick={() => navigate('/courses-app')}
                      className="btn-primary flex-shrink-0"
                    >
                      Продовжити
                      <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                ))}
            </div>
          )}

          {/* Today's plan */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100">План на сьогодні</h2>
              <span className="text-xs text-navy-400">{completedPlans}/{data.todayPlans.length} виконано</span>
            </div>
            {data.todayPlans.length === 0 ? (
              <EmptyState
                icon={Calendar}
                title="План на сьогодні не створено"
                description="Заплануйте заняття у розділі календаря"
                action={<button onClick={() => navigate('/trainers')} className="btn-primary">Почати вправу</button>}
              />
            ) : (
              <div className="space-y-2">
                {data.todayPlans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`flex items-center gap-3 p-3 rounded-xl transition-colors cursor-pointer ${
                      plan.is_completed
                        ? 'bg-success-50 dark:bg-success-950/20'
                        : 'bg-navy-50 dark:bg-navy-800/40 hover:bg-navy-100 dark:hover:bg-navy-800/60'
                    }`}
                    onClick={() => togglePlan(plan.id, plan.is_completed)}
                  >
                    <button
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ${
                        plan.is_completed
                          ? 'border-success-500 bg-success-500 text-white'
                          : 'border-navy-300 dark:border-navy-600'
                      }`}
                    >
                      {plan.is_completed && <Check className="w-4 h-4" />}
                    </button>
                    <div className="flex-1 min-w-0">
                      <div className={`text-sm font-medium ${plan.is_completed ? 'text-navy-400 line-through' : 'text-navy-700 dark:text-navy-200'}`}>
                        {plan.title}
                      </div>
                      <div className="text-xs text-navy-400">{plan.task_type} · {plan.duration_minutes}хв</div>
                    </div>
                    <Clock className="w-4 h-4 text-navy-300 flex-shrink-0" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Week activity chart */}
          <div className="card p-6">
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Активність за тиждень</h2>
            <div className="flex items-end justify-between gap-2 h-32">
              {data.weekData.map((d, i) => {
                const dayName = new Date(d.date).toLocaleDateString('uk-UA', { weekday: 'short' });
                const height = d.minutes > 0 ? Math.max(8, (d.minutes / maxWeekMinutes) * 100) : 4;
                return (
                  <div key={i} className="flex-1 flex flex-col items-center gap-2">
                    <div className="w-full flex items-end justify-center" style={{ height: '100px' }}>
                      <div
                        className={`w-full max-w-[40px] rounded-t-lg transition-all ${
                          d.minutes > 0 ? 'bg-gradient-to-t from-primary-600 to-primary-400' : 'bg-navy-200 dark:bg-navy-800'
                        }`}
                        style={{ height: `${height}%` }}
                        title={`${d.minutes} хв`}
                      />
                    </div>
                    <span className="text-xs text-navy-400">{dayName}</span>
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-between mt-4 pt-4 border-t border-navy-200 dark:border-navy-800">
              <span className="text-sm text-navy-500">Всього за тиждень: <strong className="text-navy-700 dark:text-navy-200">{formatMinutes(Math.round(data.studyTimeWeek / 60))}</strong></span>
              <button onClick={() => navigate('/analytics')} className="text-sm text-primary-600 font-medium">Детальніше →</button>
            </div>
          </div>
          {/* Study Calendar */}
          <div className="card p-6">
            <h2 className="font-heading text-lg font-semibold text-navy-800 dark:text-navy-100 mb-4">Календар навчання</h2>
            <StudyCalendar sessions={data.sessions} />
          </div>
        </div>

        {/* Sidebar widgets */}
        <div className="space-y-6">
          {/* Quick actions */}
          <div className="card p-6">
            <h2 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-100 mb-3">Швидкий старт</h2>
            <div className="space-y-2">
              <button onClick={() => navigate('/review')} className="w-full flex items-center gap-3 p-3 rounded-xl bg-warning-50 dark:bg-warning-950/20 text-warning-700 dark:text-warning-300 hover:bg-warning-100 transition-colors">
                <Repeat className="w-5 h-5" />
                <div className="text-left flex-1">
                  <div className="text-sm font-medium">Повторення</div>
                  <div className="text-xs opacity-70">{data.dueReviews.length} слів</div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button onClick={() => navigate('/trainers')} className="w-full flex items-center gap-3 p-3 rounded-xl bg-primary-50 dark:bg-primary-950/20 text-primary-700 dark:text-primary-300 hover:bg-primary-100 transition-colors">
                <Brain className="w-5 h-5" />
                <div className="text-left flex-1">
                  <div className="text-sm font-medium">Тренажери</div>
                  <div className="text-xs opacity-70">9 типів вправ</div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
              <button onClick={() => navigate('/exam')} className="w-full flex items-center gap-3 p-3 rounded-xl bg-error-50 dark:bg-error-950/20 text-error-700 dark:text-error-300 hover:bg-error-100 transition-colors">
                <ClipboardCheck className="w-5 h-5" />
                <div className="text-left flex-1">
                  <div className="text-sm font-medium">Симулятор НМТ</div>
                  <div className="text-xs opacity-70">Пробний тест</div>
                </div>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Streak */}
          {profile?.streak_days ? (
            <div className="card p-6 bg-gradient-to-br from-accent-500 to-accent-700 border-0">
              <div className="flex items-center gap-3 mb-3">
                <Flame className="w-8 h-8 text-white" />
                <div>
                  <div className="text-2xl font-bold text-white">{profile.streak_days}</div>
                  <div className="text-xs text-accent-100">днів поспіль</div>
                </div>
              </div>
              <p className="text-xs text-accent-100">Продовжуйте серію — навчайтеся щодня!</p>
            </div>
          ) : null}

          {/* Achievements preview */}
          <div className="card p-6">
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-100">Досягнення</h2>
              <button onClick={() => navigate('/achievements')} className="text-xs text-primary-600">Усі →</button>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-accent-50 dark:bg-accent-950/30 flex items-center justify-center">
                <Award className="w-6 h-6 text-accent-500" />
              </div>
              <div>
                <div className="text-sm font-medium text-navy-700 dark:text-navy-200">{profile?.total_xp || 0} XP</div>
                <div className="text-xs text-navy-400">Натисніть для перегляду</div>
              </div>
            </div>
          </div>

          {/* Goals progress */}
          <div className="card p-6">
            <h2 className="font-heading text-sm font-semibold text-navy-800 dark:text-navy-100 mb-4">Мета та прогрес</h2>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <span className="text-navy-500">Рівень: {profile?.current_level} → {profile?.target_level}</span>
                </div>
                <ProgressBar value={Math.min(100, (data.wordsLearned / 100) * 100)} max={100} />
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-navy-100 dark:border-navy-800">
                <span className="text-sm text-navy-500 flex items-center gap-2"><Target className="w-4 h-4" /> Денна мета</span>
                <span className="font-semibold text-navy-700 dark:text-navy-200">{todayMinutes}/{profile?.daily_goal_minutes}хв</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-navy-500 flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Вправ виконано</span>
                <span className="font-semibold text-navy-700 dark:text-navy-200">{data.exercisesDone}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-navy-500 flex items-center gap-2"><BookOpen className="w-4 h-4" /> Слів вивчено</span>
                <span className="font-semibold text-navy-700 dark:text-navy-200">{data.wordsLearned}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-navy-500 flex items-center gap-2"><Check className="w-4 h-4" /> Уроків завершено</span>
                <span className="font-semibold text-navy-700 dark:text-navy-200">{data.lessonsCompleted}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

function StudyCalendar({ sessions }: { sessions: StudySession[] }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startWeekday = (firstDay.getDay() + 6) % 7;

  const studyDates = new Map<string, number>();
  sessions.forEach((s) => {
    if (s.studied_at) {
      const existing = studyDates.get(s.studied_at) || 0;
      studyDates.set(s.studied_at, existing + s.duration_seconds);
    }
  });

  const today = new Date().toISOString().split('T')[0];
  const monthName = currentMonth.toLocaleDateString('uk-UA', { month: 'long', year: 'numeric' });

  const cells: (number | null)[] = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);

  const getIntensity = (day: number): number => {
    const dateStr = new Date(year, month, day).toISOString().split('T')[0];
    const seconds = studyDates.get(dateStr) || 0;
    if (seconds === 0) return 0;
    if (seconds < 300) return 1;
    if (seconds < 900) return 2;
    if (seconds < 1800) return 3;
    return 4;
  };

  const intensityColors = [
    'bg-navy-100 dark:bg-navy-800',
    'bg-success-200 dark:bg-success-900/40',
    'bg-success-300 dark:bg-success-800/60',
    'bg-success-400 dark:bg-success-700/70',
    'bg-success-500 dark:bg-success-600',
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <button
          onClick={() => setCurrentMonth(new Date(year, month - 1, 1))}
          className="btn-ghost p-1.5"
        >
          <ChevronRight className="w-4 h-4 rotate-180" />
        </button>
        <span className="text-sm font-medium text-navy-700 dark:text-navy-200 capitalize">{monthName}</span>
        <button
          onClick={() => setCurrentMonth(new Date(year, month + 1, 1))}
          className="btn-ghost p-1.5"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1.5 mb-2">
        {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'].map((d) => (
          <div key={d} className="text-center text-xs text-navy-400 font-medium py-1">{d}</div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1.5">
        {cells.map((day, i) => {
          if (day === null) return <div key={i} />;
          const dateStr = new Date(year, month, day).toISOString().split('T')[0];
          const isToday = dateStr === today;
          const intensity = getIntensity(day);
          return (
            <div
              key={i}
              className={`aspect-square rounded-lg flex items-center justify-center text-xs font-medium transition-all ${
                isToday ? 'ring-2 ring-primary-500 ring-offset-1 dark:ring-offset-navy-900' : ''
              } ${
                intensity > 0
                  ? `${intensityColors[intensity]} ${intensity >= 3 ? 'text-white' : 'text-navy-700 dark:text-navy-200'}`
                  : 'bg-navy-50 dark:bg-navy-800/40 text-navy-400'
              }`}
              title={intensity > 0 ? `${Math.round((studyDates.get(dateStr) || 0) / 60)} хв` : ''}
            >
              {day}
            </div>
          );
        })}
      </div>
      <div className="flex items-center gap-2 mt-4 pt-3 border-t border-navy-100 dark:border-navy-800">
        <span className="text-xs text-navy-400">Менше</span>
        {intensityColors.map((c, i) => (
          <div key={i} className={`w-3 h-3 rounded ${c}`} />
        ))}
        <span className="text-xs text-navy-400">Більше</span>
      </div>
    </div>
  );
}
