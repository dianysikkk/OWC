import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { AppLayout } from '@/components/layout/AppLayout';
import { supabase } from '@/lib/supabase';
import type { Achievement, UserAchievement, StudySession } from '@/lib/types';
import { LoadingState, EmptyState } from '@/components/ui/States';
import { Trophy, Flame, Zap, BookOpen, Check, ClipboardCheck, Repeat, Crown, Award, Lock } from 'lucide-react';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  'book-open': BookOpen,
  'play-circle': BookOpen,
  'flame': Flame,
  'clipboard-check': ClipboardCheck,
  'trophy': Trophy,
  'crown': Crown,
  'repeat': Repeat,
};

export function AchievementsPage() {
  const { user, profile } = useAuth();
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [earned, setEarned] = useState<Record<string, UserAchievement>>({});
  const [stats, setStats] = useState({ wordsLearned: 0, lessonsCompleted: 0, reviewsDone: 0, examsCompleted: 0, perfectExercises: 0, streakDays: 0, trainersDone: 0 });
  const [loading, setLoading] = useState(true);

  const loadData = useCallback(async () => {
    if (!user) return;
    const [achRes, uaRes] = await Promise.all([
      supabase.from('achievements').select('*').order('threshold'),
      supabase.from('user_achievements').select('*, achievement:achievements(*)').eq('user_id', user.id),
    ]);

    if (achRes.data) setAchievements(achRes.data as Achievement[]);
    const map: Record<string, UserAchievement> = {};
    (uaRes.data || []).forEach((ua: UserAchievement) => { map[ua.achievement_id] = ua; });
    setEarned(map);

    // Calculate real stats
    const [uvCount, lpCount, revCount, eaCount, exAttempts, ssCount] = await Promise.all([
      supabase.from('user_vocabulary').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('is_learned', true),
      supabase.from('lesson_progress').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('status', 'completed'),
      supabase.from('vocabulary_reviews').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
      supabase.from('exam_attempts').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('status', 'completed'),
      supabase.from('exercise_attempts').select('score, total_questions').eq('user_id', user.id),
      supabase.from('study_sessions').select('id', { count: 'exact', head: true }).eq('user_id', user.id).like('session_type', 'trainer_%'),
    ]);

    const exData = exAttempts.data || [];
    const perfect = exData.filter((a: { score: number; total_questions: number }) => a.total_questions > 0 && a.score === a.total_questions).length;

    setStats({
      wordsLearned: uvCount.count || 0,
      lessonsCompleted: lpCount.count || 0,
      reviewsDone: revCount.count || 0,
      examsCompleted: eaCount.count || 0,
      perfectExercises: perfect,
      streakDays: profile?.streak_days || 0,
      trainersDone: ssCount.count || 0,
    });
    setLoading(false);
  }, [user, profile]);

  useEffect(() => { loadData(); }, [loadData]);

  const getProgress = (achievement: Achievement): { current: number; target: number } => {
    const metricMap: Record<string, number> = {
      words_learned: stats.wordsLearned,
      lessons_completed: stats.lessonsCompleted,
      streak_days: stats.streakDays,
      exams_completed: stats.examsCompleted,
      perfect_exercises: stats.perfectExercises,
      reviews_done: stats.reviewsDone,
      trainers_done: stats.trainersDone,
    };
    return { current: metricMap[achievement.metric] || 0, target: achievement.threshold };
  };

  if (loading) return <AppLayout><LoadingState /></AppLayout>;

  const earnedCount = Object.keys(earned).length;

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">Досягнення</h1>
        <p className="text-sm text-navy-500 dark:text-navy-400">{earnedCount} з {achievements.length} отримано · {profile?.total_xp || 0} XP</p>
      </div>

      {/* XP card */}
      <div className="card p-6 mb-6 bg-gradient-to-br from-primary-600 to-primary-800 border-0">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
            <Zap className="w-8 h-8 text-white" />
          </div>
          <div>
            <div className="text-3xl font-bold text-white">{profile?.total_xp || 0}</div>
            <div className="text-sm text-primary-100">загальний досвід (XP)</div>
          </div>
        </div>
      </div>

      {/* Stats summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {[
          { label: 'Слів', value: stats.wordsLearned, icon: BookOpen },
          { label: 'Уроків', value: stats.lessonsCompleted, icon: Check },
          { label: 'Повторень', value: stats.reviewsDone, icon: Repeat },
          { label: 'Тестів', value: stats.examsCompleted, icon: ClipboardCheck },
          { label: 'Ідеально', value: stats.perfectExercises, icon: Trophy },
          { label: 'Серія', value: stats.streakDays, icon: Flame },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="card p-3 text-center">
              <Icon className="w-5 h-5 text-primary-500 mx-auto mb-1" />
              <div className="text-xl font-bold text-navy-800 dark:text-navy-100">{s.value}</div>
              <div className="text-xs text-navy-400">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Achievement grid */}
      {achievements.length === 0 ? (
        <EmptyState icon={Award} title="Досягнень поки немає" description="Вони з'являться з часом" />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {achievements.map((ach) => {
            const isEarned = !!earned[ach.id];
            const { current, target } = getProgress(ach);
            const progress = Math.min(100, (current / target) * 100);
            const Icon = iconMap[ach.icon] || Trophy;

            return (
              <div
                key={ach.id}
                className={`card p-5 ${isEarned ? 'border-accent-300 dark:border-accent-800 bg-accent-50/30 dark:bg-accent-950/10' : ''}`}
              >
                <div className="flex items-start gap-3 mb-3">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                    isEarned
                      ? 'bg-gradient-to-br from-accent-400 to-accent-600 text-white shadow-md'
                      : 'bg-navy-100 dark:bg-navy-800 text-navy-400'
                  }`}>
                    {isEarned ? <Icon className="w-6 h-6" /> : <Lock className="w-5 h-5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className={`font-heading font-semibold ${isEarned ? 'text-navy-800 dark:text-navy-100' : 'text-navy-600 dark:text-navy-300'}`}>
                      {ach.title_uk}
                    </h3>
                    <p className="text-xs text-navy-400 mt-0.5">{ach.description_uk}</p>
                  </div>
                </div>

                {isEarned ? (
                  <div className="flex items-center justify-between">
                    <span className="badge-success"><Check className="w-3 h-3" /> Отримано</span>
                    <span className="text-xs font-semibold text-accent-600">+{ach.xp_reward} XP</span>
                  </div>
                ) : (
                  <div>
                    <div className="flex items-center justify-between text-xs text-navy-400 mb-1">
                      <span>{current} / {target}</span>
                      <span className="font-medium text-accent-500">+{ach.xp_reward} XP</span>
                    </div>
                    <div className="h-2 rounded-full bg-navy-200 dark:bg-navy-800 overflow-hidden">
                      <div className="h-full bg-primary-500 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </AppLayout>
  );
}
