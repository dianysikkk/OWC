import { useState } from 'react';
import { ArrowRight, ArrowLeft, Check, Target, Clock, TrendingUp, Sparkles } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useRouter } from '@/context/RouterContext';

const LEVELS = [
  { value: 'A1', label: 'A1 — Початківець', desc: 'Тільки починаю вивчати англійську' },
  { value: 'A2', label: 'A2 — Базовий', desc: 'Розумію прості фрази і тексти' },
  { value: 'B1', label: 'B1 — Середній', desc: 'Можу спілкуватися на знайомі теми' },
  { value: 'B2', label: 'B2 — Вище середнього', desc: 'Вільно спілкуюся на більшість тем' },
  { value: 'C1', label: 'C1 — Просунутий', desc: 'Володію мовою майже вільно' },
];

const TARGETS = [
  { value: 'B1', label: 'Досягти рівня B1' },
  { value: 'B2', label: 'Досягти рівня B2' },
  { value: 'C1', label: 'Досягти рівня C1' },
];

const GOALS = [
  { minutes: 10, label: '10 хв', desc: 'Легкий старт' },
  { minutes: 15, label: '15 хв', desc: 'Регулярно' },
  { minutes: 30, label: '30 хв', desc: 'Серйозний підхід' },
  { minutes: 60, label: '1 год', desc: 'Інтенсивне навчання' },
];

const SKILLS = [
  'Словниковий запас', 'Граматика', 'Аудіювання', 'Читання', 'Письмо', 'Розмовна практика',
];

const TOPICS = [
  'Подорожі', 'Робота', 'Навчання', 'Технології', 'Медицина', 'Культура', 'Дозвілля', 'Бізнес',
];

export function OnboardingPage() {
  const { completeOnboarding } = useAuth();
  const { navigate } = useRouter();
  const [step, setStep] = useState(0);
  const [level, setLevel] = useState('');
  const [target, setTarget] = useState('');
  const [goal, setGoal] = useState(15);
  const [skills, setSkills] = useState<string[]>([]);
  const [topics, setTopics] = useState<string[]>([]);
  const [prepNMT, setPrepNMT] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const steps = ['Рівень', 'Мета', 'Час', 'Навички', 'Теми', 'НМТ'];

  const toggle = (arr: string[], item: string, setter: (v: string[]) => void) => {
    setter(arr.includes(item) ? arr.filter((x) => x !== item) : [...arr, item]);
  };

  const handleFinish = async () => {
    setLoading(true);
    setError('');
    const { error } = await completeOnboarding({
      current_level: level || 'A1',
      target_level: target || 'B1',
      daily_goal_minutes: goal,
    });
    setLoading(false);
    if (error) setError(error);
    else navigate('/dashboard');
  };

  const canProceed = () => {
    if (step === 0) return level;
    if (step === 1) return target;
    if (step === 2) return goal;
    if (step === 3) return skills.length > 0;
    if (step === 4) return topics.length > 0;
    return true;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-navy-50 via-primary-50/30 to-navy-50 dark:from-navy-950 dark:via-primary-950/20 dark:to-navy-950 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-3">
            {steps.map((s, i) => (
              <div key={s} className="flex items-center flex-1 last:flex-none">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold transition-all ${
                  i < step ? 'bg-success-500 text-white' :
                  i === step ? 'bg-primary-600 text-white' :
                  'bg-navy-200 dark:bg-navy-800 text-navy-400'
                }`}>
                  {i < step ? <Check className="w-4 h-4" /> : i + 1}
                </div>
                {i < steps.length - 1 && (
                  <div className={`flex-1 h-0.5 mx-1 rounded ${i < step ? 'bg-success-500' : 'bg-navy-200 dark:bg-navy-800'}`} />
                )}
              </div>
            ))}
          </div>
          <p className="text-sm text-navy-500 text-center">Крок {step + 1} з {steps.length}: {steps[step]}</p>
        </div>

        <div className="card p-6 sm:p-8 shadow-lg">
          {step === 0 && (
            <div className="space-y-3">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Який у вас приблизний рівень англійської?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Це орієнтовна оцінка, не офіційний іспит</p>
              {LEVELS.map((l) => (
                <button
                  key={l.value}
                  onClick={() => setLevel(l.value)}
                  className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                    level === l.value
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30'
                      : 'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                  }`}
                >
                  <div className="font-semibold text-navy-800 dark:text-navy-100">{l.label}</div>
                  <div className="text-sm text-navy-500">{l.desc}</div>
                </button>
              ))}
            </div>
          )}

          {step === 1 && (
            <div className="space-y-3">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Яка ваша мета?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Ми створимо персональний план під вашу ціль</p>
              {TARGETS.map((t) => (
                <button
                  key={t.value}
                  onClick={() => setTarget(t.value)}
                  className={`w-full text-left p-4 rounded-xl border-2 flex items-center gap-3 transition-all ${
                    target === t.value
                      ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30'
                      : 'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                  }`}
                >
                  <Target className="w-5 h-5 text-primary-500" />
                  <span className="font-medium text-navy-800 dark:text-navy-100">{t.label}</span>
                </button>
              ))}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Скільки часу ви можете приділяти щодня?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Ви зможете змінити це пізніше</p>
              <div className="grid grid-cols-2 gap-3">
                {GOALS.map((g) => (
                  <button
                    key={g.minutes}
                    onClick={() => setGoal(g.minutes)}
                    className={`p-5 rounded-xl border-2 text-center transition-all ${
                      goal === g.minutes
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30'
                        : 'border-navy-200 dark:border-navy-800 hover:border-primary-300'
                    }`}
                  >
                    <Clock className="w-6 h-6 mx-auto mb-2 text-primary-500" />
                    <div className="font-bold text-lg text-navy-800 dark:text-navy-100">{g.label}</div>
                    <div className="text-xs text-navy-500">{g.desc}</div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Які навички хочете покращити?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Оберіть одну або кілька</p>
              <div className="grid grid-cols-2 gap-2">
                {SKILLS.map((s) => (
                  <button
                    key={s}
                    onClick={() => toggle(skills, s, setSkills)}
                    className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                      skills.includes(s)
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30 text-primary-700 dark:text-primary-300'
                        : 'border-navy-200 dark:border-navy-800 text-navy-600 dark:text-navy-300'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-3">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Які теми вам цікаві?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Ми підберемо матеріали під ваші інтереси</p>
              <div className="grid grid-cols-2 gap-2">
                {TOPICS.map((t) => (
                  <button
                    key={t}
                    onClick={() => toggle(topics, t, setTopics)}
                    className={`p-3 rounded-xl border-2 text-sm font-medium transition-all ${
                      topics.includes(t)
                        ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30 text-primary-700 dark:text-primary-300'
                        : 'border-navy-200 dark:border-navy-800 text-navy-600 dark:text-navy-300'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          )}

          {step === 5 && (
            <div className="space-y-4">
              <h2 className="font-heading text-xl font-bold text-navy-900 dark:text-white mb-1">
                Чи готуєтеся ви до НМТ?
              </h2>
              <p className="text-sm text-navy-500 mb-4">Ми додамо матеріали для підготовки до вашого плану</p>
              <button
                onClick={() => setPrepNMT(true)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                  prepNMT ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30' : 'border-navy-200 dark:border-navy-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Sparkles className="w-5 h-5 text-primary-500" />
                  <div>
                    <div className="font-semibold text-navy-800 dark:text-navy-100">Так, готуюся до НМТ</div>
                    <div className="text-sm text-navy-500">Отримаєте доступ до тренувальних тестів та словника для НМТ</div>
                  </div>
                </div>
              </button>
              <button
                onClick={() => setPrepNMT(false)}
                className={`w-full text-left p-4 rounded-xl border-2 transition-all ${
                  !prepNMT ? 'border-primary-500 bg-primary-50 dark:bg-primary-950/30' : 'border-navy-200 dark:border-navy-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <TrendingUp className="w-5 h-5 text-navy-400" />
                  <div>
                    <div className="font-semibold text-navy-800 dark:text-navy-100">Ні, просто вивчаю англійську</div>
                    <div className="text-sm text-navy-500">Ви зможете додати НМТ-підготовку пізніше</div>
                  </div>
                </div>
              </button>
            </div>
          )}

          {error && <p className="text-sm text-error-500 mt-4">{error}</p>}

          <div className="flex items-center justify-between mt-6 pt-6 border-t border-navy-200 dark:border-navy-800">
            <button
              onClick={() => step > 0 && setStep(step - 1)}
              disabled={step === 0}
              className="btn-secondary"
            >
              <ArrowLeft className="w-4 h-4" />
              Назад
            </button>
            {step < steps.length - 1 ? (
              <button
                onClick={() => setStep(step + 1)}
                disabled={!canProceed()}
                className="btn-primary"
              >
                Далі
                <ArrowRight className="w-4 h-4" />
              </button>
            ) : (
              <button onClick={handleFinish} disabled={loading} className="btn-primary">
                {loading ? 'Збереження...' : 'Почати навчання'}
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
