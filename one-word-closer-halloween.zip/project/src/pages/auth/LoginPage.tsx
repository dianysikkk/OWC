import { useState, FormEvent } from 'react';
import { Mail, Lock, User, AlertCircle, ArrowRight, GraduationCap } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';

export function LoginPage() {
  const { navigate } = useRouter();
  const { signIn, resetPassword } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [showReset, setShowReset] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    const { error } = await signIn(email, password);
    setLoading(false);
    if (error) {
      setError(error === 'Invalid login credentials' ? 'Невірний email або пароль' : error);
    } else {
      navigate('/dashboard');
    }
  };

  const handleReset = async () => {
    if (!email) { setError('Введіть email'); return; }
    setLoading(true);
    const { error } = await resetPassword(email);
    setLoading(false);
    if (error) setError(error);
    else setResetSent(true);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-navy-50 via-primary-50/30 to-navy-50 dark:from-navy-950 dark:via-primary-950/20 dark:to-navy-950">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <button onClick={() => navigate('/')} className="inline-flex items-center gap-2 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
          </button>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">
            {showReset ? 'Відновлення пароля' : 'Вхід у кабінет'}
          </h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">
            {showReset ? 'Введіть email для відновлення' : 'Раді бачити вас знову'}
          </p>
        </div>

        <div className="card p-6 shadow-lg">
          {resetSent ? (
            <div className="text-center py-4">
              <p className="text-sm text-navy-600 dark:text-navy-300">
                Інструкції з відновлення пароля надіслано на вашу пошту.
              </p>
              <button onClick={() => { setShowReset(false); setResetSent(false); }} className="btn-secondary mt-4">
                Повернутися до входу
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="input pl-11"
                    placeholder="email@example.com"
                  />
                </div>
              </div>
              {!showReset && (
                <div>
                  <label className="label">Пароль</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="input pl-11"
                      placeholder="••••••••"
                    />
                  </div>
                </div>
              )}

              {error && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-error-50 dark:bg-error-950/30 text-error-700 dark:text-error-300 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}

              {showReset ? (
                <button type="button" onClick={handleReset} disabled={loading} className="btn-primary w-full">
                  {loading ? 'Відправка...' : 'Надіслати інструкції'}
                </button>
              ) : (
                <button type="submit" disabled={loading} className="btn-primary w-full">
                  {loading ? 'Вхід...' : 'Увійти'}
                  {!loading && <ArrowRight className="w-4 h-4" />}
                </button>
              )}

              {!showReset && (
                <button type="button" onClick={() => setShowReset(true)} className="text-sm text-primary-600 hover:text-primary-700 w-full text-center">
                  Забули пароль?
                </button>
              )}
            </form>
          )}
        </div>

        <p className="text-center text-sm text-navy-500 dark:text-navy-400 mt-6">
          {showReset ? (
            <button onClick={() => setShowReset(false)} className="text-primary-600 hover:text-primary-700 font-medium">
              ← Повернутися до входу
            </button>
          ) : (
            <>Немає акаунта? <button onClick={() => navigate('/register')} className="text-primary-600 hover:text-primary-700 font-medium">Зареєструватися</button></>
          )}
        </p>
      </div>
    </div>
  );
}
