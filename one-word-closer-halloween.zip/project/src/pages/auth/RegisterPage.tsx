import { useState, FormEvent } from 'react';
import { Mail, Lock, User, AlertCircle, ArrowRight, GraduationCap, Check } from 'lucide-react';
import { useRouter } from '@/context/RouterContext';
import { useAuth } from '@/context/AuthContext';

export function RegisterPage() {
  const { navigate } = useRouter();
  const { signUp } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const passwordsDiffer = confirm.length > 0 && password !== confirm;
  const passwordTooShort = password.length > 0 && password.length < 6;

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError('');

    if (passwordTooShort) { setError('Пароль повинен містити мінімум 6 символів'); return; }
    if (passwordsDiffer) { setError('Паролі не співпадають'); return; }

    setLoading(true);
    const { error } = await signUp(email, password, name);
    setLoading(false);

    if (error) {
      if (error.includes('already registered')) setError('Цей email вже зареєстрований');
      else setError(error);
    } else {
      setSuccess(true);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-navy-50 via-primary-50/30 to-navy-50 dark:from-navy-950 dark:via-primary-950/20 dark:to-navy-950">
        <div className="w-full max-w-md text-center">
          <div className="w-16 h-16 rounded-2xl bg-success-100 dark:bg-success-900/30 flex items-center justify-center mx-auto mb-6">
            <Check className="w-8 h-8 text-success-600 dark:text-success-400" />
          </div>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-2">
            Акаунт створено!
          </h1>
          <p className="text-sm text-navy-500 dark:text-navy-400 mb-6">
            Ви успішно зареєструвалися. Тепер можете увійти у свій кабінет.
          </p>
          <button onClick={() => navigate('/login')} className="btn-primary">
            Увійти
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-navy-50 via-primary-50/30 to-navy-50 dark:from-navy-950 dark:via-primary-950/20 dark:to-navy-950">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <button onClick={() => navigate('/')} className="inline-flex items-center gap-2 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center shadow-lg">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
          </button>
          <h1 className="font-heading text-2xl font-bold text-navy-900 dark:text-white mb-1">
            Створити акаунт
          </h1>
          <p className="text-sm text-navy-500 dark:text-navy-400">
            Почніть безкоштовне навчання прямо зараз
          </p>
        </div>

        <div className="card p-6 shadow-lg">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Ім'я</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="input pl-11"
                  placeholder="Ваше ім'я"
                />
              </div>
            </div>
            <div>
              <label className="label">Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="input pl-11"
                  placeholder="email@example.com"
                />
              </div>
            </div>
            <div>
              <label className="label">Пароль</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="input pl-11"
                  placeholder="мінімум 6 символів"
                />
              </div>
              {passwordTooShort && <p className="text-xs text-error-500 mt-1">Пароль занадто короткий</p>}
            </div>
            <div>
              <label className="label">Підтвердити пароль</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-navy-400" />
                <input
                  type="password"
                  required
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  className={`input pl-11 ${passwordsDiffer ? 'border-error-400' : ''}`}
                  placeholder="повторіть пароль"
                />
              </div>
              {passwordsDiffer && <p className="text-xs text-error-500 mt-1">Паролі не співпадають</p>}
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-error-50 dark:bg-error-950/30 text-error-700 dark:text-error-300 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Створення...' : 'Зареєструватися'}
              {!loading && <ArrowRight className="w-4 h-4" />}
            </button>
          </form>

          <p className="text-xs text-navy-400 text-center mt-4">
            Реєструючись, ви погоджуєтесь з{' '}
            <button onClick={() => navigate('/terms')} className="text-primary-600 hover:underline">умовами користування</button>
            {' '}та{' '}
            <button onClick={() => navigate('/privacy')} className="text-primary-600 hover:underline">політикою конфіденційності</button>
          </p>
        </div>

        <p className="text-center text-sm text-navy-500 dark:text-navy-400 mt-6">
          Вже є акаунт? <button onClick={() => navigate('/login')} className="text-primary-600 hover:text-primary-700 font-medium">Увійти</button>
        </p>
      </div>
    </div>
  );
}
