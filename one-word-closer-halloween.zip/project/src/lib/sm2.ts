export interface SM2State {
  interval: number;
  repetitions: number;
  easiness: number;
  nextReview: string;
}

/**
 * SM-2 Spaced Repetition Algorithm
 * quality: 0-5 (0=complete fail, 5=perfect)
 * Returns updated state with next review date
 */
export function sm2(
  state: { interval: number; repetitions: number; easiness: number },
  quality: number
): SM2State {
  let { interval, repetitions, easiness } = state;

  if (quality < 3) {
    repetitions = 0;
    interval = 1;
  } else {
    if (repetitions === 0) {
      interval = 1;
    } else if (repetitions === 1) {
      interval = 6;
    } else {
      interval = Math.round(interval * easiness);
    }
    repetitions += 1;
  }

  easiness = easiness + (0.1 - (5 - quality) * (0.08 + (5 - quality) * 0.02));
  if (easiness < 1.3) easiness = 1.3;

  const next = new Date();
  next.setDate(next.getDate() + interval);

  return {
    interval,
    repetitions,
    easiness: Math.round(easiness * 100) / 100,
    nextReview: next.toISOString().split('T')[0],
  };
}
