/*
# Seed exercises, B1-B2 NMT exam, and expand achievements

1. Exercises
- Creates exercises for 3 existing A1 lessons (greetings, pronouns, to be)
- Each exercise has 3-4 multiple-choice questions with 4 options each
2. NMT B1-B2 Exam
- New exam variant: "Тренувальний варіант НМТ №4 (B1-B2)"
- 15 questions at B1-B2 difficulty
3. Achievements
- Adds 6 new achievements
4. Security
- All INSERT-only into existing tables with existing RLS policies
*/

DO $$
DECLARE
  _ex1_id uuid;
  _ex2_id uuid;
  _ex3_id uuid;
  _q_id uuid;
BEGIN
  -- Exercise 1: Greetings
  INSERT INTO exercises (lesson_id, title, exercise_type, description)
  VALUES ('6261e917-54e0-4997-86b9-a32d05137bba', 'Вправа: Привітання', 'multiple_choice', 'Перевірте свої знання привітань та знайомств')
  RETURNING id INTO _ex1_id;

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex1_id, 'How do you greet someone in the morning?', 'Good morning', 'Think about time-specific greetings', 'Good morning is used before noon.', 0)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Good morning', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Good night', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Good evening', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Goodbye', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex1_id, 'What do you say when you meet someone for the first time?', 'Nice to meet you', 'Common introductory phrase', 'Nice to meet you is the standard polite response when meeting someone new.', 1)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Nice to meet you', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'See you later', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Thank you', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Sorry', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex1_id, 'How do you ask someone''s name?', 'What is your name?', 'Use a question word + is + possessive', 'What is your name? is the standard polite question to ask for a name.', 2)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'What is your name?', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'How are you?', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Where are you?', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Who is he?', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex1_id, 'Complete: "Hello, ___ name is John."', 'my', 'Possessive adjective for "I"', 'my is the possessive adjective for the first person singular.', 3)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'my', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'I', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'me', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'mine', false, 3);

  -- Exercise 2: Pronouns
  INSERT INTO exercises (lesson_id, title, exercise_type, description)
  VALUES ('7a02336a-c5ef-4cd7-b1ef-c597f6a1065b', 'Вправа: Займенники', 'multiple_choice', 'Особисті займенники в англійській мові')
  RETURNING id INTO _ex2_id;

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex2_id, 'Which pronoun replaces "Sarah"?', 'she', 'Sarah is a female singular', 'she is used for a singular female.', 0)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'she', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'he', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'it', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'they', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex2_id, 'Which pronoun replaces "John and Mary"?', 'they', 'Two or more people = plural', 'they is used for plural subjects (two or more people).', 1)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'they', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'we', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'she', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'he', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex2_id, 'Complete: "___ are students."', 'We', 'First person plural', 'We is the subject pronoun for the speaker + others.', 2)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'We', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Us', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Our', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'Ours', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex2_id, 'Which is an object pronoun?', 'me', 'Object pronouns receive the action', 'me is the object form of I. Object pronouns: me, you, him, her, it, us, them.', 3)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'me', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'I', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'we', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'she', false, 3);

  -- Exercise 3: To be
  INSERT INTO exercises (lesson_id, title, exercise_type, description)
  VALUES ('3e3f9103-6246-49be-87ce-804e25645e8e', 'Вправа: Дієслово to be', 'multiple_choice', 'Форми дієслова to be в Present Simple')
  RETURNING id INTO _ex3_id;

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex3_id, 'Complete: "I ___ a student."', 'am', 'First person singular of to be', 'am is the first person singular form of to be: I am.', 0)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'am', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'is', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'are', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'be', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex3_id, 'Complete: "She ___ from Ukraine."', 'is', 'Third person singular feminine', 'is is used with he/she/it in Present Simple.', 1)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'is', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'am', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'are', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'be', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex3_id, 'Complete: "They ___ my friends."', 'are', 'Third person plural', 'are is used with we/they/you in Present Simple.', 2)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'are', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'is', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'am', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'be', false, 3);

  INSERT INTO exercise_questions (exercise_id, question_text, correct_answer, hint, explanation, sort_order)
  VALUES (_ex3_id, 'Make negative: "He is a teacher."', 'He is not a teacher.', 'Add not after the verb to be', 'To make negative with to be, add not: He is not / He isn''t.', 3)
  RETURNING id INTO _q_id;
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'He is not a teacher.', true, 0);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'He not is a teacher.', false, 1);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'He don''t is a teacher.', false, 2);
  INSERT INTO exercise_options (question_id, option_text, is_correct, sort_order) VALUES (_q_id, 'He no is a teacher.', false, 3);
END $$;

-- ============================================================
-- NMT B1-B2 Exam Variant
-- ============================================================

INSERT INTO exam_variants (title, description, duration_minutes, is_published)
VALUES ('Тренувальний варіант НМТ №4 (B1-B2)', 'Тест середнього рівня B1-B2: умовні речення, непряма мова, фразові дієслова, відносні займенники, читання.', 60, true);

INSERT INTO exam_questions (exam_variant_id, question_number, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, topic)
SELECT v.id, q.qn, q.qt, q.a, q.b, q.c, q.d, q.ans, q.exp, q.topic
FROM exam_variants v
JOIN (VALUES
  (1::int, 'If I had known about the meeting, I ___ attended.'::text, 'would have'::text, 'will have'::text, 'had'::text, 'would'::text, 'A'::text, 'Third Conditional: If + Past Perfect, would have + Past Participle.'::text, 'Conditionals'::text),
  (2, 'She asked me if I ___ ever been to Paris.', 'had', 'have', 'has', 'did', 'A', 'Reported speech: present perfect becomes past perfect.', 'Reported Speech'),
  (3, 'The book ___ I bought yesterday is excellent.', 'that', 'what', 'who', 'whose', 'A', 'That/which for things in relative clauses: the book that I bought.', 'Relative Clauses'),
  (4, 'I need to ___ smoking for my health.', 'give up', 'give in', 'give out', 'give away', 'A', 'Give up = quit a habit. Give in = surrender. Give out = distribute. Give away = donate.', 'Phrasal Verbs'),
  (5, 'By next year, she ___ here for a decade.', 'will have lived', 'will live', 'has lived', 'lives', 'A', 'Future Perfect: by + future time, use will have + past participle.', 'Future Perfect'),
  (6, 'The teacher made us ___ the essay again.', 'write', 'to write', 'writing', 'wrote', 'A', 'Make + object + bare infinitive (without to): made us write.', 'Causative Verbs'),
  (7, 'Despite ___ ill, he went to work.', 'being', 'be', 'is', 'to be', 'A', 'Despite + gerund: Despite being ill.', 'Gerund'),
  (8, 'I wish my brother ___ so much noise.', 'didn''t make', 'doesn''t make', 'won''t make', 'wouldn''t make', 'A', 'Wish + past simple for present annoyance: I wish he didn''t make.', 'Wish'),
  (9, 'The report must ___ by Friday at the latest.', 'be completed', 'complete', 'completing', 'to complete', 'A', 'Passive infinitive: must + be + past participle = must be completed.', 'Passive Voice'),
  (10, 'He hasn''t decided ___ to go to the party yet.', 'whether', 'if he', 'that he', 'what', 'A', 'Whether is used for choices: whether to go.', 'Grammar'),
  (11, 'Choose the correct sentence:', 'Neither of the answers is correct.', 'Neither of the answers are correct.', 'Neither of the answer is correct.', 'Neither answers is correct.', 'A', 'Neither of + plural noun takes singular verb: Neither of the answers is.', 'Subject-Verb Agreement'),
  (12, 'Reading: "Despite the rain, the festival went ahead as planned." What happened?', 'The festival took place despite bad weather.', 'The festival was cancelled because of rain.', 'The festival was postponed.', 'It did not rain at the festival.', 'A', 'Despite the rain = even though it rained. "went ahead" = took place.', 'Reading Comprehension'),
  (13, 'It''s high time you ___ looking for a job.', 'started', 'start', 'will start', 'starting', 'A', 'It''s high time + past simple (subjunctive): It''s high time you started.', 'Subjunctive'),
  (14, 'The manager insisted that everyone ___ on time.', 'be', 'is', 'was', 'will be', 'A', 'Subjunctive after insist: insisted that everyone be (bare infinitive).', 'Subjunctive'),
  (15, 'I''d rather you ___ smoke in here.', 'didn''t', 'don''t', 'won''t', 'not', 'A', 'Would rather + subject + past simple: I''d rather you didn''t smoke.', 'Preference')
) AS q(qn, qt, a, b, c, d, ans, exp, topic)
ON v.title = 'Тренувальний варіант НМТ №4 (B1-B2)';

-- ============================================================
-- New Achievements
-- ============================================================

INSERT INTO achievements (code, title_uk, title_en, description_uk, description_en, icon, xp_reward, threshold, metric)
VALUES
  ('first_trainer', 'Перший тренажер', 'First Trainer', 'Завершити першу вправу в тренажері', 'Complete your first trainer exercise', 'play-circle', 50, 1, 'trainers_done'),
  ('lessons_5', 'П''ятірка уроків', 'Five Lessons', 'Завершити 5 уроків', 'Complete 5 lessons', 'book-open', 150, 5, 'lessons_completed'),
  ('exams_3', 'Досвідчений тестувальник', 'Experienced Tester', 'Пройти 3 пробні тести НМТ', 'Complete 3 NMT practice tests', 'clipboard-check', 300, 3, 'exams_completed'),
  ('streak_30', 'Місяць наполегливості', 'Month of Persistence', '30 днів поспіль навчання', '30 days of consecutive study', 'flame', 500, 30, 'streak_days'),
  ('words_100', 'Словничок', 'Word Collector', 'Вивчити 100 слів', 'Learn 100 words', 'book-open', 200, 100, 'words_learned'),
  ('first_review', 'Перше повторення', 'First Review', 'Виконати перше повторення слів', 'Complete your first vocabulary review', 'repeat', 50, 1, 'reviews_done')
ON CONFLICT (code) DO NOTHING;
