/*
# Add more NMT exam variants and questions

1. New Data
- 2 new exam variants: "Тренувальний варіант НМТ №2" and "Тренувальний варіант НМТ №3"
- 30 new exam questions (15 per variant) covering grammar, vocabulary, reading comprehension
- Each question has 4 options (A-D), correct answer, explanation, and topic tag
2. Security
- No new tables, only INSERT data into existing exam_variants and exam_questions tables
- RLS already configured: exam_variants and exam_questions are readable by anon+authenticated
*/

INSERT INTO exam_variants (title, description, duration_minutes, is_published)
VALUES
  ('Тренувальний варіант НМТ №2', 'Граматика та лексика: часи дієслів, модальні дієслова, прийменники.', 60, true),
  ('Тренувальний варіант НМТ №3', 'Лексика та читання: синоніми, антоніми, розуміння тексту.', 60, true);

-- Questions for Variant 2
INSERT INTO exam_questions (exam_variant_id, question_number, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, topic)
SELECT v.id, q.qn, q.qt, q.a, q.b, q.c, q.d, q.ans, q.exp, q.topic
FROM exam_variants v
JOIN (VALUES
  (1::int, 'He said he ___ the movie before.'::text, 'seen'::text, 'had seen'::text, 'saw'::text, 'seeing'::text, 'B'::text, 'У непрямій мові для дії перед іншою минулою дією використовуємо Past Perfect: had seen.'::text, 'Reported Speech'::text),
  (2, 'You ___ smoke here. It is forbidden.', 'mustn''t', 'don''t have to', 'shouldn''t', 'needn''t', 'A', 'Mustn''t означає заборону: ви не повинні тут курити.', 'Modal Verbs'),
  (3, 'She is interested ___ learning Spanish.', 'in', 'on', 'at', 'to', 'A', 'Після interested використовуємо прийменник in: interested in.', 'Prepositions'),
  (4, 'The book ___ by millions of readers since 2010.', 'has been read', 'has read', 'read', 'is read', 'A', 'Present Perfect Passive: has been read (книга була прочитана).', 'Passive Voice'),
  (5, 'I wish I ___ more time to study.', 'had', 'have', 'will have', 'would have', 'A', 'Після wish для бажання про теперішнє використовуємо Past Simple: I wish I had.', 'Wish / Conditionals'),
  (6, 'If I ___ you, I would study harder.', 'were', 'am', 'will be', 'was', 'A', 'У другому типі умовних речень використовуємо were: If I were you.', 'Conditionals'),
  (7, 'She has been living here ___ 2015.', 'since', 'for', 'from', 'in', 'A', 'З конкретною датою використовуємо since: since 2015.', 'Prepositions of Time'),
  (8, 'The children ___ playing in the garden when it started to rain.', 'were', 'was', 'are', 'is', 'A', 'Past Continuous з they/children: were playing.', 'Past Continuous'),
  (9, 'This problem ___ at the meeting tomorrow.', 'will be discussed', 'will discuss', 'is discussed', 'discusses', 'A', 'Future Simple Passive: will be discussed.', 'Passive Voice'),
  (10, 'He asked me where ___ .', 'I lived', 'do I live', 'did I live', 'I live', 'A', 'У непрямому питанні порядок слів прямий: He asked me where I lived.', 'Reported Speech'),
  (11, 'I''m looking forward ___ from you.', 'to hearing', 'to hear', 'hearing', 'hear', 'A', 'Look forward to + gerund: looking forward to hearing.', 'Gerund / Infinitive'),
  (12, 'The test was ___ difficult than I expected.', 'less', 'least', 'fewer', 'little', 'A', 'Менш складний — less difficult.', 'Comparatives'),
  (13, 'She ___ have left already; her car is still here.', 'can''t', 'must', 'should', 'will', 'A', 'Can''t have — логічний висновок про неможливість.', 'Modal Verbs of Deduction'),
  (14, 'By the time we arrived, the concert ___ .', 'had started', 'started', 'has started', 'starts', 'A', 'Past Perfect для дії, що відбулася до іншої минулої дії.', 'Past Perfect'),
  (15, 'I don''t mind ___ late if necessary.', 'working', 'to work', 'work', 'worked', 'A', 'Don''t mind + gerund: don''t mind working.', 'Gerund / Infinitive')
) AS q(qn, qt, a, b, c, d, ans, exp, topic)
ON v.title = 'Тренувальний варіант НМТ №2';

-- Questions for Variant 3
INSERT INTO exam_questions (exam_variant_id, question_number, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, topic)
SELECT v.id, q.qn, q.qt, q.a, q.b, q.c, q.d, q.ans, q.exp, q.topic
FROM exam_variants v
JOIN (VALUES
  (1::int, 'Choose the synonym of "happy":'::text, 'joyful'::text, 'sad'::text, 'angry'::text, 'tired'::text, 'A'::text, 'Joyful — синонім happy (радісний).'::text, 'Synonyms'::text),
  (2, 'Choose the antonym of "expensive":', 'cheap', 'costly', 'pricey', 'valuable', 'A', 'Cheap — антонім expensive (дешевий vs дорогий).', 'Antonyms'),
  (3, 'The word "enormous" means:', 'very large', 'very small', 'very fast', 'very slow', 'A', 'Enormous = дуже великий.', 'Vocabulary'),
  (4, 'Choose the correct word: She gave me a ___ smile.', 'bright', 'brightly', 'brightness', 'brighten', 'A', 'Перед іменником використовуємо прикметник: bright smile.', 'Word Forms'),
  (5, 'What does "to give up" mean?', 'to quit', 'to continue', 'to start', 'to delay', 'A', 'Give up = здаватися, кидати щось робити.', 'Phrasal Verbs'),
  (6, 'Choose the synonym of "difficult":', 'hard', 'easy', 'simple', 'light', 'A', 'Hard — синонім difficult.', 'Synonyms'),
  (7, 'Choose the antonym of "accept":', 'refuse', 'agree', 'allow', 'receive', 'A', 'Refuse — антонім accept (відмовляти vs приймати).', 'Antonyms'),
  (8, 'Complete: He is very ___, he never shares his toys.', 'selfish', 'generous', 'kind', 'friendly', 'A', 'Selfish = егоїстичний, такий що не ділиться.', 'Vocabulary in Context'),
  (9, 'The word "ancient" refers to something:', 'very old', 'very new', 'very big', 'very small', 'A', 'Ancient = стародавній, дуже старий.', 'Vocabulary'),
  (10, 'Choose the correct meaning of "to look forward to":', 'to anticipate with pleasure', 'to look behind', 'to look up', 'to look down', 'A', 'Look forward to = чекати з нетерпінням.', 'Phrasal Verbs'),
  (11, 'Choose the synonym of "begin":', 'start', 'end', 'stop', 'finish', 'A', 'Start — синонім begin.', 'Synonyms'),
  (12, 'Choose the antonym of "arrive":', 'depart', 'come', 'reach', 'enter', 'A', 'Depart — антонім arrive (відправлятися vs прибувати).', 'Antonyms'),
  (13, 'Complete: The weather was ___ cold that we stayed home.', 'so', 'such', 'very', 'too', 'A', 'So + прикметник: so cold that...', 'Grammar in Context'),
  (14, 'What does "reliable" mean?', 'trustworthy and dependable', 'untrustworthy', 'careless', 'lazy', 'A', 'Reliable = надійний, такий на якого можна покластися.', 'Vocabulary'),
  (15, 'Choose the correct word: She speaks English ___ .', 'fluently', 'fluent', 'fluency', 'fluid', 'A', 'Після дієслова speak використовуємо прислівник: fluently.', 'Word Forms')
) AS q(qn, qt, a, b, c, d, ans, exp, topic)
ON v.title = 'Тренувальний варіант НМТ №3';
