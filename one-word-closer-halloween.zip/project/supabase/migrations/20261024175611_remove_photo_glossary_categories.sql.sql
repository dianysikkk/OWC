/*
# Remove the dedicated photo glossary dictionaries

1. Modified data
- Removes only the seven categories created for the supplied photo pages.
- Vocabulary words, translations, examples, learning progress, favorites,
  reviews, and user-created decks are preserved.
- Because vocabulary.category_id uses ON DELETE SET NULL, the affected words
  remain in the main dictionary without these extra category labels.

2. Security
- No tables, permissions, or row-level security policies are changed.

3. Important notes
- The regular built-in vocabulary categories remain available.
- This operation is limited to categories whose English names begin with
  "Photo glossary —".
*/

DELETE FROM vocabulary_categories
WHERE name_en LIKE 'Photo glossary — %';
