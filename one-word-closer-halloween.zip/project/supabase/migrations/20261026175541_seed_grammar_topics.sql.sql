/*
# Seed grammar topics, examples, and exercises

1. New data
- 10 grammar topics covering A1-B2 levels: Present Simple, Present Continuous,
  Past Simple, Present Perfect, Future forms, Articles, Comparatives/Superlatives,
  Conditionals, Passive Voice, Modal verbs.
- Each topic has 3-4 example sentences and 3-4 practice exercises.

2. Security
- No security changes. All tables were already set up with public read policies.

3. Important notes
- Uses ON CONFLICT DO NOTHING to be idempotent.
- Content is in Ukrainian/English bilingual format.
*/

DO $$
DECLARE
  t_present_simple uuid;
  t_present_cont uuid;
  t_past_simple uuid;
  t_present_perfect uuid;
  t_future uuid;
  t_articles uuid;
  t_comparatives uuid;
  t_conditionals uuid;
  t_passive uuid;
  t_modals uuid;
BEGIN
  -- Present Simple
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Present Simple', 'Present Simple', 'A1', 'Часи дієслова',
    'Теперішній простий час для регулярних дій та фактів',
    'Present Simple використовується для опису регулярних, повторюваних дій, загальних фактів, звичок та постійних станів.',
    '1. I/You/We/They + дієслово (без закінчення)\n2. He/She/It + дієслово + -s/-es\n3. Заперечення: do/does not + дієслово\n4. Питання: Do/Does + підмет + дієслово?\n5. Частотні прислівники: always, usually, often, sometimes, never (перед дієсловом)',
    1)
  RETURNING id INTO t_present_simple;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_present_simple, 'She works at a hospital.', 'Вона працює в лікарні.', 'he/she/it + -s', 1),
  (t_present_simple, 'I do not drink coffee in the evening.', 'Я не п''ю каву ввечері.', 'заперечення з do not', 2),
  (t_present_simple, 'Does he play football?', 'Він грає у футбол?', 'питання з Does', 3),
  (t_present_simple, 'The sun rises in the east.', 'Сонце сходить на сході.', 'загальний факт', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_present_simple, 'My sister ___ to school by bus.', 'go', 'goes', 'going', 'gone', 'B', 'he/she/it додає -es: she goes.', 1),
  (t_present_simple, 'We ___ not live in this city.', 'does', 'do', 'is', 'are', 'B', 'Для we використовуємо do not.', 2),
  (t_present_simple, '___ they speak English?', 'Do', 'Does', 'Is', 'Are', 'A', 'Для they — Do + підмет + дієслово.', 3),
  (t_present_simple, 'He usually ___ breakfast at 7 AM.', 'have', 'has', 'having', 'had', 'B', 'he/she/it + has (3 особа однини).', 4);

  -- Present Continuous
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Present Continuous', 'Present Continuous', 'A1', 'Часи дієслова',
    'Теперішній тривалий час для дій, що відбуваються зараз',
    'Present Continuous описує дії, які відбуваються в момент мовлення або навколо нього, а також тимчасові ситуації.',
    '1. Підмет + am/is/are + дієслово + -ing\n2. Заперечення: am/is/are + not + V-ing\n3. Питання: Am/Is/Are + підмет + V-ing?\n4. Маркери: now, right now, at the moment, currently, currently\n5. Дієслова стану (stative verbs) не вживаються у Continuous: know, like, want, understand',
    2)
  RETURNING id INTO t_present_cont;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_present_cont, 'I am reading a book right now.', 'Я зараз читаю книгу.', 'дія в момент мовлення', 1),
  (t_present_cont, 'They are not watching TV.', 'Вони не дивляться телевізор.', 'заперечення', 2),
  (t_present_cont, 'Is she cooking dinner?', 'Вона готує вечерю?', 'питання', 3),
  (t_present_cont, 'We are studying English this semester.', 'Ми вивчаємо англійську цього семестру.', 'тимчасова ситуація', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_present_cont, 'Look! The children ___ in the park.', 'play', 'are playing', 'plays', 'played', 'B', 'Дія відбувається зараз: are playing.', 1),
  (t_present_cont, 'I ___ to music at the moment.', 'listen', 'listens', 'am listening', 'listening', 'C', 'I + am + V-ing.', 2),
  (t_present_cont, '___ she wearing a blue dress?', 'Do', 'Is', 'Are', 'Am', 'B', 'she → Is + V-ing?', 3),
  (t_present_cont, 'He ___ not sleeping now.', 'do', 'is', 'does', 'are', 'B', 'he → is not + V-ing.', 4);

  -- Past Simple
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Past Simple', 'Past Simple', 'A2', 'Часи дієслова',
    'Минулий простий час для завершених дій у минулому',
    'Past Simple використовується для дій, які завершилися у певний момент у минулому. Правильні дієслова додають -ed, неправильні мають спеціальні форми.',
    '1. Правильні: дієслово + -ed (worked, played)\n2. Неправильні: 2-я форма (went, saw, took)\n3. Заперечення: did not (didn''t) + дієслово\n4. Питання: Did + підмет + дієслово?\n5. Маркери: yesterday, last week, in 2020, ago, when I was young',
    3)
  RETURNING id INTO t_past_simple;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_past_simple, 'She visited her grandparents last weekend.', 'Вона відвідала дідуся з бабусею минулих вихідних.', 'правильне дієслово + -ed', 1),
  (t_past_simple, 'They went to the cinema yesterday.', 'Вони ходили в кіно вчора.', 'неправильне: go → went', 2),
  (t_past_simple, 'I did not see him at the party.', 'Я не бачив його на вечірці.', 'заперечення з did not', 3),
  (t_past_simple, 'Did you finish your homework?', 'Ти завершив домашнє завдання?', 'питання з Did', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_past_simple, 'We ___ to London last summer.', 'go', 'went', 'gone', 'going', 'B', 'go → went (неправильне дієслово).', 1),
  (t_past_simple, 'She ___ not come to the meeting.', 'did', 'was', 'does', 'is', 'A', 'did not + дієслово (без закінчення).', 2),
  (t_past_simple, '___ they buy a new car?', 'Do', 'Did', 'Was', 'Are', 'B', 'Did + підмет + дієслово?', 3),
  (t_past_simple, 'He ___ his keys at home.', 'forget', 'forgot', 'forgotten', 'forgetting', 'B', 'forget → forgot (неправильне).', 4);

  -- Present Perfect
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Present Perfect', 'Present Perfect', 'A2', 'Часи дієслова',
    'Теперішній доконаний час — зв''язок минулого з теперішнім',
    'Present Perfect описує дії, що відбулися у минулому, але мають результат або зв''язок із теперішнім. Не вказує конкретний час у минулому.',
    '1. have/has + Past Participle (3-я форма)\n2. Заперечення: have/has not + V3\n3. Питання: Have/Has + підмет + V3?\n4. Маркери: ever, never, already, just, yet, since, for\n5. Не вживається з конкретним часом у минулому (yesterday → Past Simple)',
    4)
  RETURNING id INTO t_present_perfect;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_present_perfect, 'I have already finished my work.', 'Я вже завершив свою роботу.', 'already — вже', 1),
  (t_present_perfect, 'She has never been to Paris.', 'Вона ніколи не була в Парижі.', 'never — ніколи', 2),
  (t_present_perfect, 'Have you ever eaten sushi?', 'Ти коли-небудь їв суші?', 'ever — коли-небудь', 3),
  (t_present_perfect, 'They have lived here since 2015.', 'Вони живуть тут з 2015 року.', 'since — з певного моменту', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_present_perfect, 'I ___ my homework already.', 'did', 'have done', 'do', 'doing', 'B', 'have + V3 (do → done). already — маркер Present Perfect.', 1),
  (t_present_perfect, 'She ___ in Kyiv for five years.', 'lives', 'has lived', 'lived', 'is living', 'B', 'has + V3 + for (тривалість).', 2),
  (t_present_perfect, '___ you ever been to London?', 'Did', 'Have', 'Are', 'Do', 'B', 'Have + підмет + ever + V3?', 3),
  (t_present_perfect, 'We ___ not seen this film yet.', 'did', 'have', 'are', 'do', 'B', 'have not + V3. yet — маркер Present Perfect.', 4);

  -- Future forms
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Майбутні форми', 'Future Forms', 'A2', 'Часи дієслова',
    'Способи вираження майбутнього: will, going to, Present Continuous',
    'Майбутнє в англійській може виражатися кількома способами: will (раптові рішення, прогнози), going to (плани, наміри), Present Continuous (заплановані події).',
    '1. will + дієслово: рішення в момент мовлення, прогноз, обіцянка\n2. be going to + дієслово: плани та наміри, прогнози на основі доказів\n3. Present Continuous: заплановані зустрічі, домовленості\n4. will: I will help you. going to: I am going to study.\n5. Маркери: tomorrow, next week, in the future, soon',
    5)
  RETURNING id INTO t_future;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_future, 'I will help you with your homework.', 'Я допоможу тобі з домашнім завданням.', 'раптове рішення', 1),
  (t_future, 'They are going to travel to Italy next month.', 'Вони збираються подорожувати до Італії наступного місяця.', 'план, намір', 2),
  (t_future, 'We are meeting at 5 PM tomorrow.', 'Ми зустрічаємося о 5-й годині завтра.', 'домовленість, Present Continuous', 3),
  (t_future, 'It will probably rain tomorrow.', 'Завтра, ймовірно, буде дощ.', 'прогноз без доказів', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_future, 'Look at those clouds! It ___ rain.', 'will', 'is going to', 'rains', 'raining', 'B', 'Прогноз на основі доказів → is going to.', 1),
  (t_future, '"I forgot my keys." "I ___ you mine."', 'will give', 'am going to give', 'give', 'giving', 'A', 'Раптове рішення → will.', 2),
  (t_future, 'We ___ a party this Saturday. We invited everyone.', 'have', 'are having', 'will have', 'had', 'B', 'Домовленість → Present Continuous.', 3),
  (t_future, 'She ___ start university in September.', 'will', 'goes to', 'is going to', 'going', 'C', 'Намір/план → is going to.', 4);

  -- Articles
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Артиклі', 'Articles (a/an/the)', 'A1', 'Артиклі',
    'Неозначений (a/an) та визначений (the) артиклі',
    'Артиклі вказують на визначеність або невизначеність іменника. a/an — для чогось нового, невідомого; the — для конкретного, відомого.',
    '1. a + приголосний звук: a book, a university\n2. an + голосний звук: an apple, an hour\n3. the — конкретний, відомий з контексту\n4. Без артикля: множина загалом, незлічувані, назви, абстрактні\n5. the Earth, the Sun, the Moon — унікальні об''єкти',
    6)
  RETURNING id INTO t_articles;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_articles, 'I bought a book and an apple.', 'Я купив книгу та яблуко.', 'a + приголосний, an + голосний', 1),
  (t_articles, 'The book I bought is interesting.', 'Книга, яку я купив, цікава.', 'the — конкретна, відома', 2),
  (t_articles, 'She is an engineer.', 'Вона інженер.', 'професія → a/an', 3),
  (t_articles, 'I love music.', 'Я люблю музику.', 'незлічуване → без артикля', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_articles, 'I saw ___ elephant at the zoo.', 'a', 'an', 'the', '—', 'B', 'elephant починається з голосного → an.', 1),
  (t_articles, 'Can you pass me ___ salt, please?', 'a', 'an', 'the', '—', 'C', 'Конкретна сіль на столі → the.', 2),
  (t_articles, 'She is ___ honest person.', 'a', 'an', 'the', '—', 'B', 'honest починається з голосного звуку (h німий) → an.', 3),
  (t_articles, '___ sun rises in the east.', 'A', 'An', 'The', '—', 'C', 'Унікальний об''єкт → the Sun.', 4);

  -- Comparatives and Superlatives
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Ступені порівняння', 'Comparatives & Superlatives', 'A2', 'Прикметники',
    'Порівняльний та найвищий ступені прикметників',
    'Прикметники мають три ступені: звичайний, порівняльний (більший/менший) і найвищий (найбільший/найменший). Правила залежать від довжини слова.',
    '1. Короткі (1 склад): -er / the -est (tall → taller → tallest)\n2. Довгі (2+ склади): more / the most (beautiful → more beautiful → most beautiful)\n3. Good → better → best; bad → worse → worst\n4. than — для порівняння: taller than\n5. the — перед найвищим ступенем: the tallest',
    7)
  RETURNING id INTO t_comparatives;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_comparatives, 'My brother is taller than me.', 'Мій брат вищий за мене.', 'порівняння + than', 1),
  (t_comparatives, 'This is the most interesting book I''ve read.', 'Це найцікавіша книга, яку я читав.', 'найвищий ступінь + the', 2),
  (t_comparatives, 'She is better at math than her sister.', 'Вона краще знає математику за свою сестру.', 'good → better', 3),
  (t_comparatives, 'Today is the worst day of the week.', 'Сьогодні найгірший день тижня.', 'bad → worst', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_comparatives, 'This exercise is ___ than the previous one.', 'easy', 'easier', 'easiest', 'more easy', 'B', 'Коротке слово + -er + than.', 1),
  (t_comparatives, 'She is the ___ student in the class.', 'good', 'better', 'best', 'most good', 'C', 'good → best (найвищий).', 2),
  (t_comparatives, 'This film is ___ interesting than that one.', 'more', 'most', 'much', '—', 'A', 'Довге слово → more + прикметник + than.', 3),
  (t_comparatives, 'It was the ___ day of my life.', 'bad', 'worse', 'worst', 'most bad', 'C', 'bad → worst (найвищий).', 4);

  -- Conditionals
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Умовні речення', 'Conditionals (0, 1, 2)', 'B1', 'Умовні речення',
    'Типи умовних речень: нульовий, перший, другий',
    'Умовні речення описують залежність між умовою та результатом. Три основні типи: Zero (завжди правда), First (реальне майбутнє), Second (гіпотетичне).',
    '1. Zero: If + Present Simple, Present Simple (загальні факти)\n2. First: If + Present Simple, will + дієслово (реальне майбутнє)\n3. Second: If + Past Simple, would + дієслово (гіпотетичне)\n4. was/were → were у Second Conditional (If I were you)\n5. Можна міняти місцями частини; без коми, якщо if не на початку',
    8)
  RETURNING id INTO t_conditionals;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_conditionals, 'If you heat ice, it melts.', 'Якщо нагріти лід, він тане.', 'Zero Conditional — факт', 1),
  (t_conditionals, 'If it rains tomorrow, we will stay home.', 'Якщо завтра буде дощ, ми залишимося вдома.', 'First Conditional — реальне', 2),
  (t_conditionals, 'If I had more time, I would learn Spanish.', 'Якби я мав більше часу, я вивчив би іспанську.', 'Second Conditional — гіпотетичне', 3),
  (t_conditionals, 'If I were you, I would accept the offer.', 'На твоєму місці я б прийняв пропозицію.', 'were замість was', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_conditionals, 'If I ___ rich, I would travel the world.', 'am', 'were', 'will be', 'had been', 'B', 'Second Conditional → Past Simple (were для всіх осіб).', 1),
  (t_conditionals, 'If it ___ tomorrow, we will cancel the picnic.', 'rain', 'rains', 'will rain', 'rained', 'B', 'First Conditional → Present Simple після if.', 2),
  (t_conditionals, 'Water ___ at 100 degrees Celsius.', 'boil', 'boils', 'is boiling', 'will boil', 'B', 'Zero Conditional — загальний факт, Present Simple.', 3),
  (t_conditionals, 'If she ___ harder, she would pass the exam.', 'studies', 'studied', 'will study', 'study', 'B', 'Second Conditional → Past Simple після if.', 4);

  -- Passive Voice
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Пасивний стан', 'Passive Voice', 'B1', 'Стан дієслова',
    'Пасивний стан: фокус на дії, а не на виконавці',
    'Passive Voice використовується, коли важлива сама дія, а не хто її виконує. Форма: be + Past Participle (V3).',
    '1. Present Simple Passive: am/is/are + V3\n2. Past Simple Passive: was/were + V3\n3. Present Perfect Passive: has/have been + V3\n4. Future Passive: will be + V3\n5. by + виконавець (необов''язково): The book was written by him.',
    9)
  RETURNING id INTO t_passive;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_passive, 'The letter is sent every Monday.', 'Лист надсилається кожного понеділка.', 'Present Simple Passive', 1),
  (t_passive, 'The house was built in 1990.', 'Будинок був збудований у 1990 році.', 'Past Simple Passive', 2),
  (t_passive, 'The project has been completed.', 'Проєкт був завершений.', 'Present Perfect Passive', 3),
  (t_passive, 'The report will be sent tomorrow.', 'Звіт буде надіслано завтра.', 'Future Passive', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_passive, 'The book ___ by millions of people.', 'reads', 'is read', 'is reading', 'read', 'B', 'Present Simple Passive: is + V3.', 1),
  (t_passive, 'The bridge ___ in 1985.', 'built', 'was built', 'is built', 'builds', 'B', 'Past Simple Passive: was + V3.', 2),
  (t_passive, 'The work ___ by tomorrow.', 'will complete', 'will be completed', 'is completed', 'completes', 'B', 'Future Passive: will be + V3.', 3),
  (t_passive, 'This song ___ by everyone.', 'knows', 'is known', 'is knowing', 'knew', 'B', 'Present Simple Passive: is + V3.', 4);

  -- Modal verbs
  INSERT INTO grammar_topics (title_uk, title_en, cefr_level, category, summary, explanation, rules, sort_order)
  VALUES ('Модальні дієслова', 'Modal Verbs', 'B1', 'Модальні дієслова',
    'can, must, should, may, might — для можливості, обов''язку, дозволу',
    'Модальні дієслова виражають можливість, необхідність, дозвіл, пораду чи ймовірність. Вони не змінюються за особами та не вимагають допоміжних дієслів.',
    '1. can/could — здатність, можливість, прохання\n2. must — необхідність, заборона (must not)\n3. should/ought to — порада, рекомендація\n4. may/might — дозвіл, ймовірність\n5. Модальне + дієслово без to (крім ought to)\n6. have to — зовнішня необхідність; must — внутрішня',
    10)
  RETURNING id INTO t_modals;

  INSERT INTO grammar_examples (topic_id, sentence_en, sentence_uk, note, sort_order) VALUES
  (t_modals, 'She can speak three languages.', 'Вона вміє говорити трьома мовами.', 'can — здатність', 1),
  (t_modals, 'You must wear a helmet on a motorcycle.', 'Ти повинен носити шолом на мотоциклі.', 'must — обов''язок', 2),
  (t_modals, 'You should see a doctor.', 'Тобі слід звернутися до лікаря.', 'should — порада', 3),
  (t_modals, 'It might rain later.', 'Пізніше може піти дощ.', 'might — ймовірність', 4);

  INSERT INTO grammar_exercises (topic_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t_modals, 'You ___ smoke here. It''s forbidden.', 'must not', 'should not', 'can not', 'might not', 'A', 'must not — заборона.', 1),
  (t_modals, 'She ___ play the piano very well.', 'can', 'must', 'should', 'may', 'A', 'can — здатність.', 2),
  (t_modals, 'You ___ rest more. You look tired.', 'can', 'must', 'should', 'may', 'C', 'should — порада.', 3),
  (t_modals, 'I''m not sure, but he ___ be at home now.', 'must', 'might', 'should', 'can', 'B', 'might — невпевнена ймовірність.', 4);
END $$;