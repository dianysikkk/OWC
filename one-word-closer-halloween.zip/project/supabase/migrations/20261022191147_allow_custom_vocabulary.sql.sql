/*
# Allow users to add custom vocabulary words

1. Schema changes
- Adds `created_by` column (uuid, nullable) to vocabulary table to track user-added words
2. Security
- Adds INSERT policy on vocabulary for authenticated users (can only insert rows where created_by = auth.uid())
- Existing SELECT policy (read_vocabulary, visible to all) remains unchanged
- Grants INSERT on vocabulary to authenticated
*/

ALTER TABLE vocabulary ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL;

GRANT INSERT ON vocabulary TO authenticated;

DROP POLICY IF EXISTS "insert_own_vocabulary" ON vocabulary;
CREATE POLICY "insert_own_vocabulary" ON vocabulary FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = created_by);
