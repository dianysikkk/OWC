/*
# Organize the photographed glossary into dedicated dictionaries

Adds seven public categories matching the supplied photo sections and moves only
photo-listed words into those categories. Existing word data, translations,
examples, learning progress, and access rules are preserved. The operation is
idempotent and skips no data outside the listed photo vocabulary.
*/

INSERT INTO vocabulary_categories (name_uk, name_en, icon, sort_order)
SELECT v.name_uk, v.name_en, v.icon, v.sort_order
FROM (VALUES
  ('Персональні дані з фото', 'Photo glossary — Personal details', 'user', 101),
  ('Зовнішність з фото', 'Photo glossary — Appearance', 'sparkles', 102),
  ('Одяг з фото', 'Photo glossary — Clothes', 'shirt', 103),
  ('Матеріали та візерунки з фото', 'Photo glossary — Materials and patterns', 'layers', 104),
  ('Риси характеру з фото', 'Photo glossary — Character traits', 'heart', 105),
  ('Почуття та ставлення з фото', 'Photo glossary — Feelings and attitude', 'smile', 106),
  ('Ідіоми з фото', 'Photo glossary — Idioms', 'message-circle', 107)
) AS v(name_uk, name_en, icon, sort_order)
WHERE NOT EXISTS (SELECT 1 FROM vocabulary_categories c WHERE c.name_en = v.name_en);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Personal details' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['citizenship','citizen','address','age','date of birth','newborn baby','infant','toddler','adolescent','teenager','adult','middle-aged','elderly','in his twenties','in her thirties','first name','gender','surname','male','female','marital status','single','married','separated','divorced','widowed','nationality','next of kin','nickname','permanent address','temporary address','place of residence','pseudonym','spouse','country of residence','ethnic origin','occupation','distinguishing features','birthmark']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Appearance' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['beautiful','pretty','good-looking','attractive','ordinary-looking','unattractive','chubby','plump','overweight','obese','fat','skinny','thin','slim','slender','well-built','muscular','athletic','broad-shouldered','lanky','stocky','average height','medium height','how much does he weigh','what does she look like','younger than she looks','older than he looks','fair complexion','dark complexion','pale complexion','tanned','good looks','handsome','beard','moustache','clean-shaven','freckles','dimples','forehead','high forehead','cheeks','high cheekbones','chin','double chin','eyebrows','brown eyes','blue eyes','green eyes','hazel eyes','bright eyes','piercing blue eyes','round face','oval face','long face','thin face','pimples','spots','acne','scar','wrinkles','piercing','tattoo','big nose','small nose','long nose','snub nose','pointed nose','broad smile','tight-lipped smile','blond','blonde','dark-haired','fair hair','red-haired','grey hair','dyed','short-haired','short hair','long hair','straight-haired','straight hair','curly','wavy','spiky hair','cropped hair','shoulder-length','medium-length hair','fringe','ponytail','centre parting','centre-parting','side parting','side-parting','bald','wig','tie your hair up','wear your hair loose','wear your hair up','hair extensions','brush','fine hair','thick hair','straighten','go for darker colours','paint your nails','put on weight','lose weight','take up a hobby']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Clothes' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['anorak','braces','blouse','boots','bra','collar','coat','contact lenses','casual','dress','fashionable','trendy','fleece','flip-flops','gloves','hat','hooded sweatshirt','jacket','jeans','jumper','old-fashioned','overcoat','pyjamas','sandals','shirt','shoes','shorts','skirt','smart','socks','suit','sweatshirt','swimming trunks','swimsuit','tie','bow tie','tights','tracksuit','trainers','underwear','wellingtons','V-neck','belt','button','cap','earrings','glasses','handbag','jewellery','necklace','ring','scarf','shoelaces','slippers','zip-up','put on','take off','dress up','try on','wear out','appropriate','baggy','designer','second-hand','hand-made','faded','formal','knitted','sleeveless','ripped','tight-fitting','loose-fitting']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Materials and patterns' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['cotton','denim','fur','lace','leather','linen','nylon','rubber','silk','wool','woollen','checked','dotted','floral','plain','spotted','striped','tartan']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Character traits' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['dishonest','immature','impatient','impolite','inactive','insincere','irresponsible','unpredictable','unreliable','absent-minded','adventurous','aggressive','ambitious','driven','boring','dull','bossy','brave','calm','relaxed','caring','charitable','cheerful','childish','clever','committed','compassionate','confident','consistent','coward','creative','determined','easy-going','easygoing','fearless','flexible','forgetful','generous','hard-working','have a sense of humour','helpful','hot-tempered','humble','indecisive','independent','intelligent','inventive','irritable','jealous','kind','lazy','mean','messy','miserable','moody','moral','narrow-minded','open-minded','outgoing','perfectionist','proud','punctual','reasonable','rebellious','reserved','rude','self-confident','selfish','sensitive','serious','shy','sociable','spoilt','sporty','strict','stubborn','talented','talkative','trustworthy','understanding','modest','odd','sympathetic','weird']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Feelings and attitude' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['approving','disapproving','admire','adore','angry','furious','annoyed','anxious','appalled','be a fan of','be fond of','be into','be keen on','be ashamed of','be attracted to','be hopeless at','be in a good mood','be in a bad mood','be in the mood for','bored','cannot stand','confused','delighted','depressed','devastated','disappointed','embarrassed','excited','exhausted','fall in love','fancy','fed up with','frightened','scared','frustrated','get on well with','grateful','hate','indifferent','irritated','lonely','long for','look up to','lose your temper','moved','nervous','overwhelmed','passionate','pleased','relaxed','respect','shocked','surprised','amazed','sympathy','take an interest in','take pride in','thrilled','worried']) x);

UPDATE vocabulary v SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Photo glossary — Idioms' LIMIT 1)
WHERE lower(v.word) IN (SELECT lower(x) FROM unnest(ARRAY['be on top of the world','be out of sorts','drive someone up the wall','feel blue','give someone a hard time','have mixed feelings','jumping for joy','find common ground','have the time of your life','pick up the courage','cannot believe your ears','strike up a conversation','be part of someone''s nature']) x);
