/*
# Seed reading texts and comprehension questions

1. New data
- 6 reading texts across A1-B2 levels: a daily routine, a travel story, an environmental article,
  a biography, a technology article, and a short story excerpt.
- Each text has 3-4 multiple-choice comprehension questions with explanations.

2. Security
- No security changes.

3. Important notes
- Idempotent via DO block with local variables.
*/

DO $$
DECLARE
  t1 uuid; t2 uuid; t3 uuid; t4 uuid; t5 uuid; t6 uuid;
BEGIN
  -- Text 1: A1 - Daily routine
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('My Daily Routine', 'A1', 'Щоденне життя',
    'A short text about a typical day of a student.',
    'My name is Anna and I am a student. Every day I wake up at 7 o''clock in the morning. First, I brush my teeth and wash my face. Then I have breakfast — usually cereal with milk and a cup of tea.\n\nI go to school by bus. My classes start at 8:30 and finish at 2:30. My favourite subject is English because I love learning new words. After school, I have lunch and do my homework.\n\nIn the evening, I sometimes meet my friends at the park. We play games and talk. I have dinner at 7 PM with my family. Before bed, I read a book or watch a short video. I go to sleep at 10 PM.',
    'Adapted', 5, 1)
  RETURNING id INTO t1;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t1, 'What time does Anna wake up?', '6:00', '7:00', '8:00', '7:30', 'B', 'У тексті: "I wake up at 7 o''clock in the morning."', 1),
  (t1, 'How does Anna go to school?', 'By car', 'On foot', 'By bus', 'By bike', 'C', 'У тексті: "I go to school by bus."', 2),
  (t1, 'What is Anna''s favourite subject?', 'Math', 'English', 'History', 'Art', 'B', 'У тексті: "My favourite subject is English."', 3),
  (t1, 'What does Anna do before bed?', 'Plays games', 'Calls her friend', 'Reads a book or watches a video', 'Does homework', 'C', 'У тексті: "Before bed, I read a book or watch a short video."', 4);

  -- Text 2: A2 - Travel story
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('A Trip to the Mountains', 'A2', 'Подорожі',
    'A story about a family''s weekend trip to the mountains.',
    'Last weekend, my family and I went to the Carpathian Mountains. We left home early on Saturday morning. The drive took about four hours, but the scenery was beautiful.\n\nWe stayed in a small wooden cabin near a river. On Saturday afternoon, we went hiking. My father and I climbed to the top of a hill. The view was amazing — we could see the whole valley below us. My mother stayed at the cabin and cooked dinner.\n\nOn Sunday, we visited a local market. I bought a handmade wool scarf as a souvenir. We also tried traditional Ukrainian food — borscht and varenyky. It was delicious! We drove back home on Sunday evening, tired but happy.',
    'Adapted', 8, 2)
  RETURNING id INTO t2;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t2, 'When did the family leave for the mountains?', 'Friday evening', 'Saturday morning', 'Sunday morning', 'Saturday afternoon', 'B', 'У тексті: "We left home early on Saturday morning."', 1),
  (t2, 'How long was the drive?', 'Two hours', 'Three hours', 'Four hours', 'Five hours', 'C', 'У тексті: "The drive took about four hours."', 2),
  (t2, 'What did the narrator buy at the market?', 'A hat', 'A wool scarf', 'A pair of boots', 'A bag', 'B', 'У тексті: "I bought a handmade wool scarf as a souvenir."', 3),
  (t2, 'What traditional food did they try?', 'Pizza and pasta', 'Sushi', 'Borscht and varenyky', 'Burgers', 'C', 'У тексті: "We also tried traditional Ukrainian food — borscht and varenyky."', 4);

  -- Text 3: B1 - Environment
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('Why We Must Protect Our Oceans', 'B1', 'Довкілля',
    'An article about the threats facing our oceans and what we can do.',
    'Oceans cover more than 70% of our planet''s surface. They produce over half of the world''s oxygen and absorb about 30% of carbon dioxide emissions. Despite their importance, oceans face serious threats from human activity.\n\nOne of the biggest problems is plastic pollution. Every year, about 8 million tonnes of plastic enter the ocean. This plastic does not decompose quickly. Instead, it breaks into tiny pieces called microplastics, which are eaten by fish and other marine animals. Scientists have found plastic in the stomachs of whales, turtles, and even in the fish we eat.\n\nAnother major threat is overfishing. Many fish populations are declining rapidly because we catch them faster than they can reproduce. Some species, like bluefin tuna, are now endangered.\n\nWhat can we do? First, we can reduce our use of single-use plastics — bags, bottles, and straws. Second, we can choose sustainable seafood. Third, we can support organizations that protect marine life. Even small actions, when done by millions of people, can make a real difference.',
    'Adapted from educational sources', 10, 3)
  RETURNING id INTO t3;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t3, 'How much of the planet''s surface do oceans cover?', '50%', '60%', '70%', '80%', 'C', 'У тексті: "Oceans cover more than 70% of our planet''s surface."', 1),
  (t3, 'How much plastic enters the ocean each year?', '1 million tonnes', '3 million tonnes', '8 million tonnes', '15 million tonnes', 'C', 'У тексті: "about 8 million tonnes of plastic enter the ocean."', 2),
  (t3, 'What are microplastics?', 'Large plastic bottles', 'Tiny pieces of plastic', 'A type of fish food', 'Ocean currents', 'B', 'У тексті: "it breaks into tiny pieces called microplastics."', 3),
  (t3, 'Which species is mentioned as endangered?', 'Salmon', 'Shark', 'Bluefin tuna', 'Cod', 'C', 'У тексті: "some species, like bluefin tuna, are now endangered."', 4);

  -- Text 4: B1 - Biography
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('Stephen Hawking: A Brilliant Mind', 'B1', 'Біографії',
    'The life story of one of the most famous physicists of our time.',
    'Stephen Hawking was born on January 8, 1942, in Oxford, England. He showed an early interest in science and mathematics. At the age of 17, he entered Oxford University to study physics. After graduating, he moved to Cambridge to pursue a PhD in cosmology.\n\nAt the age of 21, Hawking was diagnosed with ALS, a disease that gradually destroys nerve cells. Doctors told him he had only two years to live. Despite this devastating news, Hawking continued his research. He married Jane Wilde in 1965 and they had three children together.\n\nAs the disease progressed, Hawking lost the ability to walk, use his hands, and eventually speak. He used a wheelchair and a speech-generating device controlled by his cheek muscles. But his mind remained sharp.\n\nHawking made groundbreaking contributions to our understanding of black holes. He showed that black holes emit radiation, now known as "Hawking radiation." His 1988 book, "A Brief History of Time," sold over 25 million copies and made him a household name.\n\nHawking died on March 14, 2018, at the age of 76 — far surpassing the two years doctors had predicted. His life is a testament to the power of the human spirit and the pursuit of knowledge against all odds.',
    'Adapted', 12, 4)
  RETURNING id INTO t4;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t4, 'Where did Hawking study for his PhD?', 'Oxford', 'Cambridge', 'Harvard', 'MIT', 'B', 'У тексті: "he moved to Cambridge to pursue a PhD in cosmology."', 1),
  (t4, 'At what age was Hawking diagnosed with ALS?', '17', '19', '21', '25', 'C', 'У тексті: "At the age of 21, Hawking was diagnosed with ALS."', 2),
  (t4, 'What is "Hawking radiation"?', 'A type of star', 'Radiation emitted by black holes', 'A medical treatment', 'A form of energy', 'B', 'У тексті: "black holes emit radiation, now known as Hawking radiation."', 3),
  (t4, 'How many copies did "A Brief History of Time" sell?', '1 million', '10 million', '25 million', '50 million', 'C', 'У тексті: "sold over 25 million copies."', 4);

  -- Text 5: B2 - Technology
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('The Rise of Artificial Intelligence', 'B2', 'Технології',
    'An article exploring how AI is changing our world and the ethical questions it raises.',
    'Artificial Intelligence, or AI, has evolved from a science-fiction concept into a reality that permeates nearly every aspect of modern life. From the algorithms that curate our social media feeds to the voice assistants on our phones, AI is everywhere — and its influence is growing rapidly.\n\nThe term "artificial intelligence" was first coined in 1956 at a conference at Dartmouth College. However, progress was slow for decades due to limited computing power and insufficient data. The breakthrough came in the 2010s with the development of deep learning, a technique that uses neural networks to process vast amounts of data. This enabled machines to recognize images, understand speech, and even generate text with remarkable accuracy.\n\nToday, AI is used in healthcare to diagnose diseases, in finance to detect fraud, in transportation to develop self-driving cars, and in education to personalize learning. Supporters argue that AI will boost productivity and solve some of humanity''s biggest challenges. Critics, however, warn about job displacement, privacy concerns, and the potential for AI to be used maliciously.\n\nOne of the most debated topics is whether AI can truly "think." Current AI systems are excellent at pattern recognition but lack consciousness, empathy, and genuine understanding. They can generate human-like text, but they do not comprehend meaning the way humans do. This raises important philosophical questions about the nature of intelligence itself.\n\nAs AI continues to advance, society faces critical decisions. How do we ensure AI is used ethically? Who is responsible when an AI system makes a mistake? How do we balance innovation with regulation? These questions will shape the future of our relationship with technology.',
    'Adapted from educational sources', 15, 5)
  RETURNING id INTO t5;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t5, 'When was the term "artificial intelligence" first coined?', '1946', '1956', '1976', '2006', 'B', 'У тексті: "first coined in 1956 at a conference at Dartmouth College."', 1),
  (t5, 'What technique enabled the AI breakthrough in the 2010s?', 'Machine translation', 'Deep learning', 'Quantum computing', 'Blockchain', 'B', 'У тексті: "The breakthrough came in the 2010s with the development of deep learning."', 2),
  (t5, 'According to the text, what do critics warn about?', 'AI is too slow', 'Job displacement and privacy', 'AI is too expensive', 'AI is not useful', 'B', 'У тексті: "Critics warn about job displacement, privacy concerns."', 3),
  (t5, 'What does the text say about AI''s ability to "think"?', 'AI can truly think like humans', 'AI lacks consciousness and genuine understanding', 'AI has empathy', 'AI comprehends meaning fully', 'B', 'У тексті: "they lack consciousness, empathy, and genuine understanding."', 4);

  -- Text 6: B2 - Short story
  INSERT INTO reading_texts (title, cefr_level, category, excerpt, body, source, estimated_minutes, sort_order)
  VALUES ('The Lighthouse Keeper', 'B2', 'Художня література',
    'A short story about solitude, duty, and an unexpected encounter.',
    'Old Thomas had been the keeper of the Cromwell Lighthouse for thirty-seven years. Every night, without fail, he climbed the 142 steps to the top and lit the lamp that guided ships safely past the treacherous rocks. He knew every crack in the stone walls, every creak of the spiral staircase, every gust of wind that whistled through the windows.\n\nThe life of a lighthouse keeper is one of solitude. Thomas''s wife had passed away fifteen years ago, and his children lived far away in the city. His only companion was a tabby cat named Storm, who had appeared at the lighthouse door one stormy night and never left.\n\nOne evening in late October, Thomas noticed a small boat struggling in the rough sea. The wind was fierce and the waves crashed against the rocks with terrible force. Without hesitation, he sent up the distress flare and called the coast guard. Then he climbed to the top and kept the lamp burning brighter than ever, pointing the way to safety.\n\nThe boat carried a young woman — a marine biologist, as it turned out — who had been studying dolphins offshore when her engine failed. Thomas wrapped her in a warm blanket, made tea, and listened to her stories about the ocean she loved. She stayed until the storm passed, three days later.\n\nBefore she left, she asked him: "Don''t you get lonely here?" Thomas looked at the lighthouse, at the sea, at Storm curled by the fire. "The sea is always talking," he said with a smile. "You just have to learn how to listen."',
    'Original', 12, 6)
  RETURNING id INTO t6;

  INSERT INTO reading_questions (text_id, question, option_a, option_b, option_c, option_d, correct_option, explanation, sort_order) VALUES
  (t6, 'How long had Thomas been a lighthouse keeper?', '25 years', '30 years', '37 years', '40 years', 'C', 'У тексті: "for thirty-seven years."', 1),
  (t6, 'What was the name of Thomas''s cat?', 'Whiskers', 'Storm', 'Rocky', 'Shadow', 'B', 'У тексті: "a tabby cat named Storm."', 2),
  (t6, 'Why was the young woman at sea?', 'She was fishing', 'She was studying dolphins', 'She was sailing for fun', 'She was lost', 'B', 'У тексті: "a marine biologist... studying dolphins offshore."', 3),
  (t6, 'What did Thomas mean by "The sea is always talking"?', 'The sea makes loud noises', 'He never feels lonely because nature is his companion', 'The sea tells him secrets', 'He talks to the sea', 'B', 'Метафорично: природа заповнює самотність. Контекст усього оповідання.', 4);
END $$;