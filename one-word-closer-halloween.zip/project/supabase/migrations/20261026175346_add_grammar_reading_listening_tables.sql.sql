/*
# Add grammar, reading, listening, and study-plan tables

1. New Tables
- grammar_topics: grammar reference sections (public content)
- grammar_examples: example sentences within a topic (public content)
- grammar_exercises: practice exercises tied to a topic (public content)
- reading_texts: articles and stories for reading practice (public content)
- reading_questions: comprehension questions per text (public content)
- reading_progress: user progress on reading texts (user-scoped)
- listening_tracks: video/audio tracks with subtitle lines (public content)
- listening_subtitles: individual subtitle cues per track (public content)
- listening_progress: user progress on listening tracks (user-scoped)
- user_study_plan: personalized study plan generated from weak topics (user-scoped)

2. Modified Tables
- None. Existing tables are untouched.

3. Security
- Public content tables (grammar_*, reading_texts, reading_questions, listening_tracks, listening_subtitles): RLS enabled, SELECT granted to anon+authenticated, USING(true) policies.
- User-scoped tables (reading_progress, listening_progress, user_study_plan): RLS enabled, CRUD granted to authenticated only, owner-scoped via auth.uid()=user_id with DEFAULT auth.uid() on user_id.

4. Important notes
- All user_id columns default to auth.uid() so frontend inserts that omit user_id still satisfy WITH CHECK.
- No user data is lost; these are purely additive tables.
*/

-- GRAMMAR TOPICS
CREATE TABLE IF NOT EXISTS grammar_topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title_uk text NOT NULL,
  title_en text NOT NULL,
  cefr_level text NOT NULL DEFAULT 'A1',
  category text NOT NULL DEFAULT '',
  summary text DEFAULT '',
  explanation text NOT NULL DEFAULT '',
  rules text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE grammar_topics ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON grammar_topics TO anon, authenticated;
DROP POLICY IF EXISTS "read_grammar_topics" ON grammar_topics;
CREATE POLICY "read_grammar_topics" ON grammar_topics FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_grammar_topics_level ON grammar_topics(cefr_level);

-- GRAMMAR EXAMPLES
CREATE TABLE IF NOT EXISTS grammar_examples (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES grammar_topics(id) ON DELETE CASCADE,
  sentence_en text NOT NULL,
  sentence_uk text NOT NULL,
  note text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE grammar_examples ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON grammar_examples TO anon, authenticated;
DROP POLICY IF EXISTS "read_grammar_examples" ON grammar_examples;
CREATE POLICY "read_grammar_examples" ON grammar_examples FOR SELECT TO anon, authenticated USING (true);

-- GRAMMAR EXERCISES
CREATE TABLE IF NOT EXISTS grammar_exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  topic_id uuid NOT NULL REFERENCES grammar_topics(id) ON DELETE CASCADE,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  option_c text NOT NULL,
  option_d text NOT NULL,
  correct_option char(1) NOT NULL,
  explanation text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE grammar_exercises ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON grammar_exercises TO anon, authenticated;
DROP POLICY IF EXISTS "read_grammar_exercises" ON grammar_exercises;
CREATE POLICY "read_grammar_exercises" ON grammar_exercises FOR SELECT TO anon, authenticated USING (true);

-- READING TEXTS
CREATE TABLE IF NOT EXISTS reading_texts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  cefr_level text NOT NULL DEFAULT 'A1',
  category text NOT NULL DEFAULT '',
  excerpt text NOT NULL DEFAULT '',
  body text NOT NULL,
  source text DEFAULT '',
  estimated_minutes int NOT NULL DEFAULT 10,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE reading_texts ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON reading_texts TO anon, authenticated;
DROP POLICY IF EXISTS "read_reading_texts" ON reading_texts;
CREATE POLICY "read_reading_texts" ON reading_texts FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_reading_level ON reading_texts(cefr_level);

-- READING QUESTIONS
CREATE TABLE IF NOT EXISTS reading_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text_id uuid NOT NULL REFERENCES reading_texts(id) ON DELETE CASCADE,
  question text NOT NULL,
  option_a text NOT NULL,
  option_b text NOT NULL,
  option_c text NOT NULL,
  option_d text NOT NULL,
  correct_option char(1) NOT NULL,
  explanation text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE reading_questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON reading_questions TO anon, authenticated;
DROP POLICY IF EXISTS "read_reading_questions" ON reading_questions;
CREATE POLICY "read_reading_questions" ON reading_questions FOR SELECT TO anon, authenticated USING (true);

-- READING PROGRESS
CREATE TABLE IF NOT EXISTS reading_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  text_id uuid NOT NULL REFERENCES reading_texts(id) ON DELETE CASCADE,
  score int NOT NULL DEFAULT 0,
  total_questions int NOT NULL DEFAULT 0,
  completed_at timestamptz DEFAULT now(),
  UNIQUE(user_id, text_id)
);
ALTER TABLE reading_progress ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON reading_progress TO authenticated;
DROP POLICY IF EXISTS "select_own_reading_progress" ON reading_progress;
CREATE POLICY "select_own_reading_progress" ON reading_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_reading_progress" ON reading_progress;
CREATE POLICY "insert_own_reading_progress" ON reading_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_reading_progress" ON reading_progress;
CREATE POLICY "update_own_reading_progress" ON reading_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_reading_progress" ON reading_progress;
CREATE POLICY "delete_own_reading_progress" ON reading_progress FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_reading_progress_user ON reading_progress(user_id);

-- LISTENING TRACKS
CREATE TABLE IF NOT EXISTS listening_tracks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  cefr_level text NOT NULL DEFAULT 'A1',
  category text NOT NULL DEFAULT '',
  description text DEFAULT '',
  video_url text DEFAULT '',
  audio_url text DEFAULT '',
  duration_seconds int NOT NULL DEFAULT 0,
  thumbnail_url text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE listening_tracks ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON listening_tracks TO anon, authenticated;
DROP POLICY IF EXISTS "read_listening_tracks" ON listening_tracks;
CREATE POLICY "read_listening_tracks" ON listening_tracks FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_listening_level ON listening_tracks(cefr_level);

-- LISTENING SUBTITLES
CREATE TABLE IF NOT EXISTS listening_subtitles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  track_id uuid NOT NULL REFERENCES listening_tracks(id) ON DELETE CASCADE,
  start_time numeric NOT NULL,
  end_time numeric NOT NULL,
  text_en text NOT NULL,
  text_uk text NOT NULL,
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE listening_subtitles ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON listening_subtitles TO anon, authenticated;
DROP POLICY IF EXISTS "read_listening_subtitles" ON listening_subtitles;
CREATE POLICY "read_listening_subtitles" ON listening_subtitles FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_listening_subs_track ON listening_subtitles(track_id);

-- LISTENING PROGRESS
CREATE TABLE IF NOT EXISTS listening_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  track_id uuid NOT NULL REFERENCES listening_tracks(id) ON DELETE CASCADE,
  watched_seconds int NOT NULL DEFAULT 0,
  completed boolean NOT NULL DEFAULT false,
  last_watched_at timestamptz DEFAULT now(),
  UNIQUE(user_id, track_id)
);
ALTER TABLE listening_progress ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON listening_progress TO authenticated;
DROP POLICY IF EXISTS "select_own_listening_progress" ON listening_progress;
CREATE POLICY "select_own_listening_progress" ON listening_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_listening_progress" ON listening_progress;
CREATE POLICY "insert_own_listening_progress" ON listening_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_listening_progress" ON listening_progress;
CREATE POLICY "update_own_listening_progress" ON listening_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_listening_progress" ON listening_progress;
CREATE POLICY "delete_own_listening_progress" ON listening_progress FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_listening_progress_user ON listening_progress(user_id);

-- USER STUDY PLAN
CREATE TABLE IF NOT EXISTS user_study_plan (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_date date NOT NULL DEFAULT CURRENT_DATE,
  task_type text NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  target_url text DEFAULT '',
  difficulty text DEFAULT 'normal',
  is_completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE user_study_plan ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON user_study_plan TO authenticated;
DROP POLICY IF EXISTS "select_own_study_plan" ON user_study_plan;
CREATE POLICY "select_own_study_plan" ON user_study_plan FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_study_plan" ON user_study_plan;
CREATE POLICY "insert_own_study_plan" ON user_study_plan FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_study_plan" ON user_study_plan;
CREATE POLICY "update_own_study_plan" ON user_study_plan FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_study_plan" ON user_study_plan;
CREATE POLICY "delete_own_study_plan" ON user_study_plan FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_study_plan_user_date ON user_study_plan(user_id, plan_date);