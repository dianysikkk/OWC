/*
# Organize the imported photo glossary vocabulary

1. New data
- Adds four missing public categories: Appearance, Clothes, Materials & Patterns,
  and Ethical Problems.
- Assigns imported appearance, clothing, textile, pattern, and ethical-problem terms
  to those categories.

2. Modified tables
- `vocabulary_categories`: additive category rows only.
- `vocabulary`: category_id updates only for the imported glossary groups.

3. Security
- No policy changes. Existing public read policies remain in place.

4. Important notes
- Existing words and translations are preserved.
- Category assignment is idempotent and safe to repeat.
*/

INSERT INTO vocabulary_categories (name_uk, name_en, icon, sort_order)
SELECT v.name_uk, v.name_en, v.icon, v.sort_order
FROM (VALUES
  ('Зовнішність', 'Appearance', 'user-round', 21),
  ('Одяг', 'Clothes', 'shirt', 22),
  ('Матеріали та візерунки', 'Materials & Patterns', 'palette', 23),
  ('Етичні проблеми', 'Ethical Problems', 'scale', 24)
) AS v(name_uk, name_en, icon, sort_order)
WHERE NOT EXISTS (
  SELECT 1 FROM vocabulary_categories c WHERE c.name_en = v.name_en
);

UPDATE vocabulary
SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Appearance' LIMIT 1)
WHERE lower(word) IN (
  'age','newborn baby','infant','toddler','adolescent','teenager','adult','middle-aged','elderly',
  'in his twenties','in her thirties','athletic','broad-shouldered','muscular','lanky','stocky',
  'birthmark','scar','hazel','bright eyes','oval','thin face','beard','moustache','dimples',
  'forehead','cheeks','chin','eyebrows','neck','freckles','wrinkles','pimples','spots',
  'broad smile','tight-lipped smile','blonde','dark hair','fair hair','red hair','grey hair',
  'dyed hair','spiky hair','cropped hair','shoulder-length','medium-length','fringe','ponytail',
  'centre parting','side parting','bald','wig','snub nose','pointed nose','pale','tanned',
  'tattoo','well-built','obese','overweight','plump','skinny','slim','curly','straight','wavy'
);

UPDATE vocabulary
SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Clothes' LIMIT 1)
WHERE lower(word) IN (
  'appropriate for the occasion','baggy','designer','expensive','second-hand','faded','formal',
  'smart','elegant','knitted','long-sleeved','short-sleeved','sleeveless','ripped','tight-fitting',
  'loose-fitting','anorak','braces','collar','contact lenses','flip-flops','gloves',
  'hooded sweatshirt','overcoat','polo neck','pyjamas','sandals','scarf','slippers','suit',
  'swimming trunks','swimsuit','tie','bow tie','tights','tracksuit','trainers','underwear',
  'wellingtons','blouse','boots','bra','casual','coat','dress','fashionable','fleece','hat',
  'jacket','jeans','jumper','old-fashioned','shirt','shoes','shorts','skirt','socks',
  'sweatshirt','trousers','waistcoat','wear'
);

UPDATE vocabulary
SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Materials & Patterns' LIMIT 1)
WHERE lower(word) IN (
  'cotton','denim','fur','lace','leather','linen','nylon','rubber','silk','wool','woollen',
  'checked','dotted','floral','plain','striped'
);

UPDATE vocabulary
SET category_id = (SELECT id FROM vocabulary_categories WHERE name_en = 'Ethical Problems' LIMIT 1)
WHERE lower(word) IN (
  'abortion','charity','drug abuse','fair trade','homelessness','unemployment','corruption',
  'racism','euthanasia','genetic engineering','privacy'
);