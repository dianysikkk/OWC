/*
# One Word Closer — Initial Schema

1. Overview
Creates the full database schema for an English learning + NMT prep platform.
Includes profiles, settings, vocabulary, spaced repetition reviews, courses,
lessons, progress tracking, exercises, exams, achievements, study sessions,
study plans, collections, notifications, and support tickets.

2. New Tables
- profiles: user display info (extends auth.users)
- user_settings: per-user app preferences (theme, language, notifications, daily goal)
- vocabulary: master vocabulary table (public content)
- vocabulary_categories: categories for vocabulary (public content)
- user_vocabulary: user's personal vocabulary state (learned, favorite, difficult)
- vocabulary_reviews: spaced repetition review history (SM-2 algorithm)
- vocabulary_decks: user-created custom word decks
- vocabulary_deck_items: items in custom decks
- courses: course catalog (public content)
- modules: modules within courses (public content)
- lessons: lessons within modules (public content)
- lesson_progress: user progress on lessons
- exercises: exercise sets (public content)
- exercise_questions: questions within exercises (public content)
- exercise_options: answer options for multiple choice (public content)
- exercise_attempts: user attempts on exercises
- exam_variants: NMT exam variants (public content)
- exam_questions: questions within exam variants (public content)
- exam_attempts: user exam attempts
- exam_answers: individual answers in an exam attempt
- study_sessions: log of study activity sessions
- study_plans: user's study plan entries
- achievements: achievement definitions (public content)
- user_achievements: achievements earned by users
- notifications: user notifications
- support_tickets: user support requests

3. Security
- RLS enabled on ALL tables.
- Public content tables readable by anon + authenticated.
- User data tables readable/writable only by the owning authenticated user.
- All owner columns default to auth.uid() for seamless inserts.
*/

-- PROFILES
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  display_name text NOT NULL DEFAULT '',
  avatar_url text DEFAULT '',
  bio text DEFAULT '',
  current_level text NOT NULL DEFAULT 'A1',
  target_level text NOT NULL DEFAULT 'B1',
  daily_goal_minutes int NOT NULL DEFAULT 15,
  total_xp int NOT NULL DEFAULT 0,
  streak_days int NOT NULL DEFAULT 0,
  last_study_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON profiles TO authenticated;
DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT TO authenticated USING (auth.uid() = id);
DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- USER SETTINGS
CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  theme text NOT NULL DEFAULT 'light',
  interface_language text NOT NULL DEFAULT 'uk',
  notification_reviews boolean NOT NULL DEFAULT true,
  notification_lessons boolean NOT NULL DEFAULT true,
  notification_marketing boolean NOT NULL DEFAULT false,
  gamification_enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON user_settings TO authenticated;
DROP POLICY IF EXISTS "select_own_settings" ON user_settings;
CREATE POLICY "select_own_settings" ON user_settings FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_settings" ON user_settings;
CREATE POLICY "insert_own_settings" ON user_settings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_settings" ON user_settings;
CREATE POLICY "update_own_settings" ON user_settings FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- VOCABULARY CATEGORIES
CREATE TABLE IF NOT EXISTS vocabulary_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_uk text NOT NULL,
  name_en text NOT NULL,
  icon text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE vocabulary_categories ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON vocabulary_categories TO anon, authenticated;
DROP POLICY IF EXISTS "read_categories" ON vocabulary_categories;
CREATE POLICY "read_categories" ON vocabulary_categories FOR SELECT TO anon, authenticated USING (true);

-- VOCABULARY
CREATE TABLE IF NOT EXISTS vocabulary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  word text NOT NULL,
  translation_uk text NOT NULL,
  transcription text DEFAULT '',
  part_of_speech text DEFAULT '',
  cefr_level text NOT NULL DEFAULT 'A1',
  example_en text DEFAULT '',
  example_uk text DEFAULT '',
  collocations text DEFAULT '',
  synonyms text DEFAULT '',
  antonyms text DEFAULT '',
  common_mistakes text DEFAULT '',
  category_id uuid REFERENCES vocabulary_categories(id) ON DELETE SET NULL,
  is_for_nmt boolean NOT NULL DEFAULT false,
  difficulty int NOT NULL DEFAULT 3,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE vocabulary ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON vocabulary TO anon, authenticated;
DROP POLICY IF EXISTS "read_vocabulary" ON vocabulary;
CREATE POLICY "read_vocabulary" ON vocabulary FOR SELECT TO anon, authenticated USING (true);
CREATE INDEX IF NOT EXISTS idx_vocabulary_category ON vocabulary(category_id);
CREATE INDEX IF NOT EXISTS idx_vocabulary_level ON vocabulary(cefr_level);
CREATE INDEX IF NOT EXISTS idx_vocabulary_word ON vocabulary(word);

-- USER VOCABULARY
CREATE TABLE IF NOT EXISTS user_vocabulary (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  vocabulary_id uuid NOT NULL REFERENCES vocabulary(id) ON DELETE CASCADE,
  is_favorite boolean NOT NULL DEFAULT false,
  is_difficult boolean NOT NULL DEFAULT false,
  is_learned boolean NOT NULL DEFAULT false,
  times_practiced int NOT NULL DEFAULT 0,
  times_correct int NOT NULL DEFAULT 0,
  first_studied_at timestamptz,
  last_studied_at timestamptz,
  sm2_interval int NOT NULL DEFAULT 0,
  sm2_repetitions int NOT NULL DEFAULT 0,
  sm2_easiness numeric NOT NULL DEFAULT 2.5,
  sm2_next_review date NOT NULL DEFAULT CURRENT_DATE,
  UNIQUE(user_id, vocabulary_id)
);
ALTER TABLE user_vocabulary ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON user_vocabulary TO authenticated;
DROP POLICY IF EXISTS "select_own_uv" ON user_vocabulary;
CREATE POLICY "select_own_uv" ON user_vocabulary FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_uv" ON user_vocabulary;
CREATE POLICY "insert_own_uv" ON user_vocabulary FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_uv" ON user_vocabulary;
CREATE POLICY "update_own_uv" ON user_vocabulary FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_uv" ON user_vocabulary;
CREATE POLICY "delete_own_uv" ON user_vocabulary FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_uv_user ON user_vocabulary(user_id);
CREATE INDEX IF NOT EXISTS idx_uv_next_review ON user_vocabulary(sm2_next_review);

-- VOCABULARY REVIEWS
CREATE TABLE IF NOT EXISTS vocabulary_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  vocabulary_id uuid NOT NULL REFERENCES vocabulary(id) ON DELETE CASCADE,
  quality int NOT NULL,
  was_correct boolean NOT NULL,
  reviewed_at timestamptz DEFAULT now()
);
ALTER TABLE vocabulary_reviews ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, DELETE ON vocabulary_reviews TO authenticated;
DROP POLICY IF EXISTS "select_own_reviews" ON vocabulary_reviews;
CREATE POLICY "select_own_reviews" ON vocabulary_reviews FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_reviews" ON vocabulary_reviews;
CREATE POLICY "insert_own_reviews" ON vocabulary_reviews FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_reviews" ON vocabulary_reviews;
CREATE POLICY "delete_own_reviews" ON vocabulary_reviews FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user ON vocabulary_reviews(user_id);

-- VOCABULARY DECKS
CREATE TABLE IF NOT EXISTS vocabulary_decks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE vocabulary_decks ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON vocabulary_decks TO authenticated;
DROP POLICY IF EXISTS "select_own_decks" ON vocabulary_decks;
CREATE POLICY "select_own_decks" ON vocabulary_decks FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_decks" ON vocabulary_decks;
CREATE POLICY "insert_own_decks" ON vocabulary_decks FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_decks" ON vocabulary_decks;
CREATE POLICY "update_own_decks" ON vocabulary_decks FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_decks" ON vocabulary_decks;
CREATE POLICY "delete_own_decks" ON vocabulary_decks FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- VOCABULARY DECK ITEMS
CREATE TABLE IF NOT EXISTS vocabulary_deck_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deck_id uuid NOT NULL REFERENCES vocabulary_decks(id) ON DELETE CASCADE,
  vocabulary_id uuid NOT NULL REFERENCES vocabulary(id) ON DELETE CASCADE,
  added_at timestamptz DEFAULT now(),
  UNIQUE(deck_id, vocabulary_id)
);
ALTER TABLE vocabulary_deck_items ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, DELETE ON vocabulary_deck_items TO authenticated;
DROP POLICY IF EXISTS "select_own_deck_items" ON vocabulary_deck_items;
CREATE POLICY "select_own_deck_items" ON vocabulary_deck_items FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM vocabulary_decks WHERE vocabulary_decks.id = vocabulary_deck_items.deck_id AND vocabulary_decks.user_id = auth.uid())
);
DROP POLICY IF EXISTS "insert_own_deck_items" ON vocabulary_deck_items;
CREATE POLICY "insert_own_deck_items" ON vocabulary_deck_items FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM vocabulary_decks WHERE vocabulary_decks.id = vocabulary_deck_items.deck_id AND vocabulary_decks.user_id = auth.uid())
);
DROP POLICY IF EXISTS "delete_own_deck_items" ON vocabulary_deck_items;
CREATE POLICY "delete_own_deck_items" ON vocabulary_deck_items FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM vocabulary_decks WHERE vocabulary_decks.id = vocabulary_deck_items.deck_id AND vocabulary_decks.user_id = auth.uid())
);

-- COURSES
CREATE TABLE IF NOT EXISTS courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL DEFAULT '',
  cefr_level text NOT NULL DEFAULT 'A1',
  cover_emoji text DEFAULT '',
  is_published boolean NOT NULL DEFAULT true,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE courses ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON courses TO anon, authenticated;
DROP POLICY IF EXISTS "read_courses" ON courses;
CREATE POLICY "read_courses" ON courses FOR SELECT TO anon, authenticated USING (is_published = true);

-- MODULES
CREATE TABLE IF NOT EXISTS modules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE modules ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON modules TO anon, authenticated;
DROP POLICY IF EXISTS "read_modules" ON modules;
CREATE POLICY "read_modules" ON modules FOR SELECT TO anon, authenticated USING (true);

-- LESSONS
CREATE TABLE IF NOT EXISTS lessons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id uuid NOT NULL REFERENCES modules(id) ON DELETE CASCADE,
  title text NOT NULL,
  content text DEFAULT '',
  lesson_type text NOT NULL DEFAULT 'theory',
  estimated_minutes int NOT NULL DEFAULT 10,
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE lessons ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON lessons TO anon, authenticated;
DROP POLICY IF EXISTS "read_lessons" ON lessons;
CREATE POLICY "read_lessons" ON lessons FOR SELECT TO anon, authenticated USING (true);

-- LESSON PROGRESS
CREATE TABLE IF NOT EXISTS lesson_progress (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id uuid NOT NULL REFERENCES lessons(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'not_started',
  progress_percent int NOT NULL DEFAULT 0,
  started_at timestamptz,
  completed_at timestamptz,
  UNIQUE(user_id, lesson_id)
);
ALTER TABLE lesson_progress ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON lesson_progress TO authenticated;
DROP POLICY IF EXISTS "select_own_lp" ON lesson_progress;
CREATE POLICY "select_own_lp" ON lesson_progress FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_lp" ON lesson_progress;
CREATE POLICY "insert_own_lp" ON lesson_progress FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_lp" ON lesson_progress;
CREATE POLICY "update_own_lp" ON lesson_progress FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- EXERCISES
CREATE TABLE IF NOT EXISTS exercises (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  lesson_id uuid REFERENCES lessons(id) ON DELETE CASCADE,
  title text NOT NULL,
  exercise_type text NOT NULL DEFAULT 'multiple_choice',
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON exercises TO anon, authenticated;
DROP POLICY IF EXISTS "read_exercises" ON exercises;
CREATE POLICY "read_exercises" ON exercises FOR SELECT TO anon, authenticated USING (true);

-- EXERCISE QUESTIONS
CREATE TABLE IF NOT EXISTS exercise_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exercise_id uuid NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
  question_text text NOT NULL,
  correct_answer text NOT NULL,
  hint text DEFAULT '',
  explanation text DEFAULT '',
  sort_order int NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exercise_questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON exercise_questions TO anon, authenticated;
DROP POLICY IF EXISTS "read_eq" ON exercise_questions;
CREATE POLICY "read_eq" ON exercise_questions FOR SELECT TO anon, authenticated USING (true);

-- EXERCISE OPTIONS
CREATE TABLE IF NOT EXISTS exercise_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES exercise_questions(id) ON DELETE CASCADE,
  option_text text NOT NULL,
  is_correct boolean NOT NULL DEFAULT false,
  sort_order int NOT NULL DEFAULT 0
);
ALTER TABLE exercise_options ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON exercise_options TO anon, authenticated;
DROP POLICY IF EXISTS "read_eo" ON exercise_options;
CREATE POLICY "read_eo" ON exercise_options FOR SELECT TO anon, authenticated USING (true);

-- EXERCISE ATTEMPTS
CREATE TABLE IF NOT EXISTS exercise_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  exercise_id uuid NOT NULL REFERENCES exercises(id) ON DELETE CASCADE,
  score int NOT NULL DEFAULT 0,
  total_questions int NOT NULL DEFAULT 0,
  time_spent_seconds int NOT NULL DEFAULT 0,
  completed_at timestamptz DEFAULT now()
);
ALTER TABLE exercise_attempts ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON exercise_attempts TO authenticated;
DROP POLICY IF EXISTS "select_own_ea" ON exercise_attempts;
CREATE POLICY "select_own_ea" ON exercise_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_ea" ON exercise_attempts;
CREATE POLICY "insert_own_ea" ON exercise_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_ea_user ON exercise_attempts(user_id);

-- EXAM VARIANTS
CREATE TABLE IF NOT EXISTS exam_variants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text DEFAULT '',
  duration_minutes int NOT NULL DEFAULT 60,
  is_published boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exam_variants ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON exam_variants TO anon, authenticated;
DROP POLICY IF EXISTS "read_exams" ON exam_variants;
CREATE POLICY "read_exams" ON exam_variants FOR SELECT TO anon, authenticated USING (is_published = true);

-- EXAM QUESTIONS
CREATE TABLE IF NOT EXISTS exam_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_variant_id uuid NOT NULL REFERENCES exam_variants(id) ON DELETE CASCADE,
  question_number int NOT NULL,
  question_text text NOT NULL,
  option_a text NOT NULL DEFAULT '',
  option_b text NOT NULL DEFAULT '',
  option_c text NOT NULL DEFAULT '',
  option_d text NOT NULL DEFAULT '',
  correct_option text NOT NULL DEFAULT 'A',
  explanation text DEFAULT '',
  topic text DEFAULT '',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE exam_questions ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON exam_questions TO anon, authenticated;
DROP POLICY IF EXISTS "read_eq_exam" ON exam_questions;
CREATE POLICY "read_eq_exam" ON exam_questions FOR SELECT TO anon, authenticated USING (true);

-- EXAM ATTEMPTS
CREATE TABLE IF NOT EXISTS exam_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  exam_variant_id uuid NOT NULL REFERENCES exam_variants(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'in_progress',
  score int NOT NULL DEFAULT 0,
  total_questions int NOT NULL DEFAULT 0,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz,
  time_spent_seconds int NOT NULL DEFAULT 0
);
ALTER TABLE exam_attempts ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON exam_attempts TO authenticated;
DROP POLICY IF EXISTS "select_own_xa" ON exam_attempts;
CREATE POLICY "select_own_xa" ON exam_attempts FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_xa" ON exam_attempts;
CREATE POLICY "insert_own_xa" ON exam_attempts FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_xa" ON exam_attempts;
CREATE POLICY "update_own_xa" ON exam_attempts FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- EXAM ANSWERS
CREATE TABLE IF NOT EXISTS exam_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  exam_attempt_id uuid NOT NULL REFERENCES exam_attempts(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES exam_questions(id) ON DELETE CASCADE,
  selected_option text,
  is_marked boolean NOT NULL DEFAULT false,
  answered_at timestamptz
);
ALTER TABLE exam_answers ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE ON exam_answers TO authenticated;
DROP POLICY IF EXISTS "select_own_xans" ON exam_answers;
CREATE POLICY "select_own_xans" ON exam_answers FOR SELECT TO authenticated USING (
  EXISTS (SELECT 1 FROM exam_attempts WHERE exam_attempts.id = exam_answers.exam_attempt_id AND exam_attempts.user_id = auth.uid())
);
DROP POLICY IF EXISTS "insert_own_xans" ON exam_answers;
CREATE POLICY "insert_own_xans" ON exam_answers FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM exam_attempts WHERE exam_attempts.id = exam_answers.exam_attempt_id AND exam_attempts.user_id = auth.uid())
);
DROP POLICY IF EXISTS "update_own_xans" ON exam_answers;
CREATE POLICY "update_own_xans" ON exam_answers FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM exam_attempts WHERE exam_attempts.id = exam_answers.exam_attempt_id AND exam_attempts.user_id = auth.uid())
) WITH CHECK (
  EXISTS (SELECT 1 FROM exam_attempts WHERE exam_attempts.id = exam_answers.exam_attempt_id AND exam_attempts.user_id = auth.uid())
);

-- STUDY SESSIONS
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  session_type text NOT NULL DEFAULT 'vocabulary',
  duration_seconds int NOT NULL DEFAULT 0,
  items_studied int NOT NULL DEFAULT 0,
  items_correct int NOT NULL DEFAULT 0,
  xp_earned int NOT NULL DEFAULT 0,
  studied_at date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON study_sessions TO authenticated;
DROP POLICY IF EXISTS "select_own_ss" ON study_sessions;
CREATE POLICY "select_own_ss" ON study_sessions FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_ss" ON study_sessions;
CREATE POLICY "insert_own_ss" ON study_sessions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_ss_user_date ON study_sessions(user_id, studied_at);

-- STUDY PLANS
CREATE TABLE IF NOT EXISTS study_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  plan_date date NOT NULL DEFAULT CURRENT_DATE,
  task_type text NOT NULL,
  title text NOT NULL,
  duration_minutes int NOT NULL DEFAULT 10,
  is_completed boolean NOT NULL DEFAULT false,
  completed_at timestamptz,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE study_plans ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON study_plans TO authenticated;
DROP POLICY IF EXISTS "select_own_sp" ON study_plans;
CREATE POLICY "select_own_sp" ON study_plans FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_sp" ON study_plans;
CREATE POLICY "insert_own_sp" ON study_plans FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_sp" ON study_plans;
CREATE POLICY "update_own_sp" ON study_plans FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_sp" ON study_plans;
CREATE POLICY "delete_own_sp" ON study_plans FOR DELETE TO authenticated USING (auth.uid() = user_id);
CREATE INDEX IF NOT EXISTS idx_sp_user_date ON study_plans(user_id, plan_date);

-- ACHIEVEMENTS
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text NOT NULL UNIQUE,
  title_uk text NOT NULL,
  title_en text NOT NULL,
  description_uk text NOT NULL,
  description_en text NOT NULL,
  icon text NOT NULL DEFAULT '',
  xp_reward int NOT NULL DEFAULT 0,
  threshold int NOT NULL DEFAULT 1,
  metric text NOT NULL DEFAULT 'words_learned',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;
GRANT SELECT ON achievements TO anon, authenticated;
DROP POLICY IF EXISTS "read_achievements" ON achievements;
CREATE POLICY "read_achievements" ON achievements FOR SELECT TO anon, authenticated USING (true);

-- USER ACHIEVEMENTS
CREATE TABLE IF NOT EXISTS user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  achievement_id uuid NOT NULL REFERENCES achievements(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  UNIQUE(user_id, achievement_id)
);
ALTER TABLE user_achievements ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON user_achievements TO authenticated;
DROP POLICY IF EXISTS "select_own_ua" ON user_achievements;
CREATE POLICY "select_own_ua" ON user_achievements FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_ua" ON user_achievements;
CREATE POLICY "insert_own_ua" ON user_achievements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

-- NOTIFICATIONS
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info',
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT, UPDATE, DELETE ON notifications TO authenticated;
DROP POLICY IF EXISTS "select_own_notif" ON notifications;
CREATE POLICY "select_own_notif" ON notifications FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_notif" ON notifications;
CREATE POLICY "insert_own_notif" ON notifications FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "update_own_notif" ON notifications;
CREATE POLICY "update_own_notif" ON notifications FOR UPDATE TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
DROP POLICY IF EXISTS "delete_own_notif" ON notifications;
CREATE POLICY "delete_own_notif" ON notifications FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- SUPPORT TICKETS
CREATE TABLE IF NOT EXISTS support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  subject text NOT NULL,
  category text NOT NULL DEFAULT 'general',
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz DEFAULT now()
);
ALTER TABLE support_tickets ENABLE ROW LEVEL SECURITY;
GRANT SELECT, INSERT ON support_tickets TO authenticated;
DROP POLICY IF EXISTS "select_own_tickets" ON support_tickets;
CREATE POLICY "select_own_tickets" ON support_tickets FOR SELECT TO authenticated USING (auth.uid() = user_id);
DROP POLICY IF EXISTS "insert_own_tickets" ON support_tickets;
CREATE POLICY "insert_own_tickets" ON support_tickets FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
