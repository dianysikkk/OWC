/*
# Add remaining appearance and clothing glossary details

1. New data
- Adds additional visible items for facial features, complexion, accessories,
  footwear, and clothing actions from the photographed glossary.

2. Modified data
- Existing rows remain unchanged.
- Duplicate English entries are skipped.

3. Security
- No schema, access, or policy changes.
*/

WITH glossary(word, translation_uk, transcription, part_of_speech, cefr_level, example_en, example_uk, category_id, is_for_nmt, difficulty) AS (
  VALUES
  ('beard','борода','/bɪəd/','noun','A1','He has a short beard.','У нього коротка борода.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,1),
  ('freckles','веснянки','/ˈfrekəlz/','noun','B1','She has freckles on her nose.','У неї веснянки на носі.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,3),
  ('moustache','вуса','/məˈstɑːʃ/','noun','A2','His moustache is grey.','Його вуса сиві.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,2),
  ('piercing','пірсинг','/ˈpɪəsɪŋ/','noun','B1','She has a nose piercing.','У неї є пірсинг носа.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,3),
  ('scar','шрам','/skɑː/','noun','B1','He has a scar on his cheek.','У нього шрам на щоці.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,3),
  ('tattoo','татуювання','/təˈtuː/','noun','B1','He has a tattoo on his arm.','У нього татуювання на руці.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,3),
  ('wrinkles','зморшки','/ˈrɪŋkəlz/','noun','B1','She has a few wrinkles around her eyes.','У неї є кілька зморшок навколо очей.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,3),
  ('clean-shaven','гладко поголений','/ˌkliːn ˈʃeɪvən/','adjective','B2','He is usually clean-shaven.','Зазвичай він гладко поголений.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,4),
  ('clear skin','чиста шкіра','/klɪə skɪn/','noun phrase','B1','Drinking water can help you have clear skin.','Вода може допомогти зберегти чисту шкіру.','bb0ba817-b89f-4ef2-be05-b9855c4a626c'::uuid,true,3),
  ('double chin','подвійне підборіддя','/ˌdʌbəl ˈtʃɪn/','noun phrase','B2','The portrait showed his double chin.','На портреті було видно його подвійне підборіддя.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,4),
  ('high cheekbones','високі вилиці','/haɪ ˈtʃiːkbəʊnz/','noun phrase','B2','She has high cheekbones.','У неї високі вилиці.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,4),
  ('high forehead','високе чоло','/haɪ ˈfɒrɪd/','noun phrase','B2','He has a high forehead.','У нього високе чоло.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,4),
  ('piercing blue eyes','пронизливі блакитні очі','/ˈpɪəsɪŋ bluː aɪz/','noun phrase','B2','She has piercing blue eyes.','У неї пронизливі блакитні очі.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,4),
  ('round face','кругле обличчя','/raʊnd feɪs/','noun phrase','A2','The child has a round face.','У дитини кругле обличчя.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,2),
  ('tanned','засмаглий','/tænd/','adjective','B1','He came back from holiday tanned.','Він повернувся з відпочинку засмаглим.','f4413b8e-9e53-4060-a997-0b5848df7250'::uuid,true,3),
  ('wide mouth','широкий рот','/waɪd maʊθ/','noun phrase','A2','The character has a wide mouth.','У персонажа широкий рот.','70a6ffbf-31dd-432b-9254-0b9f655caaaa'::uuid,true,2),
  ('bracelet','браслет','/ˈbreɪslət/','noun','A2','She wears a silver bracelet.','Вона носить срібний браслет.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,2),
  ('brooch','брошка','/brəʊtʃ/','noun','B2','The brooch belonged to her grandmother.','Брошка належала її бабусі.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,4),
  ('shoelaces','шнурки','/ˈʃuːleɪsɪz/','noun','A2','Tie your shoelaces carefully.','Обережно зав''яжи шнурки.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,2),
  ('slippers','капці','/ˈslɪpəz/','noun','A1','I wear slippers at home.','Я ношу капці вдома.','0dc4b141-b0cc-4729-9f3e-2a4b3be7d784'::uuid,true,1),
  ('zip-up','на блискавці','/ˈzɪp ʌp/','adjective','B1','He wore a zip-up jacket.','Він носив куртку на блискавці.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,3),
  ('modest','скромний','/ˈmɒdɪst/','adjective','B1','She prefers modest clothes.','Вона надає перевагу скромному одягу.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,3),
  ('odd','дивний; непарний','/ɒd/','adjective','A2','That is an odd question.','Це дивне питання.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,2),
  ('sensitive','чутливий','/ˈsensɪtɪv/','adjective','B1','He is sensitive to criticism.','Він чутливий до критики.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,3),
  ('sympathetic','співчутливий','/ˌsɪmpəˈθetɪk/','adjective','B2','She was sympathetic to my problem.','Вона співчувала моїй проблемі.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,4),
  ('weird','дивний; чудернацький','/wɪəd/','adjective','B1','That was a weird dream.','Це був дивний сон.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,3),
  ('outgoing personality','товариський характер','/ˈaʊtɡəʊɪŋ ˌpɜːsəˈnæləti/','noun phrase','B2','Her outgoing personality made friends quickly.','Її товариський характер допоміг швидко знайти друзів.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,4),
  ('adore','обожнювати','/əˈdɔː/','verb','B1','Children adore their kind teacher.','Діти обожнюють свого доброго вчителя.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,3),
  ('relieved','відчувати полегшення','/rɪˈliːvd/','adjective','B1','I was relieved to hear the good news.','Я відчув полегшення, почувши добрі новини.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,3),
  ('worried sick','дуже стурбований','/ˈwʌrid sɪk/','phrase','B2','Her parents were worried sick.','Її батьки дуже хвилювалися.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,4),
  ('make a resolution','прийняти рішення','/meɪk ə ˌrezəˈluːʃən/','collocation','B2','She made a resolution to exercise more.','Вона вирішила більше займатися спортом.','cfdbe771-3daf-4dc8-b973-d395a04dddda'::uuid,true,4),
  ('be hopeless at something','бути безнадійним у чомусь','/biː ˈhəʊpləs æt/','phrase','B2','I am hopeless at remembering names.','Я безнадійний у запам''ятовуванні імен.','6dfa3b8f-8d52-4194-8ba1-4a88d5020cd2'::uuid,true,4),
  ('put on','одягати','/pʊt ɒn/','phrasal verb','A1','Put on your coat before you go out.','Одягни пальто перед виходом.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,1),
  ('take off','знімати одяг','/teɪk ɒf/','phrasal verb','A1','Take off your wet shoes.','Зніми мокре взуття.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,1),
  ('dress up','ошатно вдягатися','/dres ʌp/','phrasal verb','B1','We dressed up for the wedding.','Ми ошатно вдягнулися на весілля.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,3),
  ('try on','приміряти','/traɪ ɒn/','phrasal verb','A2','Can I try on this jacket?','Можна приміряти цю куртку?','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,2),
  ('wear out','зношувати','/weə aʊt/','phrasal verb','B1','These shoes wear out quickly.','Це взуття швидко зношується.','6c445724-2efc-442c-a828-238ca046d4ee'::uuid,true,3)
)
INSERT INTO vocabulary (word, translation_uk, transcription, part_of_speech, cefr_level, example_en, example_uk, category_id, is_for_nmt, difficulty)
SELECT g.word, g.translation_uk, g.transcription, g.part_of_speech, g.cefr_level, g.example_en, g.example_uk, g.category_id, g.is_for_nmt, g.difficulty
FROM glossary g
WHERE NOT EXISTS (SELECT 1 FROM vocabulary existing WHERE lower(existing.word) = lower(g.word));
